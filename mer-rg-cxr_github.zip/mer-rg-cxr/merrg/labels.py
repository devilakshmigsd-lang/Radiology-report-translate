"""Label vocabularies and mappings between datasets.

The finding classifier uses the 14 NIH ChestX-ray14 labels. IU X-Ray reports are
labelled from their curated MeSH "Problems" field, and VinDr-CXR labels are mapped
onto the overlapping NIH labels for external testing.
"""
from __future__ import annotations

import re

NIH_LABELS = [
    "Atelectasis", "Cardiomegaly", "Effusion", "Infiltration", "Mass", "Nodule",
    "Pneumonia", "Pneumothorax", "Consolidation", "Edema", "Emphysema", "Fibrosis",
    "Pleural_Thickening", "Hernia",
]

# Human-readable names used in prompts, templates and the rule-based matcher.
READABLE = {
    "Atelectasis": "atelectasis",
    "Cardiomegaly": "cardiomegaly",
    "Effusion": "pleural effusion",
    "Infiltration": "infiltrate",
    "Mass": "mass",
    "Nodule": "nodule",
    "Pneumonia": "pneumonia",
    "Pneumothorax": "pneumothorax",
    "Consolidation": "consolidation",
    "Edema": "pulmonary edema",
    "Emphysema": "emphysema",
    "Fibrosis": "fibrosis",
    "Pleural_Thickening": "pleural thickening",
    "Hernia": "hiatal hernia",
}

# Keywords (regular expressions, lower-case) that signal each finding in free text.
# Used by the consistency filter and the back-translation check. Edit with a radiologist.
SYNONYMS = {
    "Atelectasis": [r"atelecta\w*", r"collapse"],
    "Cardiomegaly": [r"cardiomegaly", r"(heart|cardiac silhouette|cardiac size|heart size)\s+(is\s+|are\s+)?(mildly\s+|moderately\s+|markedly\s+)?(enlarged|large)", r"enlarged (heart|cardiac silhouette)"],
    "Effusion": [r"effusions?"],
    "Infiltration": [r"infiltrat\w*", r"opacit\w*"],
    "Mass": [r"\bmass(es)?\b"],
    "Nodule": [r"nodul\w*"],
    "Pneumonia": [r"pneumonia"],
    "Pneumothorax": [r"pneumothora\w*"],
    "Consolidation": [r"consolidat\w*", r"airspace disease"],
    "Edema": [r"edema", r"oedema", r"vascular congestion"],
    "Emphysema": [r"emphysema\w*", r"hyperinflat\w*", r"hyperexpan\w*", r"copd"],
    "Fibrosis": [r"fibros\w*", r"fibrotic", r"scarring"],
    "Pleural_Thickening": [r"pleural thickening", r"thickened pleura"],
    "Hernia": [r"hernia"],
}

# IU X-Ray "Problems" field -> NIH labels (substring match on lower-cased problems).
# NOTE: IU "Opacity" is mapped to Infiltration because NIH has no opacity label.
# State this mapping in the paper (Supplementary Table S2).
IU_PROBLEM_TO_NIH = {
    "atelectasis": "Atelectasis",
    "cardiomegaly": "Cardiomegaly",
    "pleural effusion": "Effusion",
    "infiltrate": "Infiltration",
    "opacity": "Infiltration",
    "mass": "Mass",
    "nodule": "Nodule",
    "pneumonia": "Pneumonia",
    "pneumothorax": "Pneumothorax",
    "consolidation": "Consolidation",
    "edema": "Edema",
    "emphysema": "Emphysema",
    "fibrosis": "Fibrosis",
    "thickening": "Pleural_Thickening",  # only counted when "pleura" also present
    "hernia": "Hernia",
}

# VinDr-CXR class names -> NIH labels used for external testing.
# "Nodule/Mass" is compared with max(P(Nodule), P(Mass)).
VINDR_TO_NIH = {
    "Atelectasis": "Atelectasis",
    "Cardiomegaly": "Cardiomegaly",
    "Consolidation": "Consolidation",
    "Infiltration": "Infiltration",
    "Pleural effusion": "Effusion",
    "Pleural thickening": "Pleural_Thickening",
    "Pneumothorax": "Pneumothorax",
    "Pulmonary fibrosis": "Fibrosis",
    "Nodule/Mass": "Nodule_or_Mass",
}

# NIH bounding-box file uses "Infiltrate" instead of "Infiltration".
NIH_BBOX_RENAME = {"Infiltrate": "Infiltration"}


def iu_problems_to_labels(problems: str) -> dict:
    """Map an IU X-Ray 'Problems' string (semicolon separated) to NIH binary labels."""
    text = (problems or "").lower()
    out = {lab: 0 for lab in NIH_LABELS}
    if not text or text.strip() == "normal":
        return out
    for key, lab in IU_PROBLEM_TO_NIH.items():
        if key == "thickening":
            if "thickening" in text and "pleura" in text:
                out[lab] = 1
            continue
        if re.search(r"\b" + re.escape(key), text):
            out[lab] = 1
    return out


# Seed list of radiology terms for the physician-built translation glossary.
GLOSSARY_SEED_TERMS = [
    "atelectasis", "cardiomegaly", "pleural effusion", "pneumothorax", "consolidation",
    "pulmonary edema", "emphysema", "fibrosis", "pleural thickening", "hiatal hernia",
    "nodule", "mass", "granuloma", "calcified granuloma", "infiltrate", "opacity",
    "airspace disease", "pneumonia", "cardiomediastinal silhouette", "mediastinum",
    "mediastinal contours", "hilar", "hilum", "costophrenic angle", "hemidiaphragm",
    "diaphragm", "pulmonary vasculature", "vascular congestion", "interstitial markings",
    "osseous structures", "thoracic spine", "degenerative changes", "scoliosis",
    "kyphosis", "aorta", "tortuous aorta", "aortic calcification", "lung volumes",
    "hyperinflation", "scarring", "lingula", "right upper lobe", "right middle lobe",
    "right lower lobe", "left upper lobe", "left lower lobe", "lung base", "lung apex",
    "bibasilar", "bilateral", "trachea", "sternotomy wires", "surgical clips",
    "endotracheal tube", "central venous catheter", "pacemaker", "acute cardiopulmonary abnormality",
    "focal airspace disease", "heart size", "within normal limits", "no acute",
]
