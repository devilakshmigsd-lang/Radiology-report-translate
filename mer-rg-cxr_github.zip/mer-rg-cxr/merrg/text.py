"""Text utilities: report cleaning, prompts, rule-based finding matcher, consistency filter,
templates, glossary masking for translation, back-translation flag, and the MedIndic-RR sampler.

The rule-based matcher is deliberately independent of CheXbert, which is used only to
*evaluate* reports. Using the evaluator inside the method would inflate the metric.
"""
from __future__ import annotations

import math
import re
from typing import Iterable

import numpy as np

from .labels import NIH_LABELS, READABLE, SYNONYMS

# --------------------------------------------------------------------------- cleaning
def clean_report_iu_xray(report: str) -> str:
    """Report normalisation used by R2Gen/CMN for IU X-Ray, so metrics are comparable."""
    def report_cleaner(t):
        return (t.replace("..", ".").replace("..", ".").replace("..", ".").replace("1. ", "")
                 .replace(". 2. ", ". ").replace(". 3. ", ". ").replace(". 4. ", ". ").replace(". 5. ", ". ")
                 .replace(" 2. ", ". ").replace(" 3. ", ". ").replace(" 4. ", ". ").replace(" 5. ", ". ")
                 .strip().lower().split(". "))

    def sent_cleaner(t):
        return re.sub(r"[.,?;*!%^&_+():\-\[\]{}]", "",
                      t.replace('"', "").replace("/", "").replace("\\", "").replace("'", "").strip().lower())

    tokens = [sent_cleaner(s) for s in report_cleaner(report or "") if sent_cleaner(s) != ""]
    return " . ".join(tokens) + " ."


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", (text or "").strip())
    return [p.strip() for p in parts if p.strip()]


# --------------------------------------------------------------------------- prompts
def build_prompt(labels: dict) -> str:
    """Finding prompt for BioGPT. labels: NIH label -> 0/1. Deterministic order."""
    pos = [READABLE[l] for l in NIH_LABELS if labels.get(l, 0) == 1]
    neg = [READABLE[l] for l in NIH_LABELS if labels.get(l, 0) != 1]
    p = "positive: " + (", ".join(pos) if pos else "none")
    n = "negative: " + ", ".join(neg)
    return f"{p}. {n}."


# --------------------------------------------------------------------------- matcher
NEG_PRE = re.compile(
    r"\b(no(?!\s+(interval\s+)?(significant\s+)?change)|not|without|negative for|free of|clear of|absence of|resolution of|resolved|"
    r"no evidence of|no signs? of|no definite|no focal|no acute|nor|rather than)\b")
NEG_POST = re.compile(
    r"^\W*(\w+\s+){0,3}?(is|are|was|were|has|have)?\s*(not\s+(seen|identified|present|visualized|evident)|absent|resolved|cleared)\b")
UNCERTAIN = re.compile(
    r"\b(may|might|possible|possibly|probable|likely|suspicious for|cannot be excluded|"
    r"can not be excluded|cannot exclude|questionable|suggest\w*|concerning for|versus|vs)\b")
CLAUSE_BREAK = re.compile(r"\b(but|however|although|though|whereas|otherwise)\b|;")

LATERALITY = re.compile(r"\b(left|right|bilateral|bibasilar|bilaterally)\b")
SEVERITY = re.compile(r"\b(small|large|mild|mildly|moderate|moderately|severe|severely|minimal|trace|tiny|massive|marked|markedly)\b")


def _clauses(sentence: str) -> list[str]:
    return [c.strip() for c in CLAUSE_BREAK.split(sentence.lower()) if c and c.strip() and not CLAUSE_BREAK.fullmatch(c.strip())]


def match_sentence(sentence: str) -> dict:
    """Return {label: 'pos'|'neg'|'unc'} for findings mentioned in one sentence."""
    out = {}
    for clause in _clauses(sentence):
        for lab, pats in SYNONYMS.items():
            for pat in pats:
                m = re.search(pat, clause)
                if not m:
                    continue
                before, after = clause[: m.start()], clause[m.end():]
                if NEG_PRE.search(before) or NEG_POST.search(after):
                    state = "neg"
                elif UNCERTAIN.search(clause):
                    state = "unc"
                else:
                    state = "pos"
                prev = out.get(lab)
                # positive beats uncertain beats negative within one sentence
                rank = {"neg": 0, "unc": 1, "pos": 2}
                if prev is None or rank[state] > rank[prev]:
                    out[lab] = state
                break
    return out


def match_report(text: str) -> dict:
    """Aggregate sentence states over a report: pos > unc > neg."""
    agg: dict = {}
    rank = {"neg": 0, "unc": 1, "pos": 2}
    for s in split_sentences(text):
        for lab, st in match_sentence(s).items():
            if lab not in agg or rank[st] > rank[agg[lab]]:
                agg[lab] = st
    return agg


def is_positive(state) -> bool:
    return state in ("pos", "unc")


# --------------------------------------------------------------------------- templates
TEMPLATE = {
    "Atelectasis": "There is atelectasis.",
    "Cardiomegaly": "The heart is enlarged, consistent with cardiomegaly.",
    "Effusion": "There is a pleural effusion.",
    "Infiltration": "There is an airspace opacity.",
    "Mass": "There is a pulmonary mass.",
    "Nodule": "There is a pulmonary nodule.",
    "Pneumonia": "Findings are concerning for pneumonia.",
    "Pneumothorax": "There is a pneumothorax.",
    "Consolidation": "There is focal consolidation.",
    "Edema": "There is pulmonary edema.",
    "Emphysema": "The lungs are hyperinflated, consistent with emphysema.",
    "Fibrosis": "There are fibrotic changes.",
    "Pleural_Thickening": "There is pleural thickening.",
    "Hernia": "There is a hiatal hernia.",
}
NORMAL_TEMPLATE = ("The heart size and mediastinal contours are within normal limits. "
                   "The lungs are clear. There is no pneumothorax or pleural effusion.")


def template_report(labels: dict) -> str:
    """Template-only baseline: one fixed sentence per predicted finding."""
    pos = [l for l in NIH_LABELS if labels.get(l, 0) == 1]
    if not pos:
        return NORMAL_TEMPLATE
    neg_tail = []
    if labels.get("Pneumothorax", 0) != 1:
        neg_tail.append("pneumothorax")
    if labels.get("Effusion", 0) != 1:
        neg_tail.append("pleural effusion")
    tail = f" There is no {' or '.join(neg_tail)}." if neg_tail else ""
    return " ".join(TEMPLATE[l] for l in pos) + tail


# --------------------------------------------------------------------------- consistency filter
def consistency_filter(report: str, labels: dict, append_missing: bool = True):
    """Remove sentences that contradict the classifier's predictions.

    A sentence is removed if it asserts (or suggests) a finding predicted absent, or negates a
    finding predicted present. Predicted-present findings not asserted in the remaining text are
    appended from TEMPLATE. Returns (filtered_report, log) where log lists removed/added sentences.
    """
    kept, removed = [], []
    for s in split_sentences(report):
        states = match_sentence(s)
        bad = [lab for lab, st in states.items()
               if (labels.get(lab, 0) != 1 and is_positive(st)) or (labels.get(lab, 0) == 1 and st == "neg")]
        (removed if bad else kept).append(s)
    added = []
    if append_missing:
        present = match_report(" ".join(kept))
        for lab in NIH_LABELS:
            if labels.get(lab, 0) == 1 and not is_positive(present.get(lab)):
                added.append(TEMPLATE[lab])
    out = " ".join(kept + added).strip()
    if not out:
        out = NORMAL_TEMPLATE if not any(labels.get(l, 0) == 1 for l in NIH_LABELS) else " ".join(added)
    return out, {"removed": removed, "added": added}


# --------------------------------------------------------------------------- glossary masking
_INDIC_DIGITS = {}
for base in (0x0966, 0x0BE6, 0x0C66):  # Devanagari, Tamil, Telugu digits
    for d in range(10):
        _INDIC_DIGITS[base + d] = str(d)
_INDIC_TT = str.maketrans({chr(k): v for k, v in _INDIC_DIGITS.items()})
_PH = re.compile(r"\[\s*(\d+)\s*\]")


def mask_terms(text: str, terms: Iterable[str]):
    """Replace glossary terms (longest first, case-insensitive, whole words) with [0], [1], ...

    Returns (masked_text, mapping) where mapping[i] = English term behind placeholder [i].
    """
    mapping: list[str] = []
    out = text
    for term in sorted(set(terms), key=len, reverse=True):
        pat = re.compile(r"(?<![\w\[])" + re.escape(term) + r"(?![\w\]])", re.IGNORECASE)

        def repl(m, term=term):
            mapping.append(term)
            return f"[{len(mapping) - 1}]"
        out = pat.sub(repl, out)
    return out, mapping


def unmask_terms(translated: str, mapping: list[str], target_terms: dict):
    """Restore placeholders with the approved target-language terms.

    Indic digits inside placeholders are normalised first. Returns (text, n_missing) where
    n_missing counts placeholders the MT system dropped (report this rate in the paper).
    """
    t = translated.translate(_INDIC_TT)
    seen = set()

    def repl(m):
        i = int(m.group(1))
        if i < len(mapping):
            seen.add(i)
            return target_terms.get(mapping[i], mapping[i])
        return m.group(0)
    t = _PH.sub(repl, t)
    return t, len(set(range(len(mapping))) - seen)


# --------------------------------------------------------------------------- back-translation check
def backtranslation_flag(source_en: str, back_en: str):
    """Flag a translation for human review when the back-translation changes clinical meaning.

    Compares, between the English source and the English back-translation:
      * presence (asserted/suggested vs. negated/not mentioned) of each finding,
      * negation of each finding mentioned in the source,
      * the multiset of laterality words, and of severity words.
    Returns (flag: bool, reasons: list[str]).
    """
    a, b = match_report(source_en), match_report(back_en)
    reasons = []
    for lab in NIH_LABELS:
        sa, sb = a.get(lab), b.get(lab)
        if is_positive(sa) != is_positive(sb):
            reasons.append(f"presence:{lab}")
        elif sa == "neg" and sb is None:
            reasons.append(f"negation_dropped:{lab}")
    la = sorted(LATERALITY.findall(source_en.lower()))
    lb = sorted(LATERALITY.findall(back_en.lower()))
    norm = lambda xs: sorted("bilateral" if x in ("bilaterally", "bibasilar") else x for x in xs)
    if norm(la) != norm(lb):
        reasons.append("laterality")
    sva = sorted(re.sub(r"ly$", "", m) for m in SEVERITY.findall(source_en.lower()))
    svb = sorted(re.sub(r"ly$", "", m) for m in SEVERITY.findall(back_en.lower()))
    if sva != svb:
        reasons.append("severity")
    return bool(reasons), reasons


# --------------------------------------------------------------------------- MedIndic-RR sampler
HAS_NEG = re.compile(r"\b(no|not|without|negative for|free of|clear)\b", re.IGNORECASE)
HAS_LAT = re.compile(r"\b(left|right|bilateral|bibasilar|bilaterally)\b", re.IGNORECASE)


def sample_medindic(texts: list[str], n: int = 300, neg_frac: float = 0.40, lat_frac: float = 0.25,
                    seed: int = 2026) -> list[int]:
    """Stratified sample of report indices with quotas on negation and laterality content."""
    rng = np.random.default_rng(seed)
    idx = np.arange(len(texts))
    neg = np.array([bool(HAS_NEG.search(t or "")) for t in texts])
    lat = np.array([bool(HAS_LAT.search(t or "")) for t in texts])
    if n > len(texts):
        raise ValueError("n larger than pool")
    chosen: list[int] = []
    need_lat = math.ceil(lat_frac * n)
    pool = idx[lat]
    if len(pool) < need_lat:
        raise ValueError("not enough laterality reports")
    chosen += list(rng.choice(pool, need_lat, replace=False))
    need_neg = math.ceil(neg_frac * n) - int(neg[chosen].sum())
    if need_neg > 0:
        pool = np.setdiff1d(idx[neg], chosen)
        if len(pool) < need_neg:
            raise ValueError("not enough negation reports")
        chosen += list(rng.choice(pool, need_neg, replace=False))
    rest = np.setdiff1d(idx, chosen)
    chosen += list(rng.choice(rest, n - len(chosen), replace=False))
    return sorted(int(i) for i in chosen)


# --------------------------------------------------------------------------- target-language checks
# Surface markers used to check, directly in the translation, that negation and left/right survive.
# They are deliberately simple and MUST be reviewed by a native speaker of each language before use.
# Their accuracy is measured against the human Tamil audit (notebook 05).
TARGET_MARKERS = {
    "hi": {"neg": ["नहीं", "कोई", "बिना", "अनुपस्थित", "न "],
           "left": ["बाएं", "बाएँ", "बायां", "बायाँ", "बाईं", "बायीं", "बाई ", "वाम"],
           "right": ["दाएं", "दाएँ", "दायां", "दायाँ", "दाईं", "दायीं", "दाहिन", "दाई "]},
    "ta": {"neg": ["இல்லை", "இல்லாத", "இல்லாமல்", "வில்லை", "இன்றி", "அற்ற", "இல்ல"],
           "left": ["இடது", "இடப்", "இடப்பக்"],
           "right": ["வலது", "வலப்", "வலப்பக்"]},
    "te": {"neg": ["లేదు", "లేవు", "లేని", "లేకుండా", "కాదు", "లేక"],
           "left": ["ఎడమ"],
           "right": ["కుడి"]},
}
SRC_NEG = re.compile(r"\b(no|not|without|negative for|free of|absence of)\b", re.IGNORECASE)
SRC_LEFT = re.compile(r"\bleft\b", re.IGNORECASE)
SRC_RIGHT = re.compile(r"\bright\b", re.IGNORECASE)


def _has(text: str, markers) -> bool:
    return any(m in text for m in markers)


def target_marker_check(source_en: str, translation: str, lang: str):
    """Sentence-level check of a translation for lost negation and changed laterality.

    Flags:
      negation_lost  : the English has a negation cue but the translation has no negation marker;
      left_lost / right_lost : 'left'/'right' in English but the matching word is missing;
      laterality_added: a left/right word appears in the translation that the English does not have.
    Returns (flag: bool, reasons: list[str]).
    """
    mk = TARGET_MARKERS[lang]
    t = translation or ""
    reasons = []
    if SRC_NEG.search(source_en) and not _has(t, mk["neg"]):
        reasons.append("negation_lost")
    has_l, has_r = bool(SRC_LEFT.search(source_en)), bool(SRC_RIGHT.search(source_en))
    if has_l and not _has(t, mk["left"]):
        reasons.append("left_lost")
    if has_r and not _has(t, mk["right"]):
        reasons.append("right_lost")
    if (not has_l and _has(t, mk["left"])) or (not has_r and _has(t, mk["right"])):
        reasons.append("laterality_added")
    return bool(reasons), reasons
