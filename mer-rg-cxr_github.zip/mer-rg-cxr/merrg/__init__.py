"""Shared utilities for the MER-RG experiments.

Modules
-------
labels   : label vocabularies and dataset-specific label mappings
stats    : bootstrap confidence intervals, DeLong test, paired bootstrap, McNemar, Holm, kappa
xai      : pointing game, IoU, deletion AUC, SSIM for saliency maps
text     : report cleaning, prompts, rule-based finding matcher, consistency filter,
           templates, glossary masking, back-translation consistency flag, MedIndic-RR sampler
"""
__version__ = "1.0.0"
