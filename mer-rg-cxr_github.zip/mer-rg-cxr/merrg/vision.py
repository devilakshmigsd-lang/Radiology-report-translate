"""Datasets, models, resumable training and prediction (PyTorch + timm).

Images come from the compact uint8 store built in notebook 00 (see merrg/store.py).
Training saves a full checkpoint every epoch, so a Colab disconnect only loses the current epoch.
"""
from __future__ import annotations

import math
import os
import random
import time
from dataclasses import dataclass, field

import cv2
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader, Dataset

from .store import load_gray, letterbox, preprocess_u8  # re-exported for notebooks

IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
IMAGENET_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)


def seed_everything(seed: int):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)


# --------------------------------------------------------------------------- inputs
def augment(img: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """img: HxW float in [0,1]. Rotation +/-10 deg, scale 0.9-1.1, shift +/-5 %, brightness/contrast.
    No horizontal flip: it would reverse anatomical laterality."""
    h, w = img.shape
    m = cv2.getRotationMatrix2D((w / 2, h / 2), rng.uniform(-10, 10), rng.uniform(0.9, 1.1))
    m[:, 2] += rng.uniform(-0.05, 0.05, 2) * np.array([w, h])
    img = cv2.warpAffine(img, m, (w, h), flags=cv2.INTER_LINEAR, borderValue=0)
    return np.clip(img * rng.uniform(0.9, 1.1) + rng.uniform(-0.05, 0.05), 0, 1).astype(np.float32)


def to_model_input(img01: np.ndarray) -> np.ndarray:
    """HxW in [0,1] -> 3xHxW ImageNet-normalised float32."""
    x = np.repeat(img01[..., None], 3, axis=2)
    return ((x - IMAGENET_MEAN) / IMAGENET_STD).transpose(2, 0, 1).astype(np.float32)


class ArrayDataset(Dataset):
    """Reads rows of a uint8 (N, H, W) array (np.load(..., mmap_mode='r') works)."""

    def __init__(self, array, rows, targets=None, train=False, seed=0):
        self.array, self.rows = array, np.asarray(rows, dtype=np.int64)
        self.targets = None if targets is None else np.asarray(targets, dtype=np.float32)
        self.train = train
        self.rng = np.random.default_rng(seed)

    def __len__(self):
        return len(self.rows)

    def image01(self, i):
        return np.asarray(self.array[self.rows[i]], dtype=np.float32) / 255.0

    def __getitem__(self, i):
        img = self.image01(i)
        if self.train:
            img = augment(img, self.rng)
        x = torch.from_numpy(to_model_input(img))
        return x if self.targets is None else (x, torch.from_numpy(self.targets[i]))


def worker_init(worker_id):
    info = torch.utils.data.get_worker_info()
    info.dataset.rng = np.random.default_rng(info.seed % 2**32)


def load_store_local(drive_prefix: str, local_dir: str = "/content/store"):
    """Copy a store from Drive to the fast local disk once per session, then memory-map it."""
    import shutil
    os.makedirs(local_dir, exist_ok=True)
    local = os.path.join(local_dir, os.path.basename(drive_prefix) + ".npy")
    if not os.path.exists(local):
        print("copying", drive_prefix + ".npy", "to local disk ...")
        shutil.copy(drive_prefix + ".npy", local + ".part"); os.replace(local + ".part", local)
    return np.load(local, mmap_mode="r")


# --------------------------------------------------------------------------- models
def build_model(name: str, n_out: int, pretrained: bool = True) -> nn.Module:
    import timm
    return timm.create_model(name, pretrained=pretrained, num_classes=n_out)


def gradcam_target_layer(model: nn.Module, name: str):
    if name.startswith("efficientnet"):
        return model.blocks[-1]
    if name.startswith("resnet"):
        return model.layer4[-1]
    if name.startswith("densenet"):
        return model.features.denseblock4
    raise ValueError(name)


def cascading_modules(model: nn.Module):
    """Top-level modules from output to input, expanding Sequential containers (randomisation test)."""
    mods = []
    for name, m in model.named_children():
        if isinstance(m, nn.Sequential) and len(m) > 1:
            mods += [(f"{name}.{i}", sub) for i, sub in enumerate(m)]
        else:
            mods.append((name, m))
    return list(reversed(mods))


def reinit_(module: nn.Module, seed: int = 0):
    torch.manual_seed(seed)
    for m in module.modules():
        if hasattr(m, "reset_parameters"):
            m.reset_parameters()


# --------------------------------------------------------------------------- training
@dataclass
class TrainConfig:
    epochs: int = 10
    batch_size: int = 64
    lr: float = 1e-4
    weight_decay: float = 1e-5
    patience: int = 3
    num_workers: int = 2
    amp: bool = True
    log_every: int = 300
    pos_weight: list | None = field(default=None)


def macro_auc(y: np.ndarray, p: np.ndarray) -> float:
    aucs = [roc_auc_score(y[:, k], p[:, k]) for k in range(y.shape[1]) if 0 < y[:, k].sum() < len(y)]
    return float(np.mean(aucs)) if aucs else float("nan")


@torch.no_grad()
def predict(model, ds, batch_size=128, num_workers=2, device="cuda") -> np.ndarray:
    model.eval().to(device)
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, pin_memory=True)
    out = []
    for b in dl:
        x = b[0] if isinstance(b, (list, tuple)) else b
        with torch.autocast(device_type="cuda", enabled=device == "cuda"):
            out.append(torch.sigmoid(model(x.to(device, non_blocking=True)).float()).cpu().numpy())
    return np.concatenate(out)


def train_model(model, train_ds, val_ds, cfg: TrainConfig, ckpt_path: str, device="cuda"):
    """AdamW + cosine decay + weighted BCE, early stopping on validation macro AUROC.

    Saves `ckpt_path` (best weights) and `ckpt_path + '.state'` (everything needed to resume) after
    every epoch. Calling it again after a disconnect continues from the last finished epoch.
    Returns the training history (list of dicts).
    """
    model.to(device)
    dl = DataLoader(train_ds, batch_size=cfg.batch_size, shuffle=True, num_workers=cfg.num_workers,
                    pin_memory=True, drop_last=True, worker_init_fn=worker_init, persistent_workers=cfg.num_workers > 0)
    pw = None if cfg.pos_weight is None else torch.tensor(cfg.pos_weight, dtype=torch.float32, device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pw)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    total = cfg.epochs * len(dl)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: 0.5 * (1 + math.cos(math.pi * min(s, total) / total)))
    scaler = torch.amp.GradScaler("cuda", enabled=cfg.amp and device == "cuda")
    state_path = ckpt_path + ".state"
    start, best, bad, hist = 0, -1.0, 0, []
    if os.path.exists(state_path):
        st = torch.load(state_path, map_location=device, weights_only=False)
        model.load_state_dict(st["model"]); opt.load_state_dict(st["opt"]); sched.load_state_dict(st["sched"])
        scaler.load_state_dict(st["scaler"])
        start, best, bad, hist = st["epoch"] + 1, st["best"], st["bad"], st["hist"]
        print(f"resuming from epoch {start} (best val macro AUROC so far {best:.4f})")
        if st.get("done"):
            model.load_state_dict(torch.load(ckpt_path, map_location=device)); return hist
    yv = val_ds.targets
    for ep in range(start, cfg.epochs):
        model.train(); t0 = time.time(); run = 0.0
        for step, (x, y) in enumerate(dl):
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            with torch.autocast(device_type="cuda", enabled=cfg.amp and device == "cuda"):
                loss = loss_fn(model(x).float(), y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward(); scaler.step(opt); scaler.update(); sched.step()
            run += loss.item()
            if cfg.log_every and step % cfg.log_every == 0:
                print(f"  epoch {ep} step {step}/{len(dl)} loss {loss.item():.4f}")
        pv = predict(model, val_ds, num_workers=cfg.num_workers, device=device)
        auc = macro_auc(yv, pv)
        hist.append({"epoch": ep, "train_loss": run / len(dl), "val_macro_auc": auc, "minutes": (time.time() - t0) / 60})
        print(f"epoch {ep}: train loss {run / len(dl):.4f}  val macro AUROC {auc:.4f}  ({hist[-1]['minutes']:.1f} min)")
        if auc > best:
            best, bad = auc, 0
            torch.save(model.state_dict(), ckpt_path)
        else:
            bad += 1
        done = bad >= cfg.patience or ep == cfg.epochs - 1
        torch.save({"model": model.state_dict(), "opt": opt.state_dict(), "sched": sched.state_dict(),
                    "scaler": scaler.state_dict(), "epoch": ep, "best": best, "bad": bad, "hist": hist, "done": done},
                   state_path + ".tmp")
        os.replace(state_path + ".tmp", state_path)
        if done:
            if bad >= cfg.patience:
                print("early stopping")
            break
    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    return hist
