"""Statistics used throughout the paper.

All confidence intervals are percentile bootstrap intervals that resample *patients*
(or studies/reports) rather than images, so that correlated images from one patient
do not narrow the interval artificially.
"""
from __future__ import annotations

from typing import Callable, Sequence

import numpy as np
from scipy import stats as _st


# --------------------------------------------------------------------------- bootstrap
def _group_index(groups: Sequence | None, n: int):
    if groups is None:
        return [np.array([i]) for i in range(n)]
    groups = np.asarray(groups)
    _, inv = np.unique(groups, return_inverse=True)
    order = np.argsort(inv, kind="stable")
    bounds = np.flatnonzero(np.diff(inv[order])) + 1
    return np.split(order, bounds)


def bootstrap_ci(metric: Callable[[np.ndarray], float], n: int, groups: Sequence | None = None,
                 n_boot: int = 1000, alpha: float = 0.05, seed: int = 0):
    """Percentile bootstrap CI for any metric.

    metric : function that takes an integer index array (rows to use) and returns a float.
    n      : number of rows.
    groups : optional cluster id per row (e.g. patient id); clusters are resampled whole.
    Returns (point_estimate, lower, upper). Resamples where the metric is undefined
    (e.g. AUROC with one class) return NaN and are ignored.
    """
    rng = np.random.default_rng(seed)
    clusters = _group_index(groups, n)
    point = float(metric(np.arange(n)))
    k = len(clusters)
    vals = np.empty(n_boot)
    for b in range(n_boot):
        pick = rng.integers(0, k, size=k)
        idx = np.concatenate([clusters[j] for j in pick])
        try:
            vals[b] = metric(idx)
        except ValueError:
            vals[b] = np.nan
    lo, hi = np.nanpercentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return point, float(lo), float(hi)


def paired_bootstrap(metric_a: Callable[[np.ndarray], float], metric_b: Callable[[np.ndarray], float],
                     n: int, groups: Sequence | None = None, n_boot: int = 1000, seed: int = 0):
    """Paired bootstrap comparison of two systems scored on the same items (Koehn 2004).

    Returns dict(diff, lower, upper, p) for diff = metric_a - metric_b.
    p is the two-sided bootstrap p-value (share of resamples whose sign differs from the
    observed difference, doubled, capped at 1).
    """
    rng = np.random.default_rng(seed)
    clusters = _group_index(groups, n)
    allidx = np.arange(n)
    diff = metric_a(allidx) - metric_b(allidx)
    k = len(clusters)
    d = np.empty(n_boot)
    for b in range(n_boot):
        pick = rng.integers(0, k, size=k)
        idx = np.concatenate([clusters[j] for j in pick])
        d[b] = metric_a(idx) - metric_b(idx)
    lo, hi = np.percentile(d, [2.5, 97.5])
    if diff == 0:
        p = 1.0
    else:
        p = min(1.0, 2 * np.mean(np.sign(d) != np.sign(diff)))
    return {"diff": float(diff), "lower": float(lo), "upper": float(hi), "p": float(p)}


# --------------------------------------------------------------------------- DeLong
def _midrank(x: np.ndarray) -> np.ndarray:
    j = np.argsort(x)
    z = x[j]
    n = len(x)
    t = np.zeros(n)
    i = 0
    while i < n:
        a = i
        while a < n and z[a] == z[i]:
            a += 1
        t[i:a] = 0.5 * (i + a - 1)
        i = a
    t2 = np.empty(n)
    t2[j] = t + 1
    return t2


def _fast_delong(preds_sorted: np.ndarray, m: int):
    """preds_sorted: (k, n) with the m positives first. Sun & Xu (2014) algorithm."""
    n = preds_sorted.shape[1] - m
    pos, neg = preds_sorted[:, :m], preds_sorted[:, m:]
    k = preds_sorted.shape[0]
    tx = np.vstack([_midrank(pos[r]) for r in range(k)])
    ty = np.vstack([_midrank(neg[r]) for r in range(k)])
    tz = np.vstack([_midrank(preds_sorted[r]) for r in range(k)])
    aucs = tz[:, :m].sum(axis=1) / m / n - (m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    sx = np.atleast_2d(np.cov(v01))
    sy = np.atleast_2d(np.cov(v10))
    return aucs, sx / m + sy / n


def delong_test(y_true, score_a, score_b):
    """Two-sided DeLong test for two correlated AUROCs on the same cases.

    Returns dict(auc_a, auc_b, z, p).
    """
    y = np.asarray(y_true).astype(int)
    if y.min() == y.max():
        raise ValueError("Need both classes for DeLong")
    order = np.argsort(-y, kind="stable")  # positives first
    m = int(y.sum())
    preds = np.vstack([np.asarray(score_a)[order], np.asarray(score_b)[order]])
    aucs, cov = _fast_delong(preds, m)
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if var <= 0:
        return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "z": 0.0, "p": 1.0}
    z = (aucs[0] - aucs[1]) / np.sqrt(var)
    p = 2 * _st.norm.sf(abs(z))
    return {"auc_a": float(aucs[0]), "auc_b": float(aucs[1]), "z": float(z), "p": float(p)}


def delong_ci(y_true, score, alpha: float = 0.05):
    """AUROC with DeLong asymptotic CI (useful as a cross-check of the bootstrap CI)."""
    y = np.asarray(y_true).astype(int)
    order = np.argsort(-y, kind="stable")
    m = int(y.sum())
    aucs, cov = _fast_delong(np.asarray(score)[order][None, :], m)
    se = np.sqrt(cov[0, 0])
    zc = _st.norm.ppf(1 - alpha / 2)
    return float(aucs[0]), float(max(0, aucs[0] - zc * se)), float(min(1, aucs[0] + zc * se))


# --------------------------------------------------------------------------- tests on counts
def mcnemar_exact(b: int, c: int) -> float:
    """Exact McNemar p-value from discordant counts b (A wrong, B right) and c (A right, B wrong)."""
    n = b + c
    if n == 0:
        return 1.0
    return float(_st.binomtest(min(b, c), n, 0.5).pvalue)


def holm(pvals: Sequence[float]) -> np.ndarray:
    """Holm-Bonferroni adjusted p-values (same order as input)."""
    p = np.asarray(pvals, dtype=float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * p[i])
        adj[i] = min(1.0, running)
    return adj


# --------------------------------------------------------------------------- agreement
def fleiss_kappa(ratings: np.ndarray) -> float:
    """Fleiss' kappa. ratings: (n_items, n_raters) integer category codes."""
    ratings = np.asarray(ratings)
    cats = np.unique(ratings)
    n_items, n_raters = ratings.shape
    counts = np.stack([(ratings == c).sum(axis=1) for c in cats], axis=1)
    p_j = counts.sum(axis=0) / (n_items * n_raters)
    p_i = ((counts ** 2).sum(axis=1) - n_raters) / (n_raters * (n_raters - 1))
    p_bar, p_e = p_i.mean(), (p_j ** 2).sum()
    if p_e == 1:
        return 1.0
    return float((p_bar - p_e) / (1 - p_e))


def mean_pairwise_weighted_kappa(ratings: np.ndarray, weights: str = "quadratic") -> float:
    """Mean of pairwise Cohen's weighted kappa across raters. ratings: (n_items, n_raters)."""
    from sklearn.metrics import cohen_kappa_score

    r = np.asarray(ratings)
    ks = []
    for i in range(r.shape[1]):
        for j in range(i + 1, r.shape[1]):
            ks.append(cohen_kappa_score(r[:, i], r[:, j], weights=weights))
    return float(np.mean(ks))


def youden_threshold(y_true, score) -> float:
    """Threshold maximising Youden's J (sensitivity + specificity - 1)."""
    from sklearn.metrics import roc_curve

    fpr, tpr, thr = roc_curve(y_true, score)
    j = tpr - fpr
    t = thr[int(np.argmax(j))]
    return float(min(t, 1.0))


def fmt_ci(point: float, lo: float, hi: float, digits: int = 3) -> str:
    """'0.812 (0.790-0.833)' formatting used in all output tables."""
    return f"{point:.{digits}f} ({lo:.{digits}f}-{hi:.{digits}f})"
