"""Quantitative evaluation of saliency maps (Grad-CAM, LIME).

Boxes are (x, y, w, h) in the same pixel coordinates as the saliency map.
"""
from __future__ import annotations

from typing import Callable

import numpy as np


def box_mask(shape, box) -> np.ndarray:
    h, w = shape
    x, y, bw, bh = box
    m = np.zeros((h, w), dtype=bool)
    x0, y0 = max(0, int(np.floor(x))), max(0, int(np.floor(y)))
    x1, y1 = min(w, int(np.ceil(x + bw))), min(h, int(np.ceil(y + bh)))
    m[y0:y1, x0:x1] = True
    return m


def pointing_game_hit(saliency: np.ndarray, box, tolerance: int = 0) -> bool:
    """True if the saliency maximum lies inside the box (optionally enlarged by `tolerance` px).

    Ties are resolved by taking the centroid of all maximal pixels.
    """
    s = np.asarray(saliency, dtype=float)
    ys, xs = np.nonzero(s == s.max())
    cy, cx = ys.mean(), xs.mean()
    x, y, w, h = box
    return bool((x - tolerance) <= cx <= (x + w + tolerance) and (y - tolerance) <= cy <= (y + h + tolerance))


def iou_at_percentile(saliency: np.ndarray, box, percentile: float = 80.0) -> float:
    """IoU between the box and the saliency map thresholded at its `percentile`."""
    s = np.asarray(saliency, dtype=float)
    pred = s >= np.percentile(s, percentile)
    gt = box_mask(s.shape, box)
    inter = np.logical_and(pred, gt).sum()
    union = np.logical_or(pred, gt).sum()
    return float(inter / union) if union else 0.0


def deletion_auc(predict: Callable[[np.ndarray], np.ndarray], image: np.ndarray, saliency: np.ndarray,
                 steps: int = 20, fill: str | float = "mean") -> float:
    """Deletion metric (Petsiuk et al. 2018): lower is better.

    predict : function mapping a batch (N, H, W, C) float array to the target-class probability (N,).
    image   : (H, W, C) array in the model's input space (before mean/std normalisation is fine,
              as long as `predict` handles it).
    saliency: (H, W) map aligned with image.
    The most salient pixels are replaced by `fill` in `steps` equal chunks; returns the area
    under probability vs. fraction-deleted, on [0, 1].
    """
    img = np.asarray(image, dtype=np.float32)
    h, w = saliency.shape
    order = np.argsort(-np.asarray(saliency).ravel(), kind="stable")
    fill_val = img.mean(axis=(0, 1)) if fill == "mean" else np.full(img.shape[-1], float(fill), dtype=np.float32)
    batch = np.repeat(img[None], steps + 1, axis=0)
    flat = batch.reshape(steps + 1, h * w, img.shape[-1])
    cuts = np.linspace(0, h * w, steps + 1).astype(int)
    for k in range(1, steps + 1):
        flat[k, order[: cuts[k]]] = fill_val
    probs = np.asarray(predict(flat.reshape(batch.shape)), dtype=float).ravel()
    xs = cuts / (h * w)
    return float(np.trapezoid(probs, xs) if hasattr(np, "trapezoid") else np.trapz(probs, xs))


def normalise(m: np.ndarray) -> np.ndarray:
    m = np.asarray(m, dtype=float)
    rng = m.max() - m.min()
    return (m - m.min()) / rng if rng > 0 else np.zeros_like(m)


def map_ssim(a: np.ndarray, b: np.ndarray) -> float:
    """SSIM between two saliency maps after min-max normalisation (Adebayo et al. 2018)."""
    from skimage.metrics import structural_similarity

    return float(structural_similarity(normalise(a), normalise(b), data_range=1.0))


def centre_prior(shape, sigma_frac: float = 0.25) -> np.ndarray:
    """Trivial baseline: an isotropic Gaussian centred on the image."""
    h, w = shape
    yy, xx = np.mgrid[0:h, 0:w]
    s = sigma_frac * max(h, w)
    return np.exp(-(((yy - h / 2) ** 2) + ((xx - w / 2) ** 2)) / (2 * s * s))


def lime_to_map(segments: np.ndarray, local_exp: list) -> np.ndarray:
    """Turn LIME (segment, weight) pairs into a dense map; negative weights clipped to 0."""
    m = np.zeros(segments.shape, dtype=float)
    for seg, wgt in local_exp:
        m[segments == seg] = max(0.0, float(wgt))
    return m
