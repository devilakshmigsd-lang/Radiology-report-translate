"""Compact image store for Google Colab.

Every image is pre-processed once (grayscale -> CLAHE -> letterbox to SIZE x SIZE) and written
into one uint8 array file (N, SIZE, SIZE) on Google Drive, together with a CSV index that keeps
the original width/height and the letterbox scale/padding (needed to map expert boxes).
At 224 px, all 112,120 NIH images take about 5.6 GB, so the raw 45 GB never has to be kept.

This module only needs numpy, pandas and OpenCV (no PyTorch), so it is unit-tested.
"""
from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np
import pandas as pd



def _finalise(part: str, final: str, tries: int = 10):
    """Rename part -> final and confirm it. Google Drive's file system sometimes drops a rename of a
    freshly written large file, so retry with shutil.move until the final file is visible."""
    import shutil, time
    for _ in range(tries):
        if os.path.exists(part):
            try:
                shutil.move(part, final)
            except OSError:
                pass
        if os.path.exists(final) and not os.path.exists(part):
            return
        time.sleep(3)
    raise OSError(f"could not finalise {final}")


def load_gray(path: str) -> np.ndarray:
    img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(path)
    if img.ndim == 3:
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2GRAY)
    if img.dtype != np.uint8:  # 16-bit PNGs
        img = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return img


def letterbox(img: np.ndarray, size: int):
    """Resize keeping aspect ratio and pad with zeros. Returns (img, scale, pad_x, pad_y);
    a point (x, y) in the original maps to (x*scale + pad_x, y*scale + pad_y)."""
    h, w = img.shape[:2]
    s = size / max(h, w)
    nh, nw = max(1, int(round(h * s))), max(1, int(round(w * s)))
    r = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_AREA)
    out = np.zeros((size, size), dtype=r.dtype)
    py, px = (size - nh) // 2, (size - nw) // 2
    out[py:py + nh, px:px + nw] = r
    return out, s, px, py


def preprocess_u8(img: np.ndarray, size: int, clahe: bool = True):
    """grayscale uint8 -> CLAHE -> letterbox -> min-max stretched uint8 (size x size)."""
    if clahe:
        # a new CLAHE object per call: OpenCV CLAHE objects are not thread-safe
        img = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(img)
    img, s, px, py = letterbox(img, size)
    lo, hi = int(img.min()), int(img.max())
    if hi > lo:
        img = ((img.astype(np.float32) - lo) * (255.0 / (hi - lo))).round().astype(np.uint8)
    return img, s, px, py


def build_store(paths, out_prefix: str, size: int = 224, workers: int = 8, delete_source: bool = False,
                progress_every: int = 5000) -> pd.DataFrame:
    """Write `<out_prefix>.npy` (uint8, N x size x size) and `<out_prefix>.csv` (index).

    The CSV has one row per input path, in the same order: row, path, orig_w, orig_h, scale, pad_x, pad_y.
    If the files already exist with the right length, they are reused (safe to re-run after a disconnect).
    """
    paths = list(paths)
    npy, csv = out_prefix + ".npy", out_prefix + ".csv"
    if os.path.exists(npy) and os.path.exists(csv):
        idx = pd.read_csv(csv)
        if len(idx) == len(paths):
            return idx
    os.makedirs(os.path.dirname(out_prefix) or ".", exist_ok=True)
    arr = np.lib.format.open_memmap(npy + ".part", mode="w+", dtype=np.uint8, shape=(len(paths), size, size))
    meta = [None] * len(paths)

    def work(i):
        raw = load_gray(paths[i])
        img, s, px, py = preprocess_u8(raw, size)
        arr[i] = img
        meta[i] = (i, paths[i], raw.shape[1], raw.shape[0], s, px, py)
        if delete_source:
            os.remove(paths[i])

    with ThreadPoolExecutor(workers) as ex:
        for k, _ in enumerate(ex.map(work, range(len(paths)))):
            if progress_every and k % progress_every == 0:
                print(f"  {k}/{len(paths)}")
    arr.flush(); del arr
    _finalise(npy + ".part", npy)
    idx = pd.DataFrame(meta, columns=["row", "path", "orig_w", "orig_h", "scale", "pad_x", "pad_y"])
    idx.to_csv(csv, index=False)
    return idx


def concat_stores(prefixes, out_prefix: str, delete_parts: bool = True) -> pd.DataFrame:
    """Concatenate several stores (e.g. the 12 NIH parts) into one. If the output already exists
    with the right length it is reused. With delete_parts=False the parts are kept (used to
    assemble a local working copy from parts kept on Google Drive)."""
    idxs = [pd.read_csv(p + ".csv") for p in prefixes]
    n = sum(len(i) for i in idxs)
    if os.path.exists(out_prefix + ".npy") and os.path.exists(out_prefix + ".csv"):
        done = pd.read_csv(out_prefix + ".csv")
        if len(done) == n:
            return done
    os.makedirs(os.path.dirname(out_prefix) or ".", exist_ok=True)
    first = np.load(prefixes[0] + ".npy", mmap_mode="r")
    out = np.lib.format.open_memmap(out_prefix + ".npy.part", mode="w+", dtype=np.uint8, shape=(n,) + first.shape[1:])
    k = 0
    for p, ix in zip(prefixes, idxs):
        a = np.load(p + ".npy", mmap_mode="r")
        out[k:k + len(a)] = a
        k += len(a)
    out.flush(); del out
    _finalise(out_prefix + ".npy.part", out_prefix + ".npy")
    idx = pd.concat(idxs, ignore_index=True)
    idx["row"] = np.arange(len(idx))
    idx.to_csv(out_prefix + ".csv", index=False)
    if delete_parts:
        for p in prefixes:
            os.remove(p + ".npy"); os.remove(p + ".csv")
    return idx


def map_box(box, scale: float, pad_x: float, pad_y: float):
    """Map an (x, y, w, h) box from original pixels into store pixels."""
    x, y, w, h = box
    return (x * scale + pad_x, y * scale + pad_y, w * scale, h * scale)
