"""Unit tests for merrg utilities. Run: python -m pytest -q tests/"""
import numpy as np
import pytest
from sklearn.metrics import roc_auc_score

from merrg import stats, xai, text, labels


# ----------------------------------------------------------------- stats
def test_bootstrap_ci_contains_point_and_is_ordered():
    rng = np.random.default_rng(1)
    y = rng.integers(0, 2, 400)
    s = y + rng.normal(0, 1, 400)
    groups = np.repeat(np.arange(200), 2)
    pt, lo, hi = stats.bootstrap_ci(lambda i: roc_auc_score(y[i], s[i]), len(y), groups=groups, n_boot=300)
    assert lo < pt < hi
    assert abs(pt - roc_auc_score(y, s)) < 1e-12


def test_delong_matches_sklearn_auc_and_identical_scores_give_p1():
    rng = np.random.default_rng(2)
    y = rng.integers(0, 2, 300)
    a = y + rng.normal(0, 1, 300)
    b = y + rng.normal(0, 2, 300)
    r = stats.delong_test(y, a, b)
    assert abs(r["auc_a"] - roc_auc_score(y, a)) < 1e-9
    assert abs(r["auc_b"] - roc_auc_score(y, b)) < 1e-9
    assert r["p"] < 0.05  # a is clearly better
    assert stats.delong_test(y, a, a)["p"] == 1.0


def test_delong_ci_brackets_auc():
    rng = np.random.default_rng(3)
    y = rng.integers(0, 2, 200)
    s = y + rng.normal(0, 1, 200)
    auc, lo, hi = stats.delong_ci(y, s)
    assert lo < auc < hi


def test_paired_bootstrap_detects_difference():
    rng = np.random.default_rng(4)
    a = rng.normal(1.0, 1, 500)
    b = rng.normal(0.0, 1, 500)
    r = stats.paired_bootstrap(lambda i: a[i].mean(), lambda i: b[i].mean(), 500, n_boot=300)
    assert r["diff"] > 0.5 and r["p"] < 0.01 and r["lower"] > 0


def test_holm_and_mcnemar():
    adj = stats.holm([0.01, 0.04, 0.03])
    assert np.allclose(adj, [0.03, 0.06, 0.06])
    assert stats.mcnemar_exact(0, 0) == 1.0
    assert stats.mcnemar_exact(0, 10) < 0.01


def test_kappas():
    r = np.array([[1, 1, 1], [2, 2, 2], [3, 3, 3], [4, 4, 4], [5, 5, 4]])
    assert stats.fleiss_kappa(r) > 0.7
    assert stats.mean_pairwise_weighted_kappa(r) > 0.9


def test_youden():
    y = np.array([0, 0, 0, 1, 1, 1])
    s = np.array([0.1, 0.2, 0.3, 0.7, 0.8, 0.9])
    t = stats.youden_threshold(y, s)
    assert 0.3 < t <= 0.7


# ----------------------------------------------------------------- xai
def test_pointing_and_iou():
    sal = np.zeros((100, 100)); sal[40:60, 40:60] = 1.0
    assert xai.pointing_game_hit(sal, (30, 30, 40, 40))
    assert not xai.pointing_game_hit(sal, (0, 0, 20, 20))
    assert xai.iou_at_percentile(sal, (40, 40, 20, 20), percentile=96) == pytest.approx(1.0)


def test_deletion_auc_rewards_faithful_map():
    h = w = 32
    img = np.zeros((h, w, 3), np.float32); img[8:16, 8:16] = 1.0
    def predict(batch):  # probability = mean brightness of the true region
        return batch[:, 8:16, 8:16, :].mean(axis=(1, 2, 3))
    good = np.zeros((h, w)); good[8:16, 8:16] = 1
    bad = np.zeros((h, w)); bad[20:28, 20:28] = 1
    assert xai.deletion_auc(predict, img, good, fill=0.0) < xai.deletion_auc(predict, img, bad, fill=0.0)


def test_ssim_and_lime_map():
    a = np.random.default_rng(0).random((64, 64))
    assert xai.map_ssim(a, a) == pytest.approx(1.0)
    seg = np.array([[0, 0, 1], [1, 2, 2]])
    m = xai.lime_to_map(seg, [(0, 0.5), (1, -0.2), (2, 0.1)])
    assert m[0, 0] == 0.5 and m[0, 2] == 0 and m[1, 2] == 0.1
    assert xai.centre_prior((10, 10)).argmax() == 55


# ----------------------------------------------------------------- labels
def test_iu_problem_mapping():
    l = labels.iu_problems_to_labels("Cardiomegaly;Pleural Effusion;Opacity")
    assert l["Cardiomegaly"] == 1 and l["Effusion"] == 1 and l["Infiltration"] == 1 and l["Mass"] == 0
    assert sum(labels.iu_problems_to_labels("normal").values()) == 0
    assert labels.iu_problems_to_labels("Thickening")["Pleural_Thickening"] == 0
    assert labels.iu_problems_to_labels("Pleura;Thickening")["Pleural_Thickening"] == 1


# ----------------------------------------------------------------- text
def test_matcher_negation_and_clauses():
    assert text.match_sentence("No pneumothorax or pleural effusion.") == {"Pneumothorax": "neg", "Effusion": "neg"}
    assert text.match_sentence("There is a small left pleural effusion.") == {"Effusion": "pos"}
    s = text.match_sentence("No effusion, but there is left basilar atelectasis.")
    assert s["Effusion"] == "neg" and s["Atelectasis"] == "pos"
    assert text.match_sentence("Pneumothorax is not seen.") == {"Pneumothorax": "neg"}
    assert text.match_sentence("Opacity may represent atelectasis.")["Atelectasis"] == "unc"
    assert text.match_sentence("The heart is enlarged.") == {"Cardiomegaly": "pos"}
    assert text.match_sentence("No change in the right effusion.")["Effusion"] == "pos"


def test_consistency_filter():
    rep = "The heart is enlarged. There is a right pleural effusion. No pneumothorax."
    pred = {l: 0 for l in labels.NIH_LABELS}; pred["Effusion"] = 1; pred["Pneumothorax"] = 1
    out, log = text.consistency_filter(rep, pred)
    assert "heart is enlarged" not in out              # asserted but predicted absent
    assert "No pneumothorax" not in out                # negated but predicted present
    assert "right pleural effusion" in out             # consistent, kept
    assert text.TEMPLATE["Pneumothorax"] in out        # missing positive appended
    assert len(log["removed"]) == 2


def test_prompt_and_template():
    pred = {l: 0 for l in labels.NIH_LABELS}
    assert text.build_prompt(pred).startswith("positive: none.")
    assert text.template_report(pred) == text.NORMAL_TEMPLATE
    pred["Cardiomegaly"] = 1
    assert "cardiomegaly" in text.build_prompt(pred).split(".")[0]
    assert "no pneumothorax or pleural effusion" in text.template_report(pred)


def test_glossary_mask_roundtrip_with_indic_digits():
    masked, mp = text.mask_terms("Small left pleural effusion. No pneumothorax.", ["pleural effusion", "pneumothorax", "effusion"])
    assert masked == "Small left [0]. No [1]."
    # simulate MT output with Devanagari digits and spacing in placeholders
    fake = "छोटा बायाँ [ ० ]. कोई [१] नहीं."
    out, missing = text.unmask_terms(fake, mp, {"pleural effusion": "प्लूरल इफ्यूजन", "pneumothorax": "न्यूमोथोरैक्स"})
    assert "प्लूरल इफ्यूजन" in out and "न्यूमोथोरैक्स" in out and missing == 0
    out2, missing2 = text.unmask_terms("कोई नहीं", mp, {})
    assert missing2 == 2


def test_backtranslation_flag():
    src = "Small left pleural effusion. No pneumothorax."
    assert text.backtranslation_flag(src, "Small left pleural effusion. No pneumothorax.") == (False, [])
    f, r = text.backtranslation_flag(src, "Small left pleural effusion. Pneumothorax.")
    assert f and "presence:Pneumothorax" in r
    f, r = text.backtranslation_flag(src, "Small right pleural effusion. No pneumothorax.")
    assert f and "laterality" in r
    f, r = text.backtranslation_flag(src, "Large left pleural effusion. No pneumothorax.")
    assert f and "severity" in r
    f, r = text.backtranslation_flag(src, "Small left pleural effusion.")
    assert f and "negation_dropped:Pneumothorax" in r


def test_sampler_quotas():
    rng = np.random.default_rng(0)
    pool = []
    for i in range(2000):
        t = "The lungs are clear."
        if rng.random() < 0.5: t += " No pneumothorax."
        if rng.random() < 0.2: t += " Left base atelectasis."
        pool.append(t)
    idx = text.sample_medindic(pool, n=300)
    assert len(idx) == 300 == len(set(idx))
    chosen = [pool[i] for i in idx]
    assert sum(bool(text.HAS_LAT.search(t)) for t in chosen) >= 75
    assert sum(bool(text.HAS_NEG.search(t)) for t in chosen) >= 120


def test_clean_report():
    out = text.clean_report_iu_xray("The heart is normal. No effusion (small).")
    assert out == "the heart is normal . no effusion small ."


# ----------------------------------------------------------------- target-language checks
def test_target_marker_check():
    assert text.target_marker_check("No pneumothorax.", "நியூமோதோராக்ஸ் இல்லை.", "ta") == (False, [])
    f, r = text.target_marker_check("No pneumothorax.", "நியூமோதோராக்ஸ் உள்ளது.", "ta")
    assert f and r == ["negation_lost"]
    f, r = text.target_marker_check("Small left pleural effusion.", "दाएं तरफ छोटा प्लूरल इफ्यूजन।", "hi")
    assert f and "left_lost" in r and "laterality_added" in r
    assert text.target_marker_check("Right lower lobe opacity.", "కుడి దిగువ లోబ్ అస్పష్టత.", "te") == (False, [])
    assert text.target_marker_check("The heart is normal.", "हृदय सामान्य है।", "hi") == (False, [])


# ----------------------------------------------------------------- store
def test_store_roundtrip(tmp_path):
    import cv2
    from merrg import store
    paths = []
    for i, (h, w) in enumerate([(100, 80), (60, 120), (50, 50)]):
        img = (np.random.default_rng(i).random((h, w)) * 255).astype(np.uint8)
        p = str(tmp_path / f"im{i}.png"); cv2.imwrite(p, img); paths.append(p)
    idx = store.build_store(paths, str(tmp_path / "s_part1"), size=32, workers=2, progress_every=0)
    idx2 = store.build_store(paths[:2], str(tmp_path / "s_part2"), size=32, workers=2, progress_every=0)
    arr = np.load(str(tmp_path / "s_part1.npy"))
    assert arr.shape == (3, 32, 32) and arr.dtype == np.uint8
    assert list(idx.path) == paths and idx.orig_w.tolist() == [80, 120, 50]
    # letterbox: 100x80 -> scale 0.32, width 26 -> pad_x 3
    assert abs(idx.scale[0] - 0.32) < 1e-9 and idx.pad_x[0] == 3 and idx.pad_y[0] == 0
    assert arr[0, :, :3].max() == 0  # padding stays black
    # re-running reuses the files
    again = store.build_store(paths, str(tmp_path / "s_part1"), size=32)
    assert len(again) == 3
    cat = store.concat_stores([str(tmp_path / "s_part1"), str(tmp_path / "s_part2")], str(tmp_path / "all"))
    assert len(cat) == 5 and np.load(str(tmp_path / "all.npy")).shape == (5, 32, 32)
    assert cat.row.tolist() == [0, 1, 2, 3, 4]
    assert store.map_box((10, 20, 30, 40), 0.5, 3, 0) == (8.0, 10.0, 15.0, 20.0)
