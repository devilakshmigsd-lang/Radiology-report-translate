# %% [markdown]
# # 04 · Translation into Hindi, Tamil and Telugu, with automatic safety checks (Google Colab, GPU)
#
# 1. Samples 300 IU X-Ray test reports (at least 40 % with negations, 25 % with left/right) and splits them into sentences.
# 2. Translates every sentence with IndicTrans2 and NLLB-200 (and Google Cloud Translation if you set it up).
# 3. Back-translates every output to English.
# 4. Automatic safety checks (no human reference needed):
#    * **target-language check**: is the negation word / left-right word still present in the translation?
#    * **back-translation check**: does the back-translation still contain the same findings, negations,
#      laterality and severity words as the English source?
#    * **round-trip chrF++**: similarity between the English source and its back-translation.
# 5. Exports the blinded **Tamil checking sheets** for the two human annotators (notebook 05 analyses them).
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `tables/table8_automatic_safety.csv`, `tables/table8_significance.csv` | **Table 8** |
# | `medindic/audit_ta_A1.xlsx`, `medindic/audit_ta_A2.xlsx` | send to the two Tamil annotators |
#
# Time: about 1 h on a T4. Translations are saved after each system, so a disconnect loses little.
#
# **Before running:** on huggingface.co log in, open `ai4bharat/indictrans2-en-indic-1B` and
# `ai4bharat/indictrans2-indic-en-1B`, click *Agree and access*; create a token (Settings → Access Tokens, type Read)
# and paste it when the login cell asks.

# %%
import os, sys, re
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
OUT = os.path.join(PROJECT, "outputs"); MI = os.path.join(OUT, "medindic")
sys.path.insert(0, PROJECT)
for d in [MI, os.path.join(OUT, "tables")]:
    os.makedirs(d, exist_ok=True)
os.system("pip install -q openpyxl sacrebleu 'transformers==4.51.3' sentencepiece IndicTransToolkit")

import numpy as np, pandas as pd, torch, sacrebleu
from merrg import text as T, stats

LANGS = {"hi": ("Hindi", "hin_Deva"), "ta": ("Tamil", "tam_Taml"), "te": ("Telugu", "tel_Telu")}
SYSTEMS = ["indictrans2", "nllb"]          # add "google" if you set GCP_PROJECT below
GCP_PROJECT = None                         # e.g. "my-project-id" (needs the Cloud Translation API and billing)
if GCP_PROJECT:
    SYSTEMS.append("google")
N_AUDIT = 100                              # Tamil reports given to the human annotators
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# %%
from huggingface_hub import login
try:                                    # token stored as a Colab secret named HF_TOKEN (key icon in the left bar)
    from google.colab import userdata
    login(token=userdata.get("HF_TOKEN"))
except Exception as e:
    print("HF_TOKEN secret not found; IndicTrans2 (a gated model) will fail.", e)

# %% [markdown]
# ## 1. Sample 300 reports and split into sentences (MedIndic-RR test set)

# %%
src_file = os.path.join(MI, "medindic_sentences.csv")
if not os.path.exists(src_file):
    iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv"), dtype={"uid": str})
    test = iu[iu.split == "test"].reset_index(drop=True)
    idx = T.sample_medindic(test.findings.tolist(), n=300, neg_frac=0.40, lat_frac=0.25, seed=2026)
    rows = [{"item_id": item, "uid": test.uid[i], "sent_id": sid, "en": s}
            for item, i in enumerate(idx) for sid, s in enumerate(T.split_sentences(test.findings[i]))]
    pd.DataFrame(rows).to_csv(src_file, index=False)
S = pd.read_csv(src_file, dtype={"uid": str})
print(S.item_id.nunique(), "reports,", len(S), "sentences")

# %% [markdown]
# ## 2. Translation systems

# %%
_cache = {}
def indictrans2(sents, tgt_code, src_code="eng_Latn"):
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    try:
        from IndicTransToolkit.processor import IndicProcessor
    except ImportError:
        from IndicTransToolkit import IndicProcessor
    name = "ai4bharat/indictrans2-en-indic-1B" if src_code == "eng_Latn" else "ai4bharat/indictrans2-indic-en-1B"
    if name not in _cache:
        for k in [k for k in _cache if k.startswith("ai4bharat")]:   # keep one IndicTrans2 model in GPU memory
            del _cache[k]
        import gc; gc.collect(); torch.cuda.empty_cache()
        tk = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
        md = AutoModelForSeq2SeqLM.from_pretrained(name, trust_remote_code=True, torch_dtype=torch.float16).to(DEVICE).eval()
        _cache[name] = (tk, md, IndicProcessor(inference=True))
    tk, md, ip = _cache[name]
    out = []
    for i in range(0, len(sents), 16):
        batch = ip.preprocess_batch(sents[i:i + 16], src_lang=src_code, tgt_lang=tgt_code)
        enc = tk(batch, truncation=True, padding="longest", return_tensors="pt", return_attention_mask=True).to(DEVICE)
        with torch.no_grad():
            gen = md.generate(**enc, use_cache=True, min_length=0, max_length=256, num_beams=5, num_return_sequences=1)
        out += ip.postprocess_batch(tk.batch_decode(gen, skip_special_tokens=True, clean_up_tokenization_spaces=True), lang=tgt_code)
    return out

NLLB = "facebook/nllb-200-distilled-1.3B"
def nllb(sents, tgt_code, src_code="eng_Latn"):
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    if NLLB not in _cache:
        for k in list(_cache):
            del _cache[k]
        import gc; gc.collect(); torch.cuda.empty_cache()
        _cache[NLLB] = AutoModelForSeq2SeqLM.from_pretrained(NLLB, torch_dtype=torch.float16).to(DEVICE).eval()
    tk = AutoTokenizer.from_pretrained(NLLB, src_lang=src_code)
    out = []
    for i in range(0, len(sents), 16):
        enc = tk(sents[i:i + 16], return_tensors="pt", padding=True, truncation=True).to(DEVICE)
        with torch.no_grad():
            gen = _cache[NLLB].generate(**enc, forced_bos_token_id=tk.convert_tokens_to_ids(tgt_code), max_length=256, num_beams=5)
        out += tk.batch_decode(gen, skip_special_tokens=True)
    return out

def google(sents, tgt, src="en"):
    from google.cloud import translate_v3 as translate
    if IN_COLAB:
        from google.colab import auth; auth.authenticate_user()
    client, out = translate.TranslationServiceClient(), []
    for i in range(0, len(sents), 100):
        r = client.translate_text(request={"parent": f"projects/{GCP_PROJECT}/locations/global", "contents": sents[i:i + 100],
                                           "mime_type": "text/plain", "source_language_code": src, "target_language_code": tgt})
        out += [t.translated_text for t in r.translations]
    return out

def run_system(system, sents, code, to_english=False):
    flores = LANGS[code][1]
    if system == "google":
        return google(sents, "en" if to_english else code, src=code if to_english else "en")
    fn = indictrans2 if system == "indictrans2" else nllb
    return fn(sents, "eng_Latn" if to_english else flores, src_code=flores if to_english else "eng_Latn")

# %%
mt_file = os.path.join(MI, "mt_outputs.csv")
MT = pd.read_csv(mt_file) if os.path.exists(mt_file) else pd.DataFrame()
done = set(MT.system_id) if len(MT) else set()
en = S.en.tolist()
for system in SYSTEMS:
    for code in LANGS:
        sid = f"{system}|{code}"
        if sid in done:
            continue
        hyp = run_system(system, en, code)
        back = run_system(system, hyp, code, to_english=True)
        part = S[["item_id", "sent_id", "en"]].copy()
        part["system_id"], part["system"], part["lang"], part["mt"], part["back_en"] = sid, system, code, hyp, back
        MT = pd.concat([MT, part], ignore_index=True); MT.to_csv(mt_file, index=False)
        print("done", sid)

# %% [markdown]
# ## 3. Automatic safety checks → Table 8

# %%
MT["en"], MT["mt"], MT["back_en"] = MT.en.astype(str), MT.mt.fillna("").astype(str), MT.back_en.fillna("").astype(str)
tm = [T.target_marker_check(e, m, l) for e, m, l in zip(MT.en, MT.mt, MT.lang)]
MT["tgt_flag"] = [f for f, _ in tm]
MT["tgt_negation_lost"] = ["negation_lost" in r for _, r in tm]
MT["tgt_laterality"] = [any(x in r for x in ("left_lost", "right_lost", "laterality_added")) for _, r in tm]
bt = [T.backtranslation_flag(e, b) for e, b in zip(MT.en, MT.back_en)]
MT["bt_flag"] = [f for f, _ in bt]
MT["any_auto_flag"] = MT.tgt_flag | MT.bt_flag
src_neg = MT.en.str.contains(T.SRC_NEG); src_lat = MT.en.str.contains(T.SRC_LEFT) | MT.en.str.contains(T.SRC_RIGHT)
MT.to_csv(os.path.join(MI, "mt_outputs_checked.csv"), index=False)

rows = []
for (system, code), d in MT.groupby(["system", "lang"]):
    d = d.sort_values(["item_id", "sent_id"]).reset_index(drop=True)
    sneg, slat = d.en.str.contains(T.SRC_NEG).values, (d.en.str.contains(T.SRC_LEFT) | d.en.str.contains(T.SRC_RIGHT)).values
    pct = lambda v: stats.fmt_ci(*stats.bootstrap_ci(lambda i, v=np.asarray(v, float): 100 * v[i].mean(), len(v), groups=None), digits=1)
    rep_flag = d.groupby("item_id").any_auto_flag.max().values
    E, B = d.en.tolist(), d.back_en.tolist()
    rt = stats.bootstrap_ci(lambda i: sacrebleu.corpus_chrf([B[k] for k in i], [[E[k] for k in i]], word_order=2).score, len(E), n_boot=300)
    rows.append({"system": system, "lang": code, "sentences": len(d),
                 "negation lost, % of negated sentences (95% CI)": pct(d.tgt_negation_lost.values[sneg]),
                 "laterality problem, % of left/right sentences (95% CI)": pct(d.tgt_laterality.values[slat]),
                 "back-translation flag, % of sentences (95% CI)": pct(d.bt_flag.values),
                 "reports with any automatic flag (%)": round(100 * rep_flag.mean(), 1),
                 "round-trip chrF++ (95% CI)": stats.fmt_ci(*rt, digits=1)})
t8 = pd.DataFrame(rows); t8.to_csv(os.path.join(OUT, "tables", "table8_automatic_safety.csv"), index=False)
t8

# %%
# Pairwise system comparison on sentence-level automatic flags (McNemar, paired by sentence), per language
tests = []
for code in LANGS:
    W = MT[MT.lang == code].pivot_table(index=["item_id", "sent_id"], columns="system", values="any_auto_flag", aggfunc="first")
    for i, a in enumerate(SYSTEMS):
        for b in SYSTEMS[i + 1:]:
            x, y = W[a].astype(bool).values, W[b].astype(bool).values
            tests.append({"lang": code, "comparison": f"{a} vs {b}", f"flagged % ({a})": round(100 * x.mean(), 1),
                          f"flagged % ({b})": round(100 * y.mean(), 1), "p (McNemar)": stats.mcnemar_exact(int((x & ~y).sum()), int((~x & y).sum()))})
sig = pd.DataFrame(tests)
if len(sig):
    sig["p (Holm)"] = stats.holm(sig["p (McNemar)"].values)
sig.to_csv(os.path.join(OUT, "tables", "table8_significance.csv"), index=False)
sig

# %% [markdown]
# ## 4. Blinded Tamil checking sheets for the two annotators
# Every sentence of N_AUDIT reports × every system, in random order, with a neutral system code.
# Keep `audit_key.csv` away from the annotators.

# %%
ERR = ["negation_changed", "left_right_changed", "size_or_severity_changed", "finding_or_sentence_missing",
       "meaning_changed_other", "grammar_or_fluency", "comment"]
rng = np.random.default_rng(7)
items = sorted(rng.choice(S.item_id.unique(), size=min(N_AUDIT, S.item_id.nunique()), replace=False))
d = MT[(MT.lang == "ta") & MT.item_id.isin(items)].copy()
codes = {s: f"S{i + 1}" for i, s in enumerate(rng.permutation(sorted(d.system.unique())))}
d["system_code"] = d.system.map(codes)
pd.DataFrame({"system": list(codes), "system_code": list(codes.values())}).to_csv(os.path.join(MI, "audit_key.csv"), index=False)
sheet = d.sample(frac=1, random_state=11)[["item_id", "sent_id", "en", "system_code", "mt"]].rename(columns={"mt": "tamil_translation"})
for c in ERR:
    sheet[c] = ""
for a in ["A1", "A2"]:
    sheet.to_excel(os.path.join(MI, f"audit_ta_{a}.xlsx"), index=False)
print(len(sheet), "rows per annotator; files:", os.path.join(MI, "audit_ta_A1.xlsx"), "and _A2.xlsx")
