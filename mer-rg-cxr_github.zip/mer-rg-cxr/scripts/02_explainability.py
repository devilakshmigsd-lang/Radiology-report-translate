# %% [markdown]
# # 02 · Do the heatmaps point to the disease? (Grad-CAM vs LIME) — Google Colab, GPU
#
# Uses the EfficientNet-B3 seed-0 findings model from notebook 01 and the NIH expert boxes of
# **test-split patients only**.
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `tables/table7_xai.csv` | **Table 7** |
# | `tables/table7b_xai_per_finding.csv`, `tables/table7c_randomisation.csv` | Section 4.3 / Supplementary |
# | `figures/fig4_xai_examples.png` | **Figure 4** |
#
# Time: about 2–4 h on a T4 (LIME takes most of it). Results are saved every 50 boxes, so after a disconnect
# just *Run all* again.

# %%
import os, sys, time, copy
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
sys.path.insert(0, PROJECT)
os.system("pip install -q timm grad-cam lime opencv-python-headless scikit-image")

# %%
import numpy as np, pandas as pd, torch, cv2
import matplotlib.pyplot as plt
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
from lime import lime_image
from lime.wrappers.scikit_image import SegmentationAlgorithm
from merrg.labels import NIH_LABELS
from merrg import xai, stats
from merrg.store import concat_stores, map_box
from merrg.vision import build_model, to_model_input, gradcam_target_layer, cascading_modules, reinit_

NAME, SEED = "efficientnet_b3", 0
FAST = True              # True = LIME on a random 200 boxes (500 perturbations), randomisation test on 30 images
LIME_SAMPLES, LIME_SEGMENTS = (500 if FAST else 1000), 50
N_RANDOMISATION, N_LIME_RANDOMISATION = (30, 10) if FAST else (100, 50)
N_LIME_BOXES = 200 if FAST else None   # Grad-CAM and the centre prior are always computed on every box
TOL_ORIGINAL_PX = 15          # pointing-game tolerance in original 1024-px pixels (Zhang et al.)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

concat_stores([os.path.join(STORE, f"nih_part{k:02d}") for k in range(1, 13)], os.path.join(LOCAL, "nih"), delete_parts=False)
ARR = np.load(os.path.join(LOCAL, "nih.npy"), mmap_mode="r")
model = build_model(NAME, len(NIH_LABELS), pretrained=False)
model.load_state_dict(torch.load(os.path.join(OUT, "models", f"{NAME}_seed{SEED}.pt"), map_location=DEVICE))
model.eval().to(DEVICE)
boxes = pd.read_csv(os.path.join(OUT, "splits", "nih_bbox_test.csv"))
boxes = boxes[boxes["Finding Label"].isin(NIH_LABELS)].reset_index(drop=True)
print(len(boxes), "boxes on", boxes["Image Index"].nunique(), "test images")
LIME_IDS = set(boxes.sample(N_LIME_BOXES, random_state=0).index) if N_LIME_BOXES else set(boxes.index)

# %%
def prob_fn(m):
    """Batch of HxWx3 images in [0,1] -> sigmoid probabilities (N, 14)."""
    def f(batch):
        x = np.stack([to_model_input(np.asarray(b)[..., 0].astype(np.float32)) for b in batch])
        out = []
        with torch.no_grad():
            for i in range(0, len(x), 64):
                out.append(torch.sigmoid(m(torch.from_numpy(x[i:i + 64]).to(DEVICE))).float().cpu().numpy())
        return np.concatenate(out)
    return f

def gradcam_map(m, img01, k):
    x = torch.from_numpy(to_model_input(img01))[None].to(DEVICE)
    with GradCAM(model=m, target_layers=[gradcam_target_layer(m, NAME)]) as cam:
        return cam(input_tensor=x, targets=[ClassifierOutputTarget(k)])[0]

explainer = lime_image.LimeImageExplainer(random_state=0)
segmenter = SegmentationAlgorithm("slic", n_segments=LIME_SEGMENTS, compactness=10, sigma=1, random_seed=0)

def lime_map(m, img01, k):
    rgb = np.repeat(img01[..., None], 3, axis=2).astype(np.double)
    e = explainer.explain_instance(rgb, prob_fn(m), labels=(k,), top_labels=None, hide_color=0,
                                   num_samples=LIME_SAMPLES, segmentation_fn=segmenter, batch_size=64)
    return xai.lime_to_map(e.segments, e.local_exp[k])

# %% [markdown]
# ## 1. Localisation and deletion metrics (checkpointed)

# %%
res_file = os.path.join(OUT, "tables", "xai_per_box.csv")
res = pd.read_csv(res_file) if os.path.exists(res_file) else pd.DataFrame()
done_ids = set(res.box_id) if len(res) else set()
size = ARR.shape[1]
prior = xai.centre_prior((size, size))
rows = []
for i, r in boxes.iterrows():
    if i in done_ids:
        continue
    img = np.asarray(ARR[r.global_row], dtype=np.float32) / 255.0
    box = map_box((r.x, r.y, r.w, r.h), r.scale, r.pad_x, r.pad_y)
    tol = TOL_ORIGINAL_PX * r.scale
    k = NIH_LABELS.index(r["Finding Label"])
    t0 = time.time(); g = gradcam_map(model, img, k); tg = time.time() - t0
    use_lime = i in LIME_IDS
    t0 = time.time(); l = lime_map(model, img, k) if use_lime else None; tl = time.time() - t0
    pred_one = lambda b, k=k: prob_fn(model)(b)[:, k]
    img3 = np.repeat(img[..., None], 3, axis=2)
    for method, sal, sec in [("Grad-CAM", g, tg), ("LIME", l, tl), ("Centre prior", prior, 0.0)]:
        if sal is None:
            continue
        rows.append({"box_id": i, "image": r["Image Index"], "finding": r["Finding Label"], "method": method,
                     "hit": xai.pointing_game_hit(sal, box, tolerance=tol), "iou": xai.iou_at_percentile(sal, box, 80),
                     "deletion_auc": xai.deletion_auc(pred_one, img3, sal, steps=20) if method != "Centre prior" else np.nan,
                     "seconds": sec})
    if len(rows) >= 150 or i == len(boxes) - 1:      # save roughly every 50 boxes
        res = pd.concat([res, pd.DataFrame(rows)], ignore_index=True); res.to_csv(res_file, index=False); rows = []
        print(f"{res.box_id.nunique()}/{len(boxes)} boxes done")
if rows:
    res = pd.concat([res, pd.DataFrame(rows)], ignore_index=True); res.to_csv(res_file, index=False)

# %% [markdown]
# ## 2. Cascading model-parameter randomisation (Adebayo et al. 2018)

# %%
rand_file = os.path.join(OUT, "tables", "xai_randomisation_raw.csv")
if not os.path.exists(rand_file):
    sub = boxes.drop_duplicates("Image Index").sample(min(N_RANDOMISATION, boxes["Image Index"].nunique()), random_state=0)
    n_stages = len(cascading_modules(model)); rr = []
    for n_img, (_, r) in enumerate(sub.iterrows()):
        img = np.asarray(ARR[r.global_row], dtype=np.float32) / 255.0
        k = NIH_LABELS.index(r["Finding Label"])
        g0 = gradcam_map(model, img, k)
        l0 = lime_map(model, img, k) if n_img < N_LIME_RANDOMISATION else None
        m = copy.deepcopy(model)
        for depth, (mname, mod) in enumerate(cascading_modules(m), start=1):   # modules of the COPY
            reinit_(mod, seed=depth)
            rr.append({"image": r["Image Index"], "depth": depth, "layer": mname, "method": "Grad-CAM", "ssim": xai.map_ssim(g0, gradcam_map(m, img, k))})
        if l0 is not None:
            rr.append({"image": r["Image Index"], "depth": n_stages, "layer": "all", "method": "LIME", "ssim": xai.map_ssim(l0, lime_map(m, img, k))})
        del m
    pd.DataFrame(rr).to_csv(rand_file, index=False)
rr = pd.read_csv(rand_file)
rr.groupby(["method", "depth", "layer"]).ssim.mean().reset_index().to_csv(os.path.join(OUT, "tables", "table7c_randomisation.csv"), index=False)

# %% [markdown]
# ## 3. Table 7

# %%
def ci(v):
    v = np.asarray(v, dtype=float); p, lo, hi = stats.bootstrap_ci(lambda i: np.nanmean(v[i]), len(v)); return stats.fmt_ci(p, lo, hi)
full = rr[rr.depth == rr.depth.max()].groupby("method").ssim.mean()
t7 = []
for method, d in res.groupby("method", sort=False):
    t7.append({"Method": method, "Pointing game hit rate (%)": ci(d.hit.astype(float) * 100), "Mean IoU": ci(d.iou),
               "Deletion AUC (lower is better)": ci(d.deletion_auc) if d.deletion_auc.notna().any() else "-",
               "SSIM after full randomisation (lower is better)": f"{full[method]:.3f}" if method in full.index else "-",
               "Seconds per image": f"{d.seconds.mean():.2f}"})
t7 = pd.DataFrame(t7); t7.to_csv(os.path.join(OUT, "tables", "table7_xai.csv"), index=False)
per = res.pivot_table(index="finding", columns="method", values="hit", aggfunc="mean").mul(100).round(1)
per["n boxes"] = res[res.method == "Grad-CAM"].groupby("finding").size()
per.to_csv(os.path.join(OUT, "tables", "table7b_xai_per_finding.csv"))
both = set(res[res.method == "LIME"].box_id)
gh = res[(res.method == "Grad-CAM") & res.box_id.isin(both)].sort_values("box_id").hit.values.astype(bool)
lh = res[res.method == "LIME"].sort_values("box_id").hit.values.astype(bool)
print("McNemar Grad-CAM vs LIME (hit): p =", stats.mcnemar_exact(int((~gh & lh).sum()), int((gh & ~lh).sum())))
t7

# %% [markdown]
# ## 4. Figure 4 — a success and a failure case

# %%
g_res = res[(res.method == "Grad-CAM") & res.box_id.isin(set(res[res.method == "LIME"].box_id))]
picks = [g_res[g_res.hit].box_id.iloc[0] if g_res.hit.any() else g_res.box_id.iloc[0],
         g_res[~g_res.hit].box_id.iloc[0] if (~g_res.hit).any() else g_res.box_id.iloc[-1]]
fig, ax = plt.subplots(2, 3, figsize=(11, 7.5))
for row, bid in enumerate(picks):
    r = boxes.loc[bid]; img = np.asarray(ARR[r.global_row], dtype=np.float32) / 255.0
    k = NIH_LABELS.index(r["Finding Label"]); box = map_box((r.x, r.y, r.w, r.h), r.scale, r.pad_x, r.pad_y)
    hit = bool(g_res[g_res.box_id == bid].hit.iloc[0])
    for col, (title, ov) in enumerate([("Image + expert box", None), ("Grad-CAM", gradcam_map(model, img, k)), ("LIME", lime_map(model, img, k))]):
        a = ax[row, col]; a.imshow(img, cmap="gray")
        if ov is not None:
            a.imshow(ov, cmap="jet", alpha=0.4)
        a.add_patch(plt.Rectangle(box[:2], box[2], box[3], fill=False, ec="lime", lw=2))
        a.set_title(f"{r['Finding Label']}: {title}" + ("" if col else (" (Grad-CAM hit)" if hit else " (Grad-CAM miss)")), fontsize=9); a.axis("off")
plt.tight_layout(); plt.savefig(os.path.join(OUT, "figures", "fig4_xai_examples.png"), dpi=300)
