# %% [markdown]
# # 05 · Human Tamil audit: analysis (no GPU needed)
#
# Run after both annotators return their sheets, saved as
# `outputs/medindic/audit_ta_A1_returned.xlsx` and `outputs/medindic/audit_ta_A2_returned.xlsx`.
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `tables/table9_tamil_audit.csv` | **Table 9** (critical errors per 100 sentences, by system) |
# | `tables/table9b_error_types.csv`, `figures/fig5_tamil_errors.png` | **Figure 5** |
# | `tables/table10_auto_check_validity.csv` | **Table 10** (do the automatic checks find the human-found errors?) |
# | `tables/tamil_agreement_and_tests.csv` | κ and p-values quoted in Section 4.5 |

# %%
import os, sys
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
OUT = os.path.join(PROJECT, "outputs"); MI = os.path.join(OUT, "medindic")
sys.path.insert(0, PROJECT)
for d in [os.path.join(OUT, "figures"), os.path.join(OUT, "tables")]:
    os.makedirs(d, exist_ok=True)
os.system("pip install -q openpyxl")

import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import cohen_kappa_score
from merrg import stats

CRIT = ["negation_changed", "left_right_changed", "size_or_severity_changed", "finding_or_sentence_missing", "meaning_changed_other"]
MINOR = ["grammar_or_fluency"]
key = pd.read_csv(os.path.join(MI, "audit_key.csv"))
checked = pd.read_csv(os.path.join(MI, "mt_outputs_checked.csv"))
checked = checked[checked.lang == "ta"]

def load(a):
    d = pd.read_excel(os.path.join(MI, f"audit_ta_{a}_returned.xlsx"))
    for c in CRIT + MINOR:
        d[c] = pd.to_numeric(d[c], errors="coerce").fillna(0).clip(0, 1).astype(int)
    d["any_critical"] = d[CRIT].max(axis=1)
    d = d.merge(key, on="system_code")
    return d.sort_values(["system", "item_id", "sent_id"]).reset_index(drop=True)

a1, a2 = load("A1"), load("A2")
assert (a1[["system", "item_id", "sent_id"]].values == a2[["system", "item_id", "sent_id"]].values).all(), "sheets do not line up"
cons = a1[["system", "item_id", "sent_id", "en"]].copy()
for c in CRIT + MINOR + ["any_critical"]:
    cons[c] = np.maximum(a1[c], a2[c])          # conservative: an error counts if either annotator marked it
cons = cons.merge(checked[["system", "item_id", "sent_id", "tgt_flag", "tgt_negation_lost", "tgt_laterality", "bt_flag", "any_auto_flag"]],
                  on=["system", "item_id", "sent_id"])

# %% [markdown]
# ## Table 9 — critical errors per 100 sentences (consensus) and agreement

# %%
t9, tests = [], []
for system, d in cons.groupby("system"):
    p, lo, hi = stats.bootstrap_ci(lambda i, v=d.any_critical.values: 100 * v[i].mean(), len(d), groups=d.item_id.values)
    r1 = 100 * a1[a1.system == system].any_critical.mean(); r2 = 100 * a2[a2.system == system].any_critical.mean()
    t9.append({"System": system, "Sentences": len(d), "Critical errors per 100 sentences (95% CI)": stats.fmt_ci(p, lo, hi, 1),
               "Annotator 1": round(r1, 1), "Annotator 2": round(r2, 1),
               "Reports with ≥1 critical error (%)": round(100 * d.groupby("item_id").any_critical.max().mean(), 1),
               "Grammar/fluency issues per 100 sentences": round(100 * d.grammar_or_fluency.mean(), 1)})
t9 = pd.DataFrame(t9); t9.to_csv(os.path.join(OUT, "tables", "table9_tamil_audit.csv"), index=False)
tests.append({"test": "Cohen kappa, any critical error (sentence level)", "value": round(cohen_kappa_score(a1.any_critical, a2.any_critical), 3), "p": np.nan})
for c in CRIT:
    if a1[c].nunique() > 1 or a2[c].nunique() > 1:
        tests.append({"test": f"Cohen kappa, {c}", "value": round(cohen_kappa_score(a1[c], a2[c]), 3), "p": np.nan})
W = cons.pivot_table(index=["item_id", "sent_id"], columns="system", values="any_critical", aggfunc="first")
systems = list(W.columns)
for i, a in enumerate(systems):
    for b in systems[i + 1:]:
        x, y = W[a].astype(bool).values, W[b].astype(bool).values
        tests.append({"test": f"McNemar {a} vs {b} (any critical)", "value": f"{100*x.mean():.1f} vs {100*y.mean():.1f}",
                      "p": stats.mcnemar_exact(int((x & ~y).sum()), int((~x & y).sum()))})
tg = pd.DataFrame(tests)
m = tg.p.notna()
if m.any():
    tg.loc[m, "p (Holm)"] = stats.holm(tg.loc[m, "p"].values)
tg.to_csv(os.path.join(OUT, "tables", "tamil_agreement_and_tests.csv"), index=False)
t9

# %% [markdown]
# ## Figure 5 — error types per system

# %%
ty = cons.groupby("system")[CRIT + MINOR].mean().mul(100).round(2)
ty.to_csv(os.path.join(OUT, "tables", "table9b_error_types.csv"))
nice = {"negation_changed": "Negation", "left_right_changed": "Left/right", "size_or_severity_changed": "Size/severity",
        "finding_or_sentence_missing": "Omission", "meaning_changed_other": "Other meaning change"}
ax = ty[CRIT].rename(columns=nice).plot.bar(stacked=True, figsize=(7, 4.5), width=0.6)
ax.set_ylabel("Critical errors per 100 sentences"); ax.set_xlabel(""); ax.set_title("Tamil: critical translation errors by type")
plt.xticks(rotation=0); plt.tight_layout(); plt.savefig(os.path.join(OUT, "figures", "fig5_tamil_errors.png"), dpi=300)

# %% [markdown]
# ## Table 10 — do the automatic checks catch what the annotators found?

# %%
def acc(y, f, label):
    y, f = np.asarray(y, bool), np.asarray(f, bool)
    sens = stats.bootstrap_ci(lambda i: f[i][y[i]].mean() if y[i].any() else np.nan, len(y)) if y.any() else (np.nan,) * 3
    return {"Check": label, "Human-found errors (n)": int(y.sum()), "Sentences flagged (%)": round(100 * f.mean(), 1),
            "Sensitivity (%) (95% CI)": stats.fmt_ci(*(100 * np.array(sens)), 1) if y.any() else "-",
            "Specificity (%)": round(100 * (~f[~y]).mean(), 1) if (~y).any() else np.nan,
            "Errors missed (n)": int((y & ~f).sum())}
t10 = pd.DataFrame([
    acc(cons.negation_changed, cons.tgt_negation_lost, "Target-language negation check vs human negation errors"),
    acc(cons.left_right_changed, cons.tgt_laterality, "Target-language left/right check vs human left/right errors"),
    acc(cons.any_critical, cons.bt_flag, "Back-translation check vs any human critical error"),
    acc(cons.any_critical, cons.any_auto_flag, "Either automatic check vs any human critical error"),
])
t10.to_csv(os.path.join(OUT, "tables", "table10_auto_check_validity.csv"), index=False)
t10
