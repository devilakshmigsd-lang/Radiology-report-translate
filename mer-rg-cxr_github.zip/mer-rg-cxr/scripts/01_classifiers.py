# %% [markdown]
# # 01 · Finding and tuberculosis classifiers (Google Colab, GPU)
#
# Trains EfficientNet-B3, ResNet-50 and DenseNet-121 (3 seeds each) for the 14 NIH findings and for TB.
#
# **Runtime → Change runtime type → GPU** (T4 on free Colab; L4/A100 on Colab Pro).
# **Disconnects are fine:** every epoch is saved to Drive. Re-open the notebook, *Run all*, and it continues
# where it stopped. Finished runs are skipped.
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `tables/table4_classification.csv`, `tables/table4_significance.csv` | **Table 4** |
# | `tables/tableS3_per_label_auroc.csv` | Supplementary Table S3 |
# | `figures/fig2_roc.png`, `figures/figS1_training_curves.png` | **Figure 2**, Supplementary Figure S1 |
# | `models/…` | used by notebooks 02 and 03 |
#
# Rough time per findings run (10 epochs at 224 px): T4 ≈ 2–3 h, L4 ≈ 1–1.5 h, A100 ≈ 40 min. Nine runs plus TB.
# Set `QUICK = True` the first time (about 20 minutes) to check that everything works.

# %%
import os, sys, json
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
sys.path.insert(0, PROJECT)
for d in ["models", "preds", "tables", "figures"]:
    os.makedirs(os.path.join(OUT, d), exist_ok=True)
os.system("pip install -q timm opencv-python-headless")

# %%
import numpy as np, pandas as pd, torch
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve
from merrg.labels import NIH_LABELS
from merrg import stats
from merrg.store import concat_stores
from merrg.vision import ArrayDataset, TrainConfig, build_model, train_model, predict, seed_everything, macro_auc, load_store_local

QUICK = False            # True = 3 % of the data, 1 seed, 1 epoch: a 20-minute end-to-end test. Outputs go to outputs_quick/
FAST = True              # True = ~1.5 h on a T4: EfficientNet-B3 (3 epochs) + ResNet-50 (1 epoch), one seed.
                         # False = full plan: 3 models x 3 seeds x 10 epochs (several days on free Colab).
MODELS = ["efficientnet_b3", "resnet50"] if FAST else ["efficientnet_b3", "resnet50", "densenet121"]
SEEDS = [0] if (QUICK or FAST) else [0, 1, 2]
EPOCHS = {"efficientnet_b3": 3, "resnet50": 1} if FAST else {}
TB_EPOCHS = 5 if FAST else 15
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
assert DEVICE == "cuda", "No GPU: Runtime -> Change runtime type -> GPU"
print(torch.cuda.get_device_name(0))
if QUICK:
    OUT = os.path.join(PROJECT, "outputs_quick")
    for d in ["models", "preds", "tables", "figures"]:
        os.makedirs(os.path.join(OUT, d), exist_ok=True)

# assemble a local working copy of the NIH store once per session (~5 min), and load the others
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
concat_stores([os.path.join(STORE, f"nih_part{k:02d}") for k in range(1, 13)], os.path.join(LOCAL, "nih"), delete_parts=False)
NIH_ARR = np.load(os.path.join(LOCAL, "nih.npy"), mmap_mode="r")
TB_ARR = load_store_local(os.path.join(STORE, "tb"), LOCAL)
HAS_VINDR = os.path.exists(os.path.join(STORE, "vindr.npy"))
V_ARR = load_store_local(os.path.join(STORE, "vindr"), LOCAL) if HAS_VINDR else None

nih = pd.read_csv(os.path.join(PROJECT, "outputs", "splits", "nih_split.csv"))
tb = pd.read_csv(os.path.join(PROJECT, "outputs", "splits", "tb_split.csv"))
vindr = pd.read_csv(os.path.join(PROJECT, "outputs", "splits", "vindr_labels.csv")) if HAS_VINDR else None
if QUICK:
    nih = nih.groupby("split", group_keys=False).apply(lambda d: d.sample(frac=0.03, random_state=0))
    tb = tb.groupby("split", group_keys=False).apply(lambda d: d.sample(frac=0.2, random_state=0))
part = {s: nih[nih.split == s].reset_index(drop=True) for s in ["train", "val", "test"]}
tbp = {s: tb[tb.split == s].reset_index(drop=True) for s in ["train", "val", "test", "external"]}
{s: len(d) for s, d in part.items()}

# %% [markdown]
# ## 1. Findings models (14 labels)

# %%
def nds(df, train=False, seed=0):
    return ArrayDataset(NIH_ARR, df.global_row.values, df[NIH_LABELS].values, train=train, seed=seed)

ytr = part["train"][NIH_LABELS].values
pos_weight = ((len(ytr) - ytr.sum(0)) / np.maximum(ytr.sum(0), 1)).tolist()
hist_file = os.path.join(OUT, "tables", "training_history_findings.csv")
for name in MODELS:
    for seed in SEEDS:
        tag = f"{name}_seed{seed}"
        test_file = os.path.join(OUT, "preds", f"nih_test_{tag}.npy")
        if os.path.exists(test_file):
            print("finished:", tag); continue
        print("=== training", tag)
        seed_everything(seed)
        model = build_model(name, len(NIH_LABELS))
        cfg = TrainConfig(epochs=1 if QUICK else EPOCHS.get(name, 10), pos_weight=pos_weight)
        h = train_model(model, nds(part["train"], True, seed), nds(part["val"]), cfg, os.path.join(OUT, "models", f"{tag}.pt"), DEVICE)
        old = pd.read_csv(hist_file) if os.path.exists(hist_file) else pd.DataFrame()
        old = old[~((old.get("model") == name) & (old.get("seed") == seed))] if len(old) else old
        pd.concat([old, pd.DataFrame(h).assign(model=name, seed=seed)]).to_csv(hist_file, index=False)
        np.save(os.path.join(OUT, "preds", f"nih_val_{tag}.npy"), predict(model, nds(part["val"]), device=DEVICE))
        if HAS_VINDR:
            np.save(os.path.join(OUT, "preds", f"vindr_{tag}.npy"), predict(model, ArrayDataset(V_ARR, vindr.row.values), device=DEVICE))
        np.save(test_file, predict(model, nds(part["test"]), device=DEVICE))
        del model; torch.cuda.empty_cache()

# %% [markdown]
# ## 2. Tuberculosis models (binary)

# %%
def tds(df, train=False, seed=0):
    return ArrayDataset(TB_ARR, df.row.values, df[["tb"]].values, train=train, seed=seed)

ytb = tbp["train"].tb.values
tb_pw = [float((len(ytb) - ytb.sum()) / max(ytb.sum(), 1))]
for name in MODELS:
    for seed in SEEDS:
        tag = f"tb_{name}_seed{seed}"
        if os.path.exists(os.path.join(OUT, "preds", f"{tag}_external.npy")):
            print("finished:", tag); continue
        print("=== training", tag)
        seed_everything(seed)
        model = build_model(name, 1)
        cfg = TrainConfig(epochs=1 if QUICK else TB_EPOCHS, pos_weight=tb_pw, batch_size=32)
        train_model(model, tds(tbp["train"], True, seed), tds(tbp["val"]), cfg, os.path.join(OUT, "models", f"{tag}.pt"), DEVICE)
        for s in ["val", "test", "external"]:
            np.save(os.path.join(OUT, "preds", f"{tag}_{s}.npy"), predict(model, tds(tbp[s]), device=DEVICE)[:, 0])
        del model; torch.cuda.empty_cache()

# %% [markdown]
# ## 3. Decision thresholds (validation Youden J, then frozen)

# %%
yv = part["val"][NIH_LABELS].values
for name in MODELS:
    for seed in SEEDS:
        tag = f"{name}_seed{seed}"
        pv = np.load(os.path.join(OUT, "preds", f"nih_val_{tag}.npy"))
        json.dump({lab: stats.youden_threshold(yv[:, k], pv[:, k]) if 0 < yv[:, k].sum() < len(yv) else 0.5 for k, lab in enumerate(NIH_LABELS)},
                  open(os.path.join(OUT, "models", f"thresholds_{tag}.json"), "w"), indent=1)
        ptb = np.load(os.path.join(OUT, "preds", f"tb_{tag}_val.npy"))
        json.dump({"tb": stats.youden_threshold(tbp["val"].tb.values, ptb)}, open(os.path.join(OUT, "models", f"thresholds_tb_{tag}.json"), "w"))

# %% [markdown]
# ## 4. Table 4 — mean ± SD over seeds and patient-level bootstrap 95 % CI

# %%
yt, groups = part["test"][NIH_LABELS].values, part["test"]["Patient ID"].values
v_cols = [c for c in vindr.columns if c not in ("image_id", "row")] if HAS_VINDR else []
yx = vindr[v_cols].values if HAS_VINDR else None
ye, yi = tbp["external"].tb.values, tbp["test"].tb.values

def vindr_probs(p):
    out = []
    for c in v_cols:
        out.append(np.maximum(p[:, NIH_LABELS.index("Nodule")], p[:, NIH_LABELS.index("Mass")]) if c == "Nodule_or_Mass" else p[:, NIH_LABELS.index(c)])
    return np.stack(out, 1)

load = lambda f: np.load(os.path.join(OUT, "preds", f))
sd = lambda xs: f"{np.mean(xs):.3f} ± {np.std(xs):.3f}" if len(xs) > 1 else f"{xs[0]:.3f}"
NB = 200 if QUICK else 1000
rows, per_label, P = [], [], {}
for name in MODELS:
    pt = [load(f"nih_test_{name}_seed{s}.npy") for s in SEEDS]
    px = [vindr_probs(load(f"vindr_{name}_seed{s}.npy")) for s in SEEDS] if HAS_VINDR else []
    tbi = [load(f"tb_{name}_seed{s}_test.npy") for s in SEEDS]
    tbe = [load(f"tb_{name}_seed{s}_external.npy") for s in SEEDS]
    thr = [json.load(open(os.path.join(OUT, "models", f"thresholds_tb_{name}_seed{s}.json")))["tb"] for s in SEEDS]
    P[name] = dict(pt=pt, px=px, tbi=tbi, tbe=tbe)
    ss = np.array([((p >= t)[ye == 1].mean(), (p < t)[ye == 0].mean()) for p, t in zip(tbe, thr)])
    ci_int = stats.bootstrap_ci(lambda i: np.mean([macro_auc(yt[i], p[i]) for p in pt]), len(yt), groups=groups, n_boot=NB)
    ci_tb = stats.bootstrap_ci(lambda i: np.mean([roc_auc_score(ye[i], p[i]) for p in tbe]), len(ye), n_boot=NB)
    row = {"Model": name, "Params (M)": round(sum(q.numel() for q in build_model(name, 14, pretrained=False).parameters()) / 1e6, 1),
           "Internal macro AUROC": sd([macro_auc(yt, p) for p in pt]), "Internal 95% CI": f"{ci_int[1]:.3f}-{ci_int[2]:.3f}"}
    if HAS_VINDR:
        ci_ext = stats.bootstrap_ci(lambda i: np.mean([macro_auc(yx[i], p[i]) for p in px]), len(yx), n_boot=NB)
        row.update({"External (VinDr) macro AUROC": sd([macro_auc(yx, p) for p in px]), "External 95% CI": f"{ci_ext[1]:.3f}-{ci_ext[2]:.3f}"})
    row.update({"TB AUROC internal": sd([roc_auc_score(yi, p) for p in tbi]), "TB AUROC external": sd([roc_auc_score(ye, p) for p in tbe]),
                "TB external 95% CI": f"{ci_tb[1]:.3f}-{ci_tb[2]:.3f}", "TB sensitivity (external)": sd(ss[:, 0]), "TB specificity (external)": sd(ss[:, 1])})
    rows.append(row)
    pm = np.mean(pt, 0)
    for k, lab in enumerate(NIH_LABELS):
        if 0 < yt[:, k].sum() < len(yt):
            a, lo, hi = stats.bootstrap_ci(lambda i: roc_auc_score(yt[i, k], pm[i, k]), len(yt), groups=groups, n_boot=NB)
            per_label.append({"Model": name, "Label": lab, "Positives (test)": int(yt[:, k].sum()), "AUROC (95% CI)": stats.fmt_ci(a, lo, hi)})
t4 = pd.DataFrame(rows); t4.to_csv(os.path.join(OUT, "tables", "table4_classification.csv"), index=False)
pd.DataFrame(per_label).to_csv(os.path.join(OUT, "tables", "tableS3_per_label_auroc.csv"), index=False)
t4.T

# %%
ref, tests = "efficientnet_b3", []
for other in [m for m in MODELS if m != ref]:
    a, b = np.mean(P[ref]["pt"], 0), np.mean(P[other]["pt"], 0)
    r = stats.paired_bootstrap(lambda i: macro_auc(yt[i], a[i]), lambda i: macro_auc(yt[i], b[i]), len(yt), groups=groups, n_boot=NB)
    tests.append({"Comparison": f"{ref} vs {other}", "Metric": "internal macro AUROC (paired bootstrap)", "Difference": round(r["diff"], 4), "95% CI": f"{r['lower']:.4f}-{r['upper']:.4f}", "p": r["p"]})
    d = stats.delong_test(ye, np.mean(P[ref]["tbe"], 0), np.mean(P[other]["tbe"], 0))
    tests.append({"Comparison": f"{ref} vs {other}", "Metric": "TB external AUROC (DeLong)", "Difference": round(d["auc_a"] - d["auc_b"], 4), "95% CI": "", "p": d["p"]})
sig = pd.DataFrame(tests); sig["p (Holm)"] = stats.holm(sig.p.values)
sig.to_csv(os.path.join(OUT, "tables", "table4_significance.csv"), index=False)
sig

# %% [markdown]
# ## 5. Figure 2 (ROC curves) and Supplementary Figure S1 (training curves)

# %%
key = ["Cardiomegaly", "Effusion", "Pneumothorax", "Consolidation", "Atelectasis"]
fig, axes = plt.subplots(2, 3, figsize=(12, 8))
pm = np.mean(P[ref]["pt"], 0); pxm = np.mean(P[ref]["px"], 0) if HAS_VINDR else None
for ax, lab in zip(axes.ravel(), key + ["TB"]):
    if lab == "TB":
        curves = [("TBX11K (internal)", yi, np.mean(P[ref]["tbi"], 0)), ("Shenzhen + Montgomery (external)", ye, np.mean(P[ref]["tbe"], 0))]
    else:
        k = NIH_LABELS.index(lab); curves = [("NIH (internal)", yt[:, k], pm[:, k])]
        if HAS_VINDR and lab in v_cols:
            curves.append(("VinDr-CXR (external)", yx[:, v_cols.index(lab)], pxm[:, v_cols.index(lab)]))
    for nm, y, p in curves:
        if 0 < y.sum() < len(y):
            f, t, _ = roc_curve(y, p); ax.plot(f, t, label=f"{nm}  AUC {roc_auc_score(y, p):.3f}")
    ax.plot([0, 1], [0, 1], ls=":", c="grey"); ax.set_title(lab)
    ax.set_xlabel("1 - specificity"); ax.set_ylabel("Sensitivity"); ax.legend(fontsize=8, loc="lower right")
plt.tight_layout(); plt.savefig(os.path.join(OUT, "figures", "fig2_roc.png"), dpi=300)

hist = pd.read_csv(hist_file)
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
for (m, s), d in hist.groupby(["model", "seed"]):
    ax[0].plot(d.epoch, d.train_loss, alpha=.7, label=f"{m} s{s}"); ax[1].plot(d.epoch, d.val_macro_auc, alpha=.7)
ax[0].set_title("Training loss"); ax[1].set_title("Validation macro AUROC"); ax[0].legend(fontsize=6, ncol=3)
for a in ax: a.set_xlabel("Epoch")
plt.tight_layout(); plt.savefig(os.path.join(OUT, "figures", "figS1_training_curves.png"), dpi=300)
