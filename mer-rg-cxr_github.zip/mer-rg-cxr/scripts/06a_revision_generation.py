# %% [markdown]
# # 06a · Reviewer revision: classifier errors on IU X-Ray, label-mapping check, and a version that does not
# # confidently insert low-confidence findings (Google Colab, T4 GPU, about 45-60 min)
#
# Answers reviewer Issue 2 and the label-transfer comment:
# 1. Per-finding precision, recall, F1, AUROC, Brier score and calibration error of the classifier on the IU X-Ray
#    test split, with the NIH thresholds and with thresholds chosen on IU X-Ray validation studies.
# 2. Agreement between the MeSH-derived IU labels and CheXbert labels extracted from the same report text.
# 3. Two "confidence-gated" generators that do not assert low-confidence findings:
#    - gated_withhold: only findings above a high-precision threshold (chosen on IU validation) are asserted;
#    - gated_hedge: the same, and findings in the uncertain band are written as "X cannot be excluded."
#    Both are scored with the same metrics as Table 8, against the proposed system re-run in the same session.
# 4. Saves every generated report for the end-to-end translation test (notebook 06b).
#
# Everything is written to `outputs/revision/`. Run all cells; it resumes if interrupted.

# %%
import os, sys, json, glob, shutil
IN_COLAB = "google.colab" in sys.modules or bool(os.environ.get("MERRG_SUBPROCESS"))
if IN_COLAB and not os.environ.get("MERRG_SUBPROCESS"):
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
REV = os.path.join(OUT, "revision"); os.makedirs(REV, exist_ok=True)
sys.path.insert(0, PROJECT)
os.system("pip install -q timm opencv-python-headless f1chexbert radgraph pycocoevalcap nltk sacremoses openpyxl")

import numpy as np, pandas as pd, torch
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, cohen_kappa_score
from merrg.labels import NIH_LABELS, READABLE
from merrg import text as T, stats
from merrg.vision import build_model, ArrayDataset, predict, load_store_local

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
assert DEVICE == "cuda", "No GPU: Runtime -> Change runtime type -> T4 GPU"
NAME, SEED = "efficientnet_b3", 0
iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv")); iu["uid"] = iu.uid.astype(str)
Y = iu[NIH_LABELS].values.astype(int)
val, tst = (iu.split == "val").values, (iu.split == "test").values
print("IU studies:", len(iu), "| val", val.sum(), "| test", tst.sum())

# %% [markdown]
# ## 1. Classifier probabilities on IU X-Ray and three threshold sets

# %%
prob_file = os.path.join(REV, "iu_probs.npy")
if os.path.exists(prob_file):
    probs = np.load(prob_file)
else:
    model = build_model(NAME, len(NIH_LABELS), pretrained=False)
    model.load_state_dict(torch.load(os.path.join(OUT, "models", f"{NAME}_seed{SEED}.pt"), map_location=DEVICE))
    IU_ARR = load_store_local(os.path.join(STORE, "iu_frontal"), LOCAL)
    probs = predict(model.to(DEVICE), ArrayDataset(IU_ARR, iu.row.values), device=DEVICE)
    np.save(prob_file, probs); del model; torch.cuda.empty_cache()

nih_thr = json.load(open(os.path.join(OUT, "models", f"thresholds_{NAME}_seed{SEED}.json")))
t_nih = np.array([nih_thr[l] for l in NIH_LABELS])

def best_f1_threshold(p, y):
    grid = np.unique(np.quantile(p, np.linspace(0, 1, 201)))
    f1s = [f1_score(y, (p >= t).astype(int), zero_division=0) for t in grid]
    return float(grid[int(np.argmax(f1s))])

PREC_TARGET, MIN_PRED = 0.5, 3      # "confident" = at least half of the validation predictions above it are correct
def high_precision_threshold(p, y):
    """Smallest threshold whose validation precision >= PREC_TARGET with >= MIN_PRED predictions; inf if none."""
    for t in np.unique(np.quantile(p, np.linspace(0, 1, 401))):
        pr = (p >= t)
        if pr.sum() >= MIN_PRED and y[pr].mean() >= PREC_TARGET:
            return float(t)
    return float("inf")

t_iu, t_hi = np.zeros(len(NIH_LABELS)), np.zeros(len(NIH_LABELS))
for k, l in enumerate(NIH_LABELS):
    p, y = probs[val, k], Y[val, k]
    if y.sum() == 0:
        t_iu[k], t_hi[k] = t_nih[k], float("inf")
    else:
        t_iu[k] = best_f1_threshold(p, y)
        t_hi[k] = max(high_precision_threshold(p, y), t_iu[k])
json.dump({"nih": dict(zip(NIH_LABELS, t_nih.tolist())), "iu_val_f1": dict(zip(NIH_LABELS, t_iu.tolist())),
           "iu_val_high_precision": dict(zip(NIH_LABELS, [None if np.isinf(v) else v for v in t_hi]))},
          open(os.path.join(REV, "thresholds.json"), "w"), indent=1)
P_nih, P_iu, P_hi = [(probs >= t).astype(int) for t in (t_nih, t_iu, t_hi)]
P_unc = ((probs >= t_iu) & (probs < t_hi)).astype(int)          # uncertain band for the hedged variant

# %% [markdown]
# ## 2. Per-finding precision, recall, F1, AUROC and calibration on the IU X-Ray test split (reviewer Issue 2)

# %%
def ece(y, p, bins=10):
    e, edges = 0.0, np.linspace(0, 1, bins + 1)
    for a, b in zip(edges[:-1], edges[1:]):
        m = (p >= a) & ((p < b) if b < 1 else (p <= b))
        if m.any():
            e += m.mean() * abs(y[m].mean() - p[m].mean())
    return e

rows = []
Yt, Pt = Y[tst], probs[tst]
for k, l in enumerate(NIH_LABELS):
    r = {"Finding": l, "Test positives": int(Yt[:, k].sum()),
         "AUROC": round(roc_auc_score(Yt[:, k], Pt[:, k]), 3) if 0 < Yt[:, k].sum() < len(Yt) else np.nan,
         "Brier": round(float(np.mean((Pt[:, k] - Yt[:, k]) ** 2)), 4), "ECE": round(ece(Yt[:, k], Pt[:, k]), 4)}
    for tag, P in [("NIH thr", P_nih), ("IU-val thr", P_iu), ("high-precision thr", P_hi)]:
        pk = P[tst, k]
        r[f"Predicted ({tag})"] = int(pk.sum())
        r[f"Precision ({tag})"] = round(precision_score(Yt[:, k], pk, zero_division=0), 3)
        r[f"Recall ({tag})"] = round(recall_score(Yt[:, k], pk, zero_division=0), 3)
        r[f"F1 ({tag})"] = round(f1_score(Yt[:, k], pk, zero_division=0), 3)
    rows.append(r)
summ = {"Finding": "ALL (micro)", "Test positives": int(Yt.sum())}
for tag, P in [("NIH thr", P_nih), ("IU-val thr", P_iu), ("high-precision thr", P_hi)]:
    summ[f"Predicted ({tag})"] = int(P[tst].sum())
    summ[f"Precision ({tag})"] = round(precision_score(Yt, P[tst], average="micro", zero_division=0), 3)
    summ[f"Recall ({tag})"] = round(recall_score(Yt, P[tst], average="micro", zero_division=0), 3)
    summ[f"F1 ({tag})"] = round(f1_score(Yt, P[tst], average="micro", zero_division=0), 3)
rows.append(summ)
cls = pd.DataFrame(rows); cls.to_csv(os.path.join(REV, "R1_classifier_per_finding_iu_test.csv"), index=False)
print(cls.to_string())
print("findings per test study: reference", Yt.sum(1).mean().round(2), "| NIH thr", P_nih[tst].sum(1).mean().round(2),
      "| IU-val thr", P_iu[tst].sum(1).mean().round(2), "| high-precision thr", P_hi[tst].sum(1).mean().round(2),
      "| uncertain band", P_unc[tst].sum(1).mean().round(2))

# %% [markdown]
# ## 3. BioGPT (prompted): reuse the trained model, or retrain it exactly as notebook 03 did

# %%
from transformers import tokenization_utils_base as _tub
def _encode_plus(self, t=None, *a, **k):
    t = k.pop("text") if t is None else t
    if isinstance(t, (list, tuple)) and t and isinstance(t[0], str):
        ids = self.convert_tokens_to_ids(list(t))
        if k.get("add_special_tokens", True):
            ids = [self.cls_token_id] + ids + [self.sep_token_id]
        return {"input_ids": ids}
    return self(t, *a, **k)
if not hasattr(_tub.PreTrainedTokenizerBase, "build_inputs_with_special_tokens"):
    _tub.PreTrainedTokenizerBase.build_inputs_with_special_tokens = lambda self, a, b=None: (
        [self.cls_token_id] + list(a) + [self.sep_token_id] + ((list(b) + [self.sep_token_id]) if b else []))
if not hasattr(_tub.PreTrainedTokenizerBase, "encode_plus"):
    _tub.PreTrainedTokenizerBase.encode_plus = _encode_plus

from transformers import BioGptTokenizer, BioGptForCausalLM, Trainer, TrainingArguments
from torch.utils.data import Dataset
import inspect, math
tok = BioGptTokenizer.from_pretrained("microsoft/biogpt")
ref_labels = {u: {l: int(v) for l, v in zip(NIH_LABELS, row)} for u, row in zip(iu.uid, Y)}
src = lambda labels: T.build_prompt(labels) + " report:"

class ReportDS(Dataset):
    def __init__(self, df):
        self.items = []
        for _, r in df.iterrows():
            s = tok(src(ref_labels[r.uid]))["input_ids"]
            t = tok(" " + r.findings.strip(), add_special_tokens=False)["input_ids"][:200] + [tok.eos_token_id]
            self.items.append((s + t, [-100] * len(s) + t))
    def __len__(self): return len(self.items)
    def __getitem__(self, i): return self.items[i]

def collate(batch):
    n = max(len(x) for x, _ in batch)
    ids = torch.full((len(batch), n), tok.pad_token_id); lab = torch.full((len(batch), n), -100); att = torch.zeros((len(batch), n), dtype=torch.long)
    for i, (x, y) in enumerate(batch):
        ids[i, :len(x)] = torch.tensor(x); lab[i, :len(y)] = torch.tensor(y); att[i, :len(x)] = 1
    return {"input_ids": ids, "labels": lab, "attention_mask": att}

def load_or_train():
    final = os.path.join(OUT, "models", "biogpt_prompted", "final")
    if os.path.exists(os.path.join(final, "config.json")):
        print("using the BioGPT model trained in notebook 03"); return BioGptForCausalLM.from_pretrained(final).to(DEVICE), False
    print("BioGPT model not found on Drive: retraining with the notebook 03 settings (about 15 min)")
    torch.manual_seed(0)
    m = BioGptForCausalLM.from_pretrained("microsoft/biogpt")
    n_train, epochs = int((iu.split == "train").sum()), 3
    kw = dict(output_dir=os.path.join("/content" if IN_COLAB else REV, "biogpt_tmp"), per_device_train_batch_size=8,
              per_device_eval_batch_size=8, gradient_accumulation_steps=2, learning_rate=5e-5, num_train_epochs=epochs,
              weight_decay=0.01, fp16=True, save_strategy="no", logging_steps=50, report_to=[], seed=0)
    params = set(inspect.signature(TrainingArguments.__init__).parameters)
    kw["warmup_ratio" if "warmup_ratio" in params else "warmup_steps"] = 0.1 if "warmup_ratio" in params else int(0.1 * math.ceil(n_train / 16) * epochs)
    kw["eval_strategy" if "eval_strategy" in params else "evaluation_strategy"] = "epoch"
    tr = Trainer(model=m, args=TrainingArguments(**{k: v for k, v in kw.items() if k in params}), data_collator=collate,
                 train_dataset=ReportDS(iu[iu.split == "train"]), eval_dataset=ReportDS(iu[iu.split == "val"]))
    tr.train()
    m.save_pretrained(final)          # weights only (about 1.4 GB); no optimizer state
    return m.to(DEVICE), True

@torch.no_grad()
def generate(m, sources, bs=16):
    m.eval(); tok.padding_side = "left"; outs = []
    for i in range(0, len(sources), bs):
        enc = tok(sources[i:i + bs], return_tensors="pt", padding=True).to(DEVICE)
        g = m.generate(**enc, max_new_tokens=160, num_beams=3, no_repeat_ngram_size=4, early_stopping=True,
                       eos_token_id=tok.eos_token_id, pad_token_id=tok.pad_token_id)
        outs += [tok.decode(x[enc["input_ids"].shape[1]:], skip_special_tokens=True).strip() for x in g]
    tok.padding_side = "right"
    return outs

# %% [markdown]
# ## 4. Generate every variant on the 589 test studies

# %%
def hedge_filter(report, confident, uncertain):
    """Consistency filter that asserts only confident findings and hedges uncertain ones.
    Sentences asserting a finding are removed only if it is neither confident nor uncertain; a confident finding that is
    negated is removed. Missing confident findings get the usual template; missing uncertain ones get 'X cannot be excluded.'"""
    kept = []
    for s in T.split_sentences(report):
        st = T.match_sentence(s)
        bad = [l for l, v in st.items() if (confident.get(l, 0) != 1 and uncertain.get(l, 0) != 1 and T.is_positive(v))
               or (confident.get(l, 0) == 1 and v == "neg")]
        if not bad:
            kept.append(s)
    present, added = T.match_report(" ".join(kept)), []
    for l in NIH_LABELS:
        if confident.get(l, 0) == 1 and not T.is_positive(present.get(l)):
            added.append(T.TEMPLATE[l])
        elif uncertain.get(l, 0) == 1 and not T.is_positive(present.get(l)):
            added.append(f"{READABLE[l][0].upper() + READABLE[l][1:]} cannot be excluded.")
    out = " ".join(kept + added).strip()
    return (out or T.NORMAL_TEMPLATE), len(added)

test = iu[tst].reset_index(drop=True); ti = np.flatnonzero(tst)
lab = lambda P: {u: {l: int(v) for l, v in zip(NIH_LABELS, P[i])} for u, i in zip(test.uid, ti)}
L_nih, L_iu, L_hi, L_unc = lab(P_nih), lab(P_iu), lab(P_hi), lab(P_unc)
gen_file = os.path.join(REV, "iu_test_reports_revision.csv")
if os.path.exists(gen_file):
    G = pd.read_csv(gen_file, dtype={"uid": str})
else:
    m, retrained = load_or_train()
    G = pd.DataFrame({"uid": test.uid, "reference": test.findings})
    raw = {"nih": generate(m, [src(L_nih[u]) for u in test.uid]),
           "iu": generate(m, [src(L_iu[u]) for u in test.uid]),
           "hi": generate(m, [src(L_hi[u]) for u in test.uid])}
    del m; torch.cuda.empty_cache()
    G["ours"], G["added_ours"] = zip(*[(lambda f: (f[0], len(f[1]["added"])))(T.consistency_filter(r, L_nih[u])) for u, r in zip(G.uid, raw["nih"])])
    G["recal"], G["added_recal"] = zip(*[(lambda f: (f[0], len(f[1]["added"])))(T.consistency_filter(r, L_iu[u])) for u, r in zip(G.uid, raw["iu"])])
    G["gated_withhold"], G["added_withhold"] = zip(*[(lambda f: (f[0], len(f[1]["added"])))(T.consistency_filter(r, L_hi[u])) for u, r in zip(G.uid, raw["hi"])])
    G["gated_hedge"], G["added_hedge"] = zip(*[hedge_filter(r, L_hi[u], L_unc[u]) for u, r in zip(G.uid, raw["hi"])])
    G["ours_nofilter"] = raw["nih"]
    G["biogpt_retrained_in_06a"] = retrained
    G.to_csv(gen_file, index=False)
print(G[["added_ours", "added_recal", "added_withhold", "added_hedge"]].describe().round(2).to_string())

# %% [markdown]
# ## 5. Metrics (same code as notebooks 03 and 03b) and paired tests against the proposed system

# %%
_cx = "/root/.cache/chexbert/chexbert.pth"
if not os.path.exists(_cx):
    _c = [p for p in glob.glob("/root/.cache/**/chexbert.pth", recursive=True) if os.path.isfile(p)]
    if _c:
        os.makedirs(os.path.dirname(_cx), exist_ok=True); shutil.copy(_c[0], _cx)
if not os.path.exists(_cx):
    from huggingface_hub import hf_hub_download
    os.makedirs(os.path.dirname(_cx), exist_ok=True); shutil.copy(hf_hub_download("StanfordAIMI/RRG_scorers", "chexbert.pth"), _cx)
from pycocoevalcap.bleu.bleu import Bleu
from pycocoevalcap.rouge.rouge import Rouge
import nltk; nltk.download("wordnet", quiet=True); nltk.download("omw-1.4", quiet=True)
from nltk.translate.meteor_score import meteor_score as _ms
from f1chexbert import F1CheXbert
from radgraph import F1RadGraph

CONDITIONS = ["Enlarged Cardiomediastinum", "Cardiomegaly", "Lung Opacity", "Lung Lesion", "Edema", "Consolidation", "Pneumonia",
              "Atelectasis", "Pneumothorax", "Pleural Effusion", "Pleural Other", "Fracture", "Support Devices", "No Finding"]
FIVE = [CONDITIONS.index(c) for c in ["Atelectasis", "Cardiomegaly", "Consolidation", "Edema", "Pleural Effusion"]]
chexbert = F1CheXbert(device=DEVICE); radgraph = F1RadGraph(reward_level="partial")
lbl = lambda texts: np.array([chexbert.get_label(t) for t in texts], dtype=int)
bleu = lambda g, r: Bleu(4).compute_score(g, r, verbose=0)[0]

refs = G.reference.tolist(); Yref = lbl(refs)
gts = {i: [T.clean_report_iu_xray(r)] for i, r in enumerate(refs)}
SYS = {"ours": "Proposed (NIH thresholds), re-run", "recal": "Proposed, IU-val thresholds",
       "gated_withhold": "Confidence-gated: withhold low-confidence findings",
       "gated_hedge": "Confidence-gated: hedge low-confidence findings"}
NF = [CONDITIONS.index(c) for c in CONDITIONS if c != "No Finding"]
cache, out = {}, []
for s, name in SYS.items():
    hyps = G[s].fillna("").tolist(); res = {i: [T.clean_report_iu_xray(h)] for i, h in enumerate(hyps)}
    Yh = lbl(hyps)
    rg = radgraph(hyps=hyps, refs=refs)[1]; rg = np.array(rg[0] if isinstance(rg, tuple) else rg, dtype=float)
    cache[s] = (Yh, rg)
    fp = ((Yh[:, NF] == 1) & (Yref[:, NF] == 0)).sum(1); fn = ((Yh[:, NF] == 0) & (Yref[:, NF] == 1)).sum(1)
    b = bleu(gts, res)
    c_mi = stats.bootstrap_ci(lambda i, Yh=Yh: f1_score(Yref[i], Yh[i], average="micro", zero_division=0), len(refs))
    c_rg = stats.bootstrap_ci(lambda i, rg=rg: rg[i].mean(), len(refs))
    out.append({"Method": name, "BLEU-1": round(b[0], 3), "BLEU-4": round(b[3], 3),
                "METEOR": round(float(np.mean([_ms([gts[k][0].split()], res[k][0].split()) for k in gts])), 3),
                "ROUGE-L": round(Rouge().compute_score(gts, res)[0], 3),
                "CheXbert micro-F1-14 (95% CI)": stats.fmt_ci(*c_mi),
                "CheXbert macro-F1-14": round(f1_score(Yref, Yh, average="macro", zero_division=0), 3),
                "CheXbert micro-F1-5": round(f1_score(Yref[:, FIVE], Yh[:, FIVE], average="micro", zero_division=0), 3),
                "RadGraph F1 (95% CI)": stats.fmt_ci(*c_rg),
                "False findings per report (CheXbert)": round(fp.mean(), 2), "Missed findings per report (CheXbert)": round(fn.mean(), 2),
                "Reports with >= 1 false finding (%)": round(100 * (fp > 0).mean(), 1)})
    G[f"en_false_findings_{s}"], G[f"en_missed_findings_{s}"] = fp, fn
R2 = pd.DataFrame(out); R2.to_csv(os.path.join(REV, "R2_generation_gated.csv"), index=False)
G.to_csv(gen_file, index=False)
print(R2.to_string())

tests = []
for other in ["gated_withhold", "gated_hedge", "recal"]:
    for metric, fa, fb in [
        ("CheXbert micro-F1-14", lambda i, o=other: f1_score(Yref[i], cache[o][0][i], average="micro", zero_division=0),
                                  lambda i: f1_score(Yref[i], cache["ours"][0][i], average="micro", zero_division=0)),
        ("CheXbert macro-F1-14", lambda i, o=other: f1_score(Yref[i], cache[o][0][i], average="macro", zero_division=0),
                                  lambda i: f1_score(Yref[i], cache["ours"][0][i], average="macro", zero_division=0)),
        ("RadGraph F1", lambda i, o=other: cache[o][1][i].mean(), lambda i: cache["ours"][1][i].mean()),
        ("False findings per report", lambda i, o=other: G[f"en_false_findings_{o}"].values[i].mean(),
                                       lambda i: G["en_false_findings_ours"].values[i].mean())]:
        r = stats.paired_bootstrap(fa, fb, len(refs))
        tests.append({"Comparison": f"{SYS[other]} vs proposed", "Metric": metric, "Difference": round(r["diff"], 4),
                      "95% CI": f"{r['lower']:.4f} to {r['upper']:.4f}", "p": r["p"]})
sig = pd.DataFrame(tests); sig["p (Holm)"] = stats.holm(sig.p.values)
sig.to_csv(os.path.join(REV, "R2_generation_gated_significance.csv"), index=False)
print(sig.to_string())


# %% [markdown]
# ## 5b. Examples of harmful false-positive and false-negative reports (reviewer Issue 2)

# %%
IMPORTANT = ["Pneumothorax", "Pleural Effusion", "Consolidation", "Cardiomegaly", "Edema", "Pneumonia", "Atelectasis"]
Yo, Yg = cache["ours"][0], cache["gated_withhold"][0]
ex_rows = []
for kind, cond in [("False positive", lambda c, i: Yo[i, c] == 1 and Yref[i, c] == 0),
                   ("False negative", lambda c, i: Yo[i, c] == 0 and Yref[i, c] == 1)]:
    got = 0
    for name in IMPORTANT:
        c = CONDITIONS.index(name)
        for i in range(len(G)):
            if cond(c, i):
                ex_rows.append({"Type": kind, "Finding": name, "uid": G.uid[i], "Reference report": G.reference[i],
                                "Proposed report": G.ours[i], "Gated (withhold) report": G.gated_withhold[i],
                                "Gated has the same error": bool(Yg[i, c] != Yref[i, c])})
                got += 1; break
        if got >= 3: break
pd.DataFrame(ex_rows).to_csv(os.path.join(REV, "R6_harmful_examples.csv"), index=False)
print(pd.DataFrame(ex_rows)[["Type", "Finding", "Gated has the same error"]])

# %% [markdown]
# ## 6. Do the MeSH-derived IU labels agree with labels read from the report text? (label-transfer check)

# %%
PAIRS = {"Atelectasis": "Atelectasis", "Cardiomegaly": "Cardiomegaly", "Effusion": "Pleural Effusion",
         "Pneumothorax": "Pneumothorax", "Consolidation": "Consolidation", "Edema": "Edema", "Pneumonia": "Pneumonia"}
Ytext = lbl(iu.findings.fillna("").tolist())
rows = []
for nih_l, cx in PAIRS.items():
    a, b = Y[:, NIH_LABELS.index(nih_l)], Ytext[:, CONDITIONS.index(cx)]
    rows.append({"NIH label (MeSH)": nih_l, "CheXbert label (text)": cx, "MeSH positives": int(a.sum()), "Text positives": int(b.sum()),
                 "Both positive": int((a & b).sum()), "Agreement (%)": round(100 * (a == b).mean(), 1),
                 "Cohen kappa": round(cohen_kappa_score(a, b), 3) if (a.any() or b.any()) else np.nan})
R3 = pd.DataFrame(rows); R3.to_csv(os.path.join(REV, "R3_label_mapping_agreement.csv"), index=False)
print(R3.to_string())
print("\nDone. Send the folder outputs/revision (as a zip) back to Claude.")
