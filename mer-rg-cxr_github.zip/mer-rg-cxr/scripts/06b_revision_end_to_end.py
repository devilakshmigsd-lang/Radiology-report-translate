# %% [markdown]
# # 06b · Reviewer revision: end-to-end test, image -> generated English report -> Tamil -> safety checks
# # (Google Colab, T4 GPU, about 30 min; run AFTER 06a, in a fresh session: Runtime -> Restart session first)
#
# Answers reviewer Issue 1. For 100 randomly chosen IU X-Ray test studies (seed 7), the reports written by the
# proposed system and by the two confidence-gated variants (from 06a) are translated into Tamil with IndicTrans2
# (the safer system in the paper), back-translated, and screened with the same checks as notebook 04.
# Outputs in `outputs/revision/`:
#   - e2e_ta_checked.csv          every generated sentence, its Tamil translation, back-translation and flags
#   - R4_end_to_end_reports.csv   report-level English errors (CheXbert vs reference), Tamil flags, and both together
#   - e2e_audit_ta.xlsx           blinded sheet of unique Tamil sentences for the radiologist audit (same format as before)

# %%
import os, sys, time
IN_COLAB = "google.colab" in sys.modules or bool(os.environ.get("MERRG_SUBPROCESS"))
if IN_COLAB and not os.environ.get("MERRG_SUBPROCESS"):
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
OUT = os.path.join(PROJECT, "outputs"); REV = os.path.join(OUT, "revision")
sys.path.insert(0, PROJECT)
os.system("pip install -q openpyxl sacrebleu 'transformers==4.51.3' sentencepiece IndicTransToolkit")

import numpy as np, pandas as pd, torch
from merrg import text as T
from huggingface_hub import login
try:
    from google.colab import userdata
    login(token=userdata.get("HF_TOKEN"))
except Exception as e:
    print("HF_TOKEN secret not found; IndicTrans2 (a gated model) will fail.", e)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
assert DEVICE == "cuda", "No GPU: Runtime -> Change runtime type -> T4 GPU"

G = pd.read_csv(os.path.join(REV, "iu_test_reports_revision.csv"), dtype={"uid": str})
VARIANTS = {"ours": "Proposed", "gated_withhold": "Gated (withhold)", "gated_hedge": "Gated (hedge)"}
rng = np.random.default_rng(7)
pick = sorted(rng.choice(len(G), size=100, replace=False))
S = G.iloc[pick].reset_index(drop=True)
rows = [{"uid": r.uid, "variant": v, "sent_id": j, "en": s}
        for _, r in S.iterrows() for v in VARIANTS for j, s in enumerate(T.split_sentences(str(r[v])))]
E = pd.DataFrame(rows)
uniq = sorted(E.en.unique())
print(len(S), "reports,", len(E), "generated sentences,", len(uniq), "unique sentences to translate")

# %% translation (same model and decoding as notebook 04)
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
try:
    from IndicTransToolkit.processor import IndicProcessor
except ImportError:
    from IndicTransToolkit import IndicProcessor

def it2(sents, src, tgt):
    name = "ai4bharat/indictrans2-en-indic-1B" if src == "eng_Latn" else "ai4bharat/indictrans2-indic-en-1B"
    tk = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
    md = AutoModelForSeq2SeqLM.from_pretrained(name, trust_remote_code=True, torch_dtype=torch.float16).to(DEVICE).eval()
    ip, out = IndicProcessor(inference=True), []
    for i in range(0, len(sents), 16):
        b = ip.preprocess_batch(sents[i:i + 16], src_lang=src, tgt_lang=tgt)
        enc = tk(b, truncation=True, padding="longest", return_tensors="pt", return_attention_mask=True).to(DEVICE)
        with torch.no_grad():
            g = md.generate(**enc, use_cache=True, min_length=0, max_length=256, num_beams=5, num_return_sequences=1)
        out += ip.postprocess_batch(tk.batch_decode(g, skip_special_tokens=True, clean_up_tokenization_spaces=True), lang=tgt)
    del md; import gc; gc.collect(); torch.cuda.empty_cache(); return out

mt_file = os.path.join(REV, "e2e_ta_unique.csv")
if os.path.exists(mt_file):
    U = pd.read_csv(mt_file)
else:
    t0 = time.time(); ta = it2(uniq, "eng_Latn", "tam_Taml"); back = it2(ta, "tam_Taml", "eng_Latn")
    U = pd.DataFrame({"en": uniq, "mt": ta, "back_en": back}); U.to_csv(mt_file, index=False)
    print(f"translated in {(time.time() - t0) / 60:.1f} min")

# %% checks (same functions as notebook 04)
U["en"], U["mt"], U["back_en"] = U.en.astype(str), U.mt.fillna("").astype(str), U.back_en.fillna("").astype(str)
tm = [T.target_marker_check(e, m, "ta") for e, m in zip(U.en, U.mt)]
U["tgt_flag"] = [f for f, _ in tm]
U["tgt_negation_lost"] = ["negation_lost" in r for _, r in tm]
U["tgt_laterality"] = [any(x in r for x in ("left_lost", "right_lost", "laterality_added")) for _, r in tm]
U["bt_flag"] = [T.backtranslation_flag(e, b)[0] for e, b in zip(U.en, U.back_en)]
U["any_auto_flag"] = U.tgt_flag | U.bt_flag
E = E.merge(U, on="en", how="left")
E.to_csv(os.path.join(REV, "e2e_ta_checked.csv"), index=False)

# %% report-level end-to-end table
rep = E.groupby(["uid", "variant"]).agg(sentences=("en", "size"), flagged=("any_auto_flag", "sum")).reset_index()
rep["tamil_flagged"] = rep.flagged > 0
for v in VARIANTS:
    m = rep.variant == v
    rep.loc[m, "en_false_findings"] = rep.loc[m, "uid"].map(S.set_index("uid")[f"en_false_findings_{v}"]).values
    rep.loc[m, "en_missed_findings"] = rep.loc[m, "uid"].map(S.set_index("uid")[f"en_missed_findings_{v}"]).values
rep["english_error"] = (rep.en_false_findings + rep.en_missed_findings) > 0
rep["passes_triage"] = ~rep.tamil_flagged
rep["english_error_and_passes_triage"] = rep.english_error & rep.passes_triage
rep.to_csv(os.path.join(REV, "e2e_reports.csv"), index=False)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * (c - h), 100 * (c + h))
out = []
for v, name in VARIANTS.items():
    d = rep[rep.variant == v]; n = len(d)
    k1, k2, k3, k4 = d.english_error.sum(), d.tamil_flagged.sum(), d.passes_triage.sum(), d.english_error_and_passes_triage.sum()
    out.append({"System": name, "Reports": n, "Tamil sentences": int(d.sentences.sum()),
                "Sentences flagged (%)": round(100 * d.flagged.sum() / d.sentences.sum(), 1),
                "Reports with English clinical error (%) (95% CI)": f"{100 * k1 / n:.1f} ({wilson(k1, n)[0]:.1f}-{wilson(k1, n)[1]:.1f})",
                "Reports with any Tamil flag (%)": round(100 * k2 / n, 1),
                "Reports passing triage (n)": int(k3),
                "Passing triage but with English clinical error (n)": int(k4),
                "False findings per report": round(d.en_false_findings.mean(), 2)})
R4 = pd.DataFrame(out); R4.to_csv(os.path.join(REV, "R4_end_to_end_reports.csv"), index=False)
print(R4.to_string())

# %% blinded audit sheet of unique Tamil sentences (system variants are not shown)
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation
A = U[["en", "mt"]].sample(frac=1, random_state=11).reset_index(drop=True)
A.insert(0, "row_id", range(1, len(A) + 1))
A.to_csv(os.path.join(REV, "e2e_audit_key.csv"), index=False)
heads = ["Negation changed", "Left/right changed", "Size/severity changed", "Finding/sentence missing",
         "Other meaning change", "Grammar/fluency (minor)", "Comment"]
wb = Workbook(); ws = wb.active; ws.title = "Instructions"
for i, t in enumerate(["End-to-end Tamil audit: generated report sentences and their Tamil translations.",
                       "Use exactly the same rules as the first Tamil audit: choose 1 in each error column that applies; leave it empty otherwise.",
                       "Judge only whether the Tamil says the same as the English sentence (not whether the English is correct)."], 1):
    ws.cell(i, 1, t); ws.column_dimensions["A"].width = 120
sh = wb.create_sheet("Audit"); sh.append(["Row", "English sentence", "Tamil translation"] + heads)
for r in A.itertuples(index=False):
    sh.append([r.row_id, r.en, r.mt])
for c in sh[1]:
    c.font = Font(bold=True); c.fill = PatternFill("solid", fgColor="D9D9D9"); c.alignment = Alignment(wrap_text=True)
for col, w in zip("ABCDEFGHIJ", [6, 55, 60, 13, 13, 13, 13, 13, 13, 30]):
    sh.column_dimensions[col].width = w
dv = DataValidation(type="list", formula1='"1"', allow_blank=True); sh.add_data_validation(dv); dv.add(f"D2:I{sh.max_row}")
sh.freeze_panes = "D2"
wb.save(os.path.join(REV, "e2e_audit_ta.xlsx"))
print(len(A), "unique sentences in e2e_audit_ta.xlsx. Send the folder outputs/revision (as a zip) back to Claude.")

# %% [markdown]
# ## Example translations in Hindi and Telugu (for the paper's example table; display only, no evaluation)

# %%
EXAMPLES = ["No pleural effusion or pneumothorax.", "No pneumothorax.", "There is no pleural effusion.",
            "The lungs are mildly hypoinflated without focal consolidation.", "There are no nodules or masses.",
            "Aorta is atherosclerotic.", "Bony structures unremarkable.",
            "The heart is normal in size.", "There is a small left pleural effusion.", "Mild atelectasis in the right lower lobe."]
ex = pd.DataFrame({"en": EXAMPLES})
for code, tgt in [("hi", "hin_Deva"), ("te", "tel_Telu")]:
    ex[code] = it2(EXAMPLES, "eng_Latn", tgt)
ex.to_csv(os.path.join(REV, "examples_hi_te.csv"), index=False)
print(ex.to_string())
print("Saved examples_hi_te.csv. Send the folder outputs/revision (as a zip) back to Claude.")
