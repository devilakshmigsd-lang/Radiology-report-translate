# %% [markdown]
# # 03 · Finding-grounded report generation on IU X-Ray (Google Colab, GPU)
#
# 1. Runs the EfficientNet-B3 (seed 0) findings model on IU X-Ray frontal images -> predicted labels.
# 2. Fine-tunes BioGPT twice: with finding prompts, and without (baseline).
# 3. Generates test reports for every system, applies the consistency filter, and scores all of them with the
#    same metric code (BLEU-1..4, METEOR, ROUGE-L, CheXbert F1, RadGraph F1).
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `tables/table5_report_generation.csv`, `tables/table5_significance.csv` | **Table 5** |
# | `tables/table6_examples.csv` | **Table 6** (examples) |
# | `tables/filter_log_summary.csv` | Section 4.2 |
# | `generated/iu_test_reports.csv` | notebook 04 |
#
# Baselines R2Gen / CMN (optional but recommended): train them with the authors' code on
# `r2gen_iu/r2gen_iu.zip` (made by notebook 00) and save their test outputs as
# `outputs/external/r2gen_test.csv` and `outputs/external/cmn_test.csv` with columns `id,report`.
# Time: about 1–2 h on a T4. BioGPT checkpoints are saved each epoch; after a disconnect just Run all.

# %%
import os, sys, json, shutil
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
sys.path.insert(0, PROJECT)
for d in ["generated", "external", "tables", "models"]:
    os.makedirs(os.path.join(OUT, d), exist_ok=True)
os.system("pip install -q timm opencv-python-headless transformers accelerate sacremoses f1chexbert radgraph pycocoevalcap")
if shutil.which("java") is None:   # METEOR in pycocoevalcap needs Java
    os.system("apt-get -qq install -y default-jre-headless > /dev/null")

# %%
import numpy as np, pandas as pd, torch
from merrg.labels import NIH_LABELS
from merrg import text as T, stats
from merrg.vision import build_model, ArrayDataset, predict, load_store_local

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NAME, SEED = "efficientnet_b3", 0
FAST = True              # True = 3 BioGPT epochs (about 30 min on a T4); False = 10 epochs
iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv"))
iu["uid"] = iu.uid.astype(str)
print(iu.split.value_counts())

# %% [markdown]
# ## 1. Predicted findings for every IU study (frontal image, NIH thresholds frozen from notebook 01)

# %%
model = build_model(NAME, len(NIH_LABELS), pretrained=False)
model.load_state_dict(torch.load(os.path.join(OUT, "models", f"{NAME}_seed{SEED}.pt"), map_location=DEVICE))
IU_ARR = load_store_local(os.path.join(STORE, "iu_frontal"), LOCAL)
probs = predict(model.to(DEVICE), ArrayDataset(IU_ARR, iu.row.values), device=DEVICE)
thr = json.load(open(os.path.join(OUT, "models", f"thresholds_{NAME}_seed{SEED}.json")))
pred = pd.DataFrame((probs >= np.array([thr[l] for l in NIH_LABELS])).astype(int), columns=NIH_LABELS)
pred.insert(0, "uid", iu.uid.values)
pred.to_csv(os.path.join(OUT, "generated", "iu_predicted_labels.csv"), index=False)
del model; torch.cuda.empty_cache()
ref_labels = {r.uid: {l: int(r[l]) for l in NIH_LABELS} for _, r in iu.iterrows()}
pred_labels = {r.uid: {l: int(r[l]) for l in NIH_LABELS} for _, r in pred.iterrows()}

# %% [markdown]
# ## 2. Fine-tune BioGPT (prompted and unprompted)

# %%
from transformers import BioGptTokenizer, BioGptForCausalLM, Trainer, TrainingArguments, EarlyStoppingCallback
from torch.utils.data import Dataset

tok = BioGptTokenizer.from_pretrained("microsoft/biogpt")
MAX_TGT = 200

def source(labels, prompted):
    return (T.build_prompt(labels) + " report:") if prompted else "report:"

class ReportDS(Dataset):
    def __init__(self, df, prompted):
        self.items = []
        for _, r in df.iterrows():
            s = tok(source(ref_labels[r.uid], prompted))["input_ids"]          # reference labels during training
            t = tok(" " + r.findings.strip(), add_special_tokens=False)["input_ids"][:MAX_TGT] + [tok.eos_token_id]
            self.items.append((s + t, [-100] * len(s) + t))
    def __len__(self): return len(self.items)
    def __getitem__(self, i): return self.items[i]

def collate(batch):
    n = max(len(x) for x, _ in batch)
    ids = torch.full((len(batch), n), tok.pad_token_id); lab = torch.full((len(batch), n), -100); att = torch.zeros((len(batch), n), dtype=torch.long)
    for i, (x, y) in enumerate(batch):
        ids[i, :len(x)] = torch.tensor(x); lab[i, :len(y)] = torch.tensor(y); att[i, :len(x)] = 1
    return {"input_ids": ids, "labels": lab, "attention_mask": att}

def finetune(prompted):
    tag = "biogpt_prompted" if prompted else "biogpt_unprompted"
    out_dir = os.path.join(OUT, "models", tag)
    if os.path.exists(os.path.join(out_dir, "final", "config.json")):
        return BioGptForCausalLM.from_pretrained(os.path.join(out_dir, "final")).to(DEVICE)
    # a finished run whose "final" copy was lost (e.g. Drive full): reuse its best saved checkpoint
    import glob as _g
    ck = sorted(_g.glob(os.path.join(out_dir, "checkpoint-*", "model.safetensors")), key=lambda p: int(p.split("checkpoint-")[1].split("/")[0]))
    if ck:
        st = json.load(open(os.path.join(os.path.dirname(ck[-1]), "trainer_state.json")))
        if st.get("epoch", 0) >= (3 if FAST else 10) - 1e-6:
            best = st.get("best_model_checkpoint") or os.path.dirname(ck[-1])
            best = os.path.join(out_dir, os.path.basename(best.rstrip("/")))
            if not os.path.exists(os.path.join(best, "model.safetensors")):
                best = os.path.dirname(ck[-1])
            print("loading finished BioGPT checkpoint", best)
            return BioGptForCausalLM.from_pretrained(best).to(DEVICE)
    torch.manual_seed(0)
    m = BioGptForCausalLM.from_pretrained("microsoft/biogpt")
    import inspect, math
    n_train = int((iu.split == "train").sum()); epochs = 3 if FAST else 10
    kw = dict(output_dir=out_dir, per_device_train_batch_size=8, per_device_eval_batch_size=8, gradient_accumulation_steps=2,
              learning_rate=5e-5 if FAST else 2e-5, num_train_epochs=epochs, weight_decay=0.01, fp16=DEVICE == "cuda",
              save_strategy="no", logging_steps=50, load_best_model_at_end=False,   # no 2.6 GB optimizer checkpoints on Drive
              report_to=[], seed=0)
    params = set(inspect.signature(TrainingArguments.__init__).parameters)   # works across transformers versions
    if "warmup_ratio" in params:
        kw["warmup_ratio"] = 0.1
    else:
        kw["warmup_steps"] = int(0.1 * math.ceil(n_train / 16) * epochs)
    kw["eval_strategy" if "eval_strategy" in params else "evaluation_strategy"] = "epoch"
    args = TrainingArguments(**{k: v for k, v in kw.items() if k in params})
    tr = Trainer(model=m, args=args, data_collator=collate,
                 train_dataset=ReportDS(iu[iu.split == "train"], prompted), eval_dataset=ReportDS(iu[iu.split == "val"], prompted))
    tr.train()
    pd.DataFrame(tr.state.log_history).to_csv(os.path.join(OUT, "tables", f"training_history_{tag}.csv"), index=False)
    m.save_pretrained(os.path.join(out_dir, "final"))
    return m.to(DEVICE)

@torch.no_grad()
def generate(m, sources, bs=16):
    m.eval(); tok.padding_side = "left"; outs = []
    for i in range(0, len(sources), bs):
        enc = tok(sources[i:i + bs], return_tensors="pt", padding=True).to(DEVICE)
        g = m.generate(**enc, max_new_tokens=160, num_beams=3, no_repeat_ngram_size=4, early_stopping=True,
                       eos_token_id=tok.eos_token_id, pad_token_id=tok.pad_token_id)
        outs += [tok.decode(x[enc["input_ids"].shape[1]:], skip_special_tokens=True).strip() for x in g]
    tok.padding_side = "right"
    return outs

# %% [markdown]
# ## 3. Generate test reports for every system

# %%
test = iu[iu.split == "test"].reset_index(drop=True)
gen_file = os.path.join(OUT, "generated", "iu_test_reports.csv")
if os.path.exists(gen_file):
    G = pd.read_csv(gen_file, dtype={"uid": str})
else:
    G = pd.DataFrame({"uid": test.uid, "reference": test.findings})
    m = finetune(prompted=True)
    G["ours_pred_nofilter"] = generate(m, [source(pred_labels[u], True) for u in test.uid])
    G["ours_ref_nofilter"] = generate(m, [source(ref_labels[u], True) for u in test.uid])
    del m; torch.cuda.empty_cache()
    m = finetune(prompted=False)
    G["biogpt_noprompt"] = generate(m, [source(None, False)] * len(test))
    del m; torch.cuda.empty_cache()
    logs = []
    filt = [T.consistency_filter(r, pred_labels[u]) for u, r in zip(G.uid, G.ours_pred_nofilter)]
    G["ours"] = [f[0] for f in filt]
    G["ours_ref_upper_bound"] = [T.consistency_filter(r, ref_labels[u])[0] for u, r in zip(G.uid, G.ours_ref_nofilter)]
    G["template"] = [T.template_report(pred_labels[u]) for u in G.uid]
    pd.DataFrame({"removed_sentences": [len(f[1]["removed"]) for f in filt], "added_sentences": [len(f[1]["added"]) for f in filt]}) \
      .describe().to_csv(os.path.join(OUT, "tables", "filter_log_summary.csv"))
    for ext in ["r2gen", "cmn"]:
        p = os.path.join(OUT, "external", f"{ext}_test.csv")
        if os.path.exists(p):
            e = pd.read_csv(p, dtype={"id": str}).set_index("id").report
            G[ext] = G.uid.map(e)
            print(ext, "missing:", G[ext].isna().sum())
        else:
            print(f"{ext} outputs not found at {p}; that row will be skipped")
    G.to_csv(gen_file, index=False)
G.head()

# %% [markdown]
# ## 4. Metrics (identical code for every system)

# %%
from pycocoevalcap.bleu.bleu import Bleu
from pycocoevalcap.meteor.meteor import Meteor
from pycocoevalcap.rouge.rouge import Rouge
from sklearn.metrics import f1_score
# compatibility with transformers >= 5 (encode_plus removed; f1chexbert/radgraph still call it)
from transformers import tokenization_utils_base as _tub
def _encode_plus(self, t=None, *a, **k):
    t = k.pop("text") if t is None else t
    if isinstance(t, (list, tuple)) and t and isinstance(t[0], str):     # pre-tokenised word pieces
        ids = self.convert_tokens_to_ids(list(t))
        if k.get("add_special_tokens", True):
            ids = [self.cls_token_id] + ids + [self.sep_token_id]
        return {"input_ids": ids}
    return self(t, *a, **k)
if not hasattr(_tub.PreTrainedTokenizerBase, "build_inputs_with_special_tokens"):
    _tub.PreTrainedTokenizerBase.build_inputs_with_special_tokens = lambda self, a, b=None: (
        [self.cls_token_id] + list(a) + [self.sep_token_id] + ((list(b) + [self.sep_token_id]) if b else []))
if not hasattr(_tub.PreTrainedTokenizerBase, "encode_plus"):
    _tub.PreTrainedTokenizerBase.encode_plus = _encode_plus
    _tub.PreTrainedTokenizerBase.batch_encode_plus = lambda self, *a, **k: self(*a, **k)
import glob as _glob, shutil as _sh
_cx = "/root/.cache/chexbert/chexbert.pth"
if not os.path.exists(_cx):     # f1chexbert downloads into the HF cache but opens this path
    _c = [p for p in _glob.glob("/root/.cache/**/chexbert.pth", recursive=True) if os.path.isfile(p)]
    if _c:
        os.makedirs(os.path.dirname(_cx), exist_ok=True); _sh.copy(_c[0], _cx)
from f1chexbert import F1CheXbert
from radgraph import F1RadGraph

CONDITIONS = ["Enlarged Cardiomediastinum", "Cardiomegaly", "Lung Opacity", "Lung Lesion", "Edema", "Consolidation", "Pneumonia",
              "Atelectasis", "Pneumothorax", "Pleural Effusion", "Pleural Other", "Fracture", "Support Devices", "No Finding"]
FIVE = [CONDITIONS.index(c) for c in ["Atelectasis", "Cardiomegaly", "Consolidation", "Edema", "Pleural Effusion"]]
chexbert = F1CheXbert(device=DEVICE)
radgraph = F1RadGraph(reward_level="partial")

def chexbert_labels(texts):
    return np.array([chexbert.get_label(t) for t in texts], dtype=int)   # 14 binary labels, uncertain -> positive

def bleu_n(gts, res):
    b, _ = Bleu(4).compute_score(gts, res)
    return b

import nltk; nltk.download("wordnet", quiet=True); nltk.download("omw-1.4", quiet=True)
from nltk.translate.meteor_score import meteor_score as _ms
def meteor_avg(gts, res):
    """Sentence-level METEOR (NLTK) averaged over reports; the pycocoevalcap Java METEOR desyncs on empty outputs."""
    return float(np.mean([_ms([gts[k][0].split()], res[k][0].split()) for k in gts]))

def nlg(refs, hyps):
    gts = {i: [T.clean_report_iu_xray(r)] for i, r in enumerate(refs)}
    res = {i: [T.clean_report_iu_xray(h)] for i, h in enumerate(hyps)}
    b = bleu_n(gts, res)
    return {"BLEU-1": b[0], "BLEU-2": b[1], "BLEU-3": b[2], "BLEU-4": b[3],
            "METEOR": meteor_avg(gts, res), "ROUGE-L": Rouge().compute_score(gts, res)[0]}, gts, res

def radgraph_scores(refs, hyps):
    out = radgraph(hyps=list(hyps), refs=list(refs))
    rewards = out[1]
    return np.array(rewards[0] if isinstance(rewards, tuple) else rewards, dtype=float)

systems = [c for c in ["template", "r2gen", "cmn", "biogpt_noprompt", "ours_pred_nofilter", "ours", "ours_ref_upper_bound"] if c in G]
names = {"template": "Template only", "r2gen": "R2Gen", "cmn": "CMN", "biogpt_noprompt": "BioGPT, no prompt",
         "ours_pred_nofilter": "BioGPT + findings prompt", "ours": "BioGPT + prompt + filter (ours)",
         "ours_ref_upper_bound": "Ours with reference labels (upper bound)"}
refs = G.reference.tolist()
Yref = chexbert_labels(refs)
cache, rows = {}, []
for s in systems:
    hyps = G[s].fillna("").tolist()
    m, gts, res = nlg(refs, hyps)
    Yh = chexbert_labels(hyps)
    rg = radgraph_scores(refs, hyps)
    cache[s] = (gts, res, Yh, rg)
    f1mi = lambda i, Yh=Yh: f1_score(Yref[i], Yh[i], average="micro", zero_division=0)
    b4 = lambda i, gts=gts, res=res: bleu_n({k: gts[k] for k in i}, {k: res[k] for k in i})[3]
    c_b4 = stats.bootstrap_ci(lambda i: b4(np.unique(i)), len(refs), n_boot=500)   # unique ids: BLEU is a corpus metric
    c_mi = stats.bootstrap_ci(f1mi, len(refs))
    c_rg = stats.bootstrap_ci(lambda i: rg[i].mean(), len(refs))
    rows.append({"Method": names[s], "BLEU-1": round(m["BLEU-1"], 3), "BLEU-4 (95% CI)": stats.fmt_ci(*c_b4),
                 "METEOR": round(m["METEOR"], 3), "ROUGE-L": round(m["ROUGE-L"], 3),
                 "CheXbert micro-F1-14 (95% CI)": stats.fmt_ci(*c_mi),
                 "CheXbert macro-F1-14": round(f1_score(Yref, Yh, average="macro", zero_division=0), 3),
                 "CheXbert micro-F1-5": round(f1_score(Yref[:, FIVE], Yh[:, FIVE], average="micro", zero_division=0), 3),
                 "RadGraph F1 (95% CI)": stats.fmt_ci(*c_rg)})
t5 = pd.DataFrame(rows)
t5.to_csv(os.path.join(OUT, "tables", "table5_report_generation.csv"), index=False)
t5

# %% [markdown]
# **Note on BLEU CIs:** resampling with replacement duplicates reports; for the corpus-level BLEU we score the unique
# resampled reports, which slightly narrows the interval. State this in the table footnote, or report BLEU without CI.

# %%
tests = []
for other in [s for s in ["biogpt_noprompt", "ours_pred_nofilter", "r2gen", "cmn", "template"] if s in cache]:
    for metric, fa, fb in [
        ("CheXbert micro-F1-14", lambda i: f1_score(Yref[i], cache["ours"][2][i], average="micro", zero_division=0),
                                  lambda i, o=other: f1_score(Yref[i], cache[o][2][i], average="micro", zero_division=0)),
        ("RadGraph F1", lambda i: cache["ours"][3][i].mean(), lambda i, o=other: cache[o][3][i].mean())]:
        r = stats.paired_bootstrap(fa, fb, len(refs))
        tests.append({"Comparison": f"ours vs {names[other]}", "Metric": metric, "Difference": round(r["diff"], 4),
                      "95% CI": f"{r['lower']:.4f}-{r['upper']:.4f}", "p": r["p"]})
sig = pd.DataFrame(tests); sig["p (Holm)"] = stats.holm(sig.p.values)
sig.to_csv(os.path.join(OUT, "tables", "table5_significance.csv"), index=False)
sig

# %% [markdown]
# ## 5. Qualitative examples (Table 6 / Figure 3): one normal, one single-finding, one multi-finding study

# %%
npos = test[NIH_LABELS].sum(1).values
pick = []
for cond in [npos == 0, npos == 1, npos >= 2]:
    idx = np.flatnonzero(cond)
    if len(idx):
        pick.append(int(np.random.default_rng(0).choice(idx)))
cols = ["uid", "reference"] + [s for s in ["r2gen", "cmn", "biogpt_noprompt", "ours"] if s in G]
ex = G.iloc[pick][cols].copy()
ex.insert(1, "reference findings (MeSH)", test.iloc[pick].Problems.values)
ex.to_csv(os.path.join(OUT, "tables", "table6_examples.csv"), index=False)
ex.T
