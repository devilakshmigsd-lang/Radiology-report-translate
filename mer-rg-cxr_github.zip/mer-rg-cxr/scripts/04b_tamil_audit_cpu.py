# %% [markdown]
# # 04b · Rebuild the Tamil audit sheets on CPU (no GPU needed)
#
# Recreates exactly what notebook 04 sends to the two annotators, for the 100 audit reports only:
# the same 300-report MedIndic-RR sample (seed 2026), the same 100 audit reports (seed 7), the same system codes
# and row order, and the same models and decoding (beam 5). Tamil forward and back-translation are computed for
# the audit sentences only, so notebook 05 can compare the automatic checks with the annotators' judgements.
#
# Outputs (in `outputs/medindic/`): `audit_ta_A1.xlsx`, `audit_ta_A2.xlsx`, `audit_key.csv`,
# `mt_outputs_checked.csv` (Tamil audit rows). Time on a CPU runtime: about 1-2 h.

# %%
import os, sys
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
OUT = os.path.join(PROJECT, "outputs"); MI = os.path.join(OUT, "medindic")
sys.path.insert(0, PROJECT); os.makedirs(MI, exist_ok=True)
os.system("pip install -q openpyxl sacrebleu 'transformers==4.51.3' sentencepiece IndicTransToolkit")

import numpy as np, pandas as pd, torch, time
from merrg import text as T
from huggingface_hub import login
try:
    from google.colab import userdata
    login(token=userdata.get("HF_TOKEN"))
except Exception as e:
    print("HF_TOKEN secret not found; IndicTrans2 (a gated model) will fail.", e)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32
torch.set_num_threads(os.cpu_count() or 2)
N_AUDIT, SYSTEMS = 100, ["indictrans2", "nllb"]

# %% same sample as notebook 04
src_file = os.path.join(MI, "medindic_sentences.csv")
if not os.path.exists(src_file):
    iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv"), dtype={"uid": str})
    test = iu[iu.split == "test"].reset_index(drop=True)
    idx = T.sample_medindic(test.findings.tolist(), n=300, neg_frac=0.40, lat_frac=0.25, seed=2026)
    rows = [{"item_id": item, "uid": test.uid[i], "sent_id": sid, "en": s}
            for item, i in enumerate(idx) for sid, s in enumerate(T.split_sentences(test.findings[i]))]
    pd.DataFrame(rows).to_csv(src_file, index=False)
S = pd.read_csv(src_file, dtype={"uid": str})
print(S.item_id.nunique(), "reports,", len(S), "sentences (notebook 04 reported 300 and 1380)")
rng = np.random.default_rng(7)
items = sorted(rng.choice(S.item_id.unique(), size=min(N_AUDIT, S.item_id.nunique()), replace=False))
A = S[S.item_id.isin(items)].sort_values(["item_id", "sent_id"]).reset_index(drop=True)
print(len(A), "audit sentences")

# %% translation (same models and decoding as notebook 04)
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
try:
    from IndicTransToolkit.processor import IndicProcessor
except ImportError:
    from IndicTransToolkit import IndicProcessor

def free():
    import gc; gc.collect()
    if DEVICE == "cuda": torch.cuda.empty_cache()

def it2(sents, src, tgt):
    name = "ai4bharat/indictrans2-en-indic-1B" if src == "eng_Latn" else "ai4bharat/indictrans2-indic-en-1B"
    tk = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
    md = AutoModelForSeq2SeqLM.from_pretrained(name, trust_remote_code=True, torch_dtype=DTYPE).to(DEVICE).eval()
    ip, out = IndicProcessor(inference=True), []
    for i in range(0, len(sents), 8):
        b = ip.preprocess_batch(sents[i:i + 8], src_lang=src, tgt_lang=tgt)
        enc = tk(b, truncation=True, padding="longest", return_tensors="pt", return_attention_mask=True).to(DEVICE)
        with torch.no_grad():
            g = md.generate(**enc, use_cache=True, min_length=0, max_length=256, num_beams=5, num_return_sequences=1)
        out += ip.postprocess_batch(tk.batch_decode(g, skip_special_tokens=True, clean_up_tokenization_spaces=True), lang=tgt)
        if i % 80 == 0: print(f"  {name.split('/')[-1]} {i}/{len(sents)}", flush=True)
    del md; free(); return out

NLLB = "facebook/nllb-200-distilled-1.3B"
def nllb(sents, src, tgt):
    md = AutoModelForSeq2SeqLM.from_pretrained(NLLB, torch_dtype=DTYPE).to(DEVICE).eval()
    tk, out = AutoTokenizer.from_pretrained(NLLB, src_lang=src), []
    for i in range(0, len(sents), 8):
        enc = tk(sents[i:i + 8], return_tensors="pt", padding=True, truncation=True).to(DEVICE)
        with torch.no_grad():
            g = md.generate(**enc, forced_bos_token_id=tk.convert_tokens_to_ids(tgt), max_length=256, num_beams=5)
        out += tk.batch_decode(g, skip_special_tokens=True)
        if i % 80 == 0: print(f"  nllb {i}/{len(sents)}", flush=True)
    del md; free(); return out

part_file = os.path.join(MI, "mt_ta_audit_parts.csv")
MT = pd.read_csv(part_file) if os.path.exists(part_file) else pd.DataFrame()
for system in SYSTEMS:
    if len(MT) and (MT.system == system).any():
        continue
    t0 = time.time(); fn = it2 if system == "indictrans2" else nllb
    hyp = fn(A.en.tolist(), "eng_Latn", "tam_Taml")
    back = fn(hyp, "tam_Taml", "eng_Latn")
    p = A[["item_id", "sent_id", "en"]].copy()
    p["system_id"], p["system"], p["lang"], p["mt"], p["back_en"] = f"{system}|ta", system, "ta", hyp, back
    MT = pd.concat([MT, p], ignore_index=True); MT.to_csv(part_file, index=False)
    print("done", system, f"{(time.time() - t0) / 60:.1f} min")

# %% automatic checks (same functions as notebook 04) and the blinded sheets
MT["en"], MT["mt"], MT["back_en"] = MT.en.astype(str), MT.mt.fillna("").astype(str), MT.back_en.fillna("").astype(str)
tm = [T.target_marker_check(e, m, l) for e, m, l in zip(MT.en, MT.mt, MT.lang)]
MT["tgt_flag"] = [f for f, _ in tm]
MT["tgt_negation_lost"] = ["negation_lost" in r for _, r in tm]
MT["tgt_laterality"] = [any(x in r for x in ("left_lost", "right_lost", "laterality_added")) for _, r in tm]
bt = [T.backtranslation_flag(e, b) for e, b in zip(MT.en, MT.back_en)]
MT["bt_flag"] = [f for f, _ in bt]
MT["any_auto_flag"] = MT.tgt_flag | MT.bt_flag
MT.to_csv(os.path.join(MI, "mt_outputs_checked.csv"), index=False)
for s, d in MT.groupby("system"):
    print(s, "Tamil audit subset: sentences flagged", round(100 * d.any_auto_flag.mean(), 1), "%")

ERR = ["negation_changed", "left_right_changed", "size_or_severity_changed", "finding_or_sentence_missing",
       "meaning_changed_other", "grammar_or_fluency", "comment"]
d = MT.copy()   # rng continues exactly as in notebook 04 after drawing `items`
codes = {s: f"S{i + 1}" for i, s in enumerate(rng.permutation(sorted(d.system.unique())))}
d["system_code"] = d.system.map(codes)
pd.DataFrame({"system": list(codes), "system_code": list(codes.values())}).to_csv(os.path.join(MI, "audit_key.csv"), index=False)
sheet = d.sample(frac=1, random_state=11)[["item_id", "sent_id", "en", "system_code", "mt"]].rename(columns={"mt": "tamil_translation"})
for c in ERR:
    sheet[c] = ""
for a in ["A1", "A2"]:
    sheet.to_excel(os.path.join(MI, f"audit_ta_{a}.xlsx"), index=False)
print(len(sheet), "rows per annotator (notebook 04 reported 948); files in", MI)
print(sorted(os.listdir(MI)))
