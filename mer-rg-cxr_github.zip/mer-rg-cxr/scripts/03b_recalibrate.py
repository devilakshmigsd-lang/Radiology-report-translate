# %% [markdown]
# # 03b · Target-domain threshold calibration on IU X-Ray (Google Colab, GPU)
#
# The NIH-tuned decision thresholds (notebook 01) over-predict findings on IU X-Ray, so the consistency
# filter inserts false positives. Here each finding's threshold is re-chosen to maximise F1 against the IU
# **validation** labels only (test labels are never used), then the test reports are regenerated with the
# same fine-tuned BioGPT and filter and re-scored with the same metric code as notebook 03.
#
# | Output (in `outputs/`) | Paper |
# |---|---|
# | `models/thresholds_iu_val_{model}.json` | Methods 3.x |
# | `tables/table5b_label_f1.csv` | Section 4.2 (classifier labels on IU test, before vs after) |
# | `tables/table5b_recalibrated.csv`, `tables/table5b_significance.csv` | **Table 5** (extra rows) |
# | `generated/iu_test_reports_recal.csv` | notebook 04 (optional) |
#
# Needs notebook 03 finished (BioGPT model in `models/biogpt_prompted/final`). Time: about 15 min on a T4.

# %%
import os, sys, json, glob, shutil
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
sys.path.insert(0, PROJECT)
os.system("pip install -q timm opencv-python-headless f1chexbert radgraph pycocoevalcap nltk sacremoses")

import numpy as np, pandas as pd, torch
from sklearn.metrics import f1_score
from merrg.labels import NIH_LABELS
from merrg import text as T, stats
from merrg.vision import build_model, ArrayDataset, predict, load_store_local

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
NAME, SEED = "efficientnet_b3", 0
iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv")); iu["uid"] = iu.uid.astype(str)

# %% [markdown]
# ## 1. Probabilities on IU X-Ray and validation-set thresholds

# %%
model = build_model(NAME, len(NIH_LABELS), pretrained=False)
model.load_state_dict(torch.load(os.path.join(OUT, "models", f"{NAME}_seed{SEED}.pt"), map_location=DEVICE))
IU_ARR = load_store_local(os.path.join(STORE, "iu_frontal"), LOCAL)
probs = predict(model.to(DEVICE), ArrayDataset(IU_ARR, iu.row.values), device=DEVICE)
del model; torch.cuda.empty_cache()
nih_thr = json.load(open(os.path.join(OUT, "models", f"thresholds_{NAME}_seed{SEED}.json")))
Y = iu[NIH_LABELS].values.astype(int)
val, tst = (iu.split == "val").values, (iu.split == "test").values

new_thr, rows = {}, []
for k, l in enumerate(NIH_LABELS):
    p, y = probs[val, k], Y[val, k]
    if y.sum() == 0:                      # no validation positives: keep the NIH threshold
        new_thr[l] = float(nih_thr[l]); rule = "kept NIH (no val positives)"
    else:
        grid = np.unique(np.quantile(p, np.linspace(0, 1, 201)))
        f1s = [f1_score(y, (p >= t).astype(int), zero_division=0) for t in grid]
        new_thr[l] = float(grid[int(np.argmax(f1s))]); rule = "max F1 on IU val"
    rows.append({"finding": l, "val positives": int(y.sum()), "test positives": int(Y[tst, k].sum()),
                 "NIH threshold": round(nih_thr[l], 4), "IU-val threshold": round(new_thr[l], 4), "rule": rule})
json.dump(new_thr, open(os.path.join(OUT, "models", f"thresholds_iu_val_{NAME}.json"), "w"), indent=1)

P_nih = (probs >= np.array([nih_thr[l] for l in NIH_LABELS])).astype(int)
P_new = (probs >= np.array([new_thr[l] for l in NIH_LABELS])).astype(int)
lab = pd.DataFrame(rows)
lab["test F1 (NIH thr)"] = [round(f1_score(Y[tst, k], P_nih[tst, k], zero_division=0), 3) for k in range(len(NIH_LABELS))]
lab["test F1 (IU-val thr)"] = [round(f1_score(Y[tst, k], P_new[tst, k], zero_division=0), 3) for k in range(len(NIH_LABELS))]
lab["predicted positives per test study (NIH)"] = round(P_nih[tst].sum() / tst.sum(), 3)
lab["predicted positives per test study (IU-val)"] = round(P_new[tst].sum() / tst.sum(), 3)
lab.to_csv(os.path.join(OUT, "tables", "table5b_label_f1.csv"), index=False)
print(lab.to_string())
print("label micro-F1 on IU test: NIH thr", round(f1_score(Y[tst], P_nih[tst], average="micro", zero_division=0), 3),
      "| IU-val thr", round(f1_score(Y[tst], P_new[tst], average="micro", zero_division=0), 3))
print("mean predicted findings per test study: NIH", P_nih[tst].sum(1).mean().round(2), "| IU-val", P_new[tst].sum(1).mean().round(2),
      "| reference", Y[tst].sum(1).mean().round(2))

# %% [markdown]
# ## 2. Regenerate test reports with the recalibrated labels (same BioGPT, same filter)

# %%
from transformers import BioGptTokenizer, BioGptForCausalLM
tok = BioGptTokenizer.from_pretrained("microsoft/biogpt")
G = pd.read_csv(os.path.join(OUT, "generated", "iu_test_reports.csv"), dtype={"uid": str})
new_labels = {u: {l: int(v) for l, v in zip(NIH_LABELS, row)} for u, row in zip(iu.uid[tst], P_new[tst])}
rec_file = os.path.join(OUT, "generated", "iu_test_reports_recal.csv")
if os.path.exists(rec_file):
    R = pd.read_csv(rec_file, dtype={"uid": str})
else:
    m = BioGptForCausalLM.from_pretrained(os.path.join(OUT, "models", "biogpt_prompted", "final")).to(DEVICE).eval()
    srcs = [T.build_prompt(new_labels[u]) + " report:" for u in G.uid]
    outs = []; tok.padding_side = "left"
    with torch.no_grad():
        for i in range(0, len(srcs), 16):
            enc = tok(srcs[i:i + 16], return_tensors="pt", padding=True).to(DEVICE)
            g = m.generate(**enc, max_new_tokens=160, num_beams=3, no_repeat_ngram_size=4, early_stopping=True,
                           eos_token_id=tok.eos_token_id, pad_token_id=tok.pad_token_id)
            outs += [tok.decode(x[enc["input_ids"].shape[1]:], skip_special_tokens=True).strip() for x in g]
    del m; torch.cuda.empty_cache()
    filt = [T.consistency_filter(r, new_labels[u]) for u, r in zip(G.uid, outs)]
    R = pd.DataFrame({"uid": G.uid, "reference": G.reference, "recal_nofilter": outs, "recal": [f[0] for f in filt],
                      "template_recal": [T.template_report(new_labels[u]) for u in G.uid]})
    R.to_csv(rec_file, index=False)
    pd.DataFrame({"removed_sentences": [len(f[1]["removed"]) for f in filt], "added_sentences": [len(f[1]["added"]) for f in filt]}) \
      .describe().to_csv(os.path.join(OUT, "tables", "filter_log_summary_recal.csv"))
for c in ["biogpt_noprompt", "ours_pred_nofilter", "ours"]:
    R[c] = G[c].values

# %% [markdown]
# ## 3. Metrics (same code as notebook 03)

# %%
from transformers import tokenization_utils_base as _tub
def _encode_plus(self, t=None, *a, **k):
    t = k.pop("text") if t is None else t
    if isinstance(t, (list, tuple)) and t and isinstance(t[0], str):
        ids = self.convert_tokens_to_ids(list(t))
        if k.get("add_special_tokens", True):
            ids = [self.cls_token_id] + ids + [self.sep_token_id]
        return {"input_ids": ids}
    return self(t, *a, **k)
if not hasattr(_tub.PreTrainedTokenizerBase, "build_inputs_with_special_tokens"):
    _tub.PreTrainedTokenizerBase.build_inputs_with_special_tokens = lambda self, a, b=None: (
        [self.cls_token_id] + list(a) + [self.sep_token_id] + ((list(b) + [self.sep_token_id]) if b else []))
if not hasattr(_tub.PreTrainedTokenizerBase, "encode_plus"):
    _tub.PreTrainedTokenizerBase.encode_plus = _encode_plus
_cx = "/root/.cache/chexbert/chexbert.pth"
if not os.path.exists(_cx):
    _c = [p for p in glob.glob("/root/.cache/**/chexbert.pth", recursive=True) if os.path.isfile(p)]
    if _c:
        os.makedirs(os.path.dirname(_cx), exist_ok=True); shutil.copy(_c[0], _cx)
from pycocoevalcap.bleu.bleu import Bleu
from pycocoevalcap.rouge.rouge import Rouge
import nltk; nltk.download("wordnet", quiet=True); nltk.download("omw-1.4", quiet=True)
from nltk.translate.meteor_score import meteor_score as _ms
from f1chexbert import F1CheXbert
from radgraph import F1RadGraph

CONDITIONS = ["Enlarged Cardiomediastinum", "Cardiomegaly", "Lung Opacity", "Lung Lesion", "Edema", "Consolidation", "Pneumonia",
              "Atelectasis", "Pneumothorax", "Pleural Effusion", "Pleural Other", "Fracture", "Support Devices", "No Finding"]
FIVE = [CONDITIONS.index(c) for c in ["Atelectasis", "Cardiomegaly", "Consolidation", "Edema", "Pleural Effusion"]]
chexbert = F1CheXbert(device=DEVICE); radgraph = F1RadGraph(reward_level="partial")
lbl = lambda texts: np.array([chexbert.get_label(t) for t in texts], dtype=int)
bleu = lambda g, r: Bleu(4).compute_score(g, r, verbose=0)[0]

refs = R.reference.tolist(); Yref = lbl(refs)
names = {"template_recal": "Template only (IU-val thresholds)", "recal_nofilter": "BioGPT + prompt, IU-val thresholds",
         "recal": "BioGPT + prompt + filter, IU-val thresholds (ours, recalibrated)"}
cache, out = {}, []
for s in ["recal", "recal_nofilter", "template_recal", "ours", "ours_pred_nofilter", "biogpt_noprompt"]:
    hyps = R[s].fillna("").tolist()
    gts = {i: [T.clean_report_iu_xray(r)] for i, r in enumerate(refs)}
    res = {i: [T.clean_report_iu_xray(h)] for i, h in enumerate(hyps)}
    Yh = lbl(hyps)
    rg = radgraph(hyps=hyps, refs=refs)[1]; rg = np.array(rg[0] if isinstance(rg, tuple) else rg, dtype=float)
    cache[s] = (Yh, rg)
    if s not in names:
        continue
    b = bleu(gts, res)
    c_b4 = stats.bootstrap_ci(lambda i: bleu({k: gts[k] for k in np.unique(i)}, {k: res[k] for k in np.unique(i)})[3], len(refs), n_boot=500)
    c_mi = stats.bootstrap_ci(lambda i, Yh=Yh: f1_score(Yref[i], Yh[i], average="micro", zero_division=0), len(refs))
    c_rg = stats.bootstrap_ci(lambda i, rg=rg: rg[i].mean(), len(refs))
    out.append({"Method": names[s], "BLEU-1": round(b[0], 3), "BLEU-4 (95% CI)": stats.fmt_ci(*c_b4),
                "METEOR": round(float(np.mean([_ms([gts[k][0].split()], res[k][0].split()) for k in gts])), 3),
                "ROUGE-L": round(Rouge().compute_score(gts, res)[0], 3),
                "CheXbert micro-F1-14 (95% CI)": stats.fmt_ci(*c_mi),
                "CheXbert macro-F1-14": round(f1_score(Yref, Yh, average="macro", zero_division=0), 3),
                "CheXbert micro-F1-5": round(f1_score(Yref[:, FIVE], Yh[:, FIVE], average="micro", zero_division=0), 3),
                "RadGraph F1 (95% CI)": stats.fmt_ci(*c_rg)})
t5b = pd.DataFrame(out); t5b.to_csv(os.path.join(OUT, "tables", "table5b_recalibrated.csv"), index=False)
print(t5b.to_string())

tests = []
for other, oname in [("ours", "ours with NIH thresholds"), ("ours_pred_nofilter", "BioGPT + prompt (NIH thr)"),
                     ("biogpt_noprompt", "BioGPT, no prompt"), ("recal_nofilter", "BioGPT + prompt, IU-val thr")]:
    for metric, fa, fb in [
        ("CheXbert micro-F1-14", lambda i: f1_score(Yref[i], cache["recal"][0][i], average="micro", zero_division=0),
                                  lambda i, o=other: f1_score(Yref[i], cache[o][0][i], average="micro", zero_division=0)),
        ("CheXbert macro-F1-14", lambda i: f1_score(Yref[i], cache["recal"][0][i], average="macro", zero_division=0),
                                  lambda i, o=other: f1_score(Yref[i], cache[o][0][i], average="macro", zero_division=0)),
        ("RadGraph F1", lambda i: cache["recal"][1][i].mean(), lambda i, o=other: cache[o][1][i].mean())]:
        r = stats.paired_bootstrap(fa, fb, len(refs))
        tests.append({"Comparison": f"recalibrated ours vs {oname}", "Metric": metric, "Difference": round(r["diff"], 4),
                      "95% CI": f"{r['lower']:.4f} to {r['upper']:.4f}", "p": r["p"]})
sig = pd.DataFrame(tests); sig["p (Holm)"] = stats.holm(sig.p.values)
sig.to_csv(os.path.join(OUT, "tables", "table5b_significance.csv"), index=False)
print(sig.to_string())
