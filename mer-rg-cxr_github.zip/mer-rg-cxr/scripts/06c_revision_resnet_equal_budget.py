# %% [markdown]
# # 06c · Reviewer revision: ResNet-50 with the same 3-epoch budget as EfficientNet-B3
# # (Google Colab, T4 GPU, about 40-70 min; resumes after a disconnect)
#
# Answers reviewer Issue 3. Same split, augmentation, loss, optimiser and validation selection as notebook 01;
# only the number of epochs changes (1 -> 3). Output: `outputs/revision/R5_equal_budget.csv`.

# %%
import os, sys
IN_COLAB = "google.colab" in sys.modules or bool(os.environ.get("MERRG_SUBPROCESS"))
if IN_COLAB and not os.environ.get("MERRG_SUBPROCESS"):
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
REV = os.path.join(OUT, "revision"); os.makedirs(REV, exist_ok=True)
sys.path.insert(0, PROJECT)
os.system("pip install -q timm opencv-python-headless")

import numpy as np, pandas as pd, torch
from merrg.labels import NIH_LABELS
from merrg import stats
from merrg.store import concat_stores
from merrg.vision import ArrayDataset, TrainConfig, build_model, train_model, predict, seed_everything, macro_auc
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
assert DEVICE == "cuda", "No GPU: Runtime -> Change runtime type -> T4 GPU"

LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
concat_stores([os.path.join(STORE, f"nih_part{k:02d}") for k in range(1, 13)], os.path.join(LOCAL, "nih"), delete_parts=False)
NIH_ARR = np.load(os.path.join(LOCAL, "nih.npy"), mmap_mode="r")
nih = pd.read_csv(os.path.join(OUT, "splits", "nih_split.csv"))
part = {s: nih[nih.split == s].reset_index(drop=True) for s in ["train", "val", "test"]}
nds = lambda df, train=False, seed=0: ArrayDataset(NIH_ARR, df.global_row.values, df[NIH_LABELS].values, train=train, seed=seed)

# %%
tag = "resnet50_e3_seed0"
test_file = os.path.join(REV, f"nih_test_{tag}.npy")
if not os.path.exists(test_file):
    ytr = part["train"][NIH_LABELS].values
    pos_weight = ((len(ytr) - ytr.sum(0)) / np.maximum(ytr.sum(0), 1)).tolist()
    seed_everything(0)
    model = build_model("resnet50", len(NIH_LABELS))
    h = train_model(model, nds(part["train"], True, 0), nds(part["val"]), TrainConfig(epochs=3, pos_weight=pos_weight),
                    os.path.join(OUT, "models", f"{tag}.pt"), DEVICE)
    pd.DataFrame(h).to_csv(os.path.join(REV, f"training_history_{tag}.csv"), index=False)
    np.save(test_file, predict(model, nds(part["test"]), device=DEVICE))
    del model; torch.cuda.empty_cache()

# %%
yt, groups = part["test"][NIH_LABELS].values, part["test"]["Patient ID"].values
P = {"EfficientNet-B3 (3 epochs)": np.load(os.path.join(OUT, "preds", "nih_test_efficientnet_b3_seed0.npy")),
     "ResNet-50 (1 epoch, paper)": np.load(os.path.join(OUT, "preds", "nih_test_resnet50_seed0.npy")),
     "ResNet-50 (3 epochs)": np.load(test_file)}
rows = []
for n, p in P.items():
    a, lo, hi = stats.bootstrap_ci(lambda i, p=p: macro_auc(yt[i], p[i]), len(yt), groups=groups)
    rows.append({"Model": n, "NIH test macro AUROC (95% CI)": stats.fmt_ci(a, lo, hi)})
ref = P["EfficientNet-B3 (3 epochs)"]
for n in ["ResNet-50 (1 epoch, paper)", "ResNet-50 (3 epochs)"]:
    r = stats.paired_bootstrap(lambda i: macro_auc(yt[i], ref[i]), lambda i, p=P[n]: macro_auc(yt[i], p[i]), len(yt), groups=groups)
    rows.append({"Model": f"EfficientNet-B3 minus {n}", "NIH test macro AUROC (95% CI)": f"{r['diff']:.3f} ({r['lower']:.3f} to {r['upper']:.3f}), p = {r['p']:.3g}"})
R5 = pd.DataFrame(rows); R5.to_csv(os.path.join(REV, "R5_equal_budget.csv"), index=False)
print(R5.to_string())
print("Done. Send the folder outputs/revision (as a zip) back to Claude.")
