# %% [markdown]
# # 06d · CPU-only part of the revision (no GPU needed; about 40-60 min on a normal Colab runtime)
#
# Produces, in `outputs/revision/`:
#   - examples_hi_te.csv                     Hindi and Telugu IndicTrans2 translations of the example sentences (Table 23)
#   - R1_classifier_per_finding_iu_test.csv  per-finding precision / recall / F1 / AUROC / calibration on IU X-Ray (Table 11)
#   - R3_label_mapping_agreement.csv         MeSH labels vs CheXbert labels from the report text (Table 12)
#   - iu_probs.npy, thresholds.json          reused later by 06a on the GPU
# Paste this whole file into one cell of a NEW notebook and run it (Runtime type: CPU is fine).

# %%
import os, sys, json, glob, shutil
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
LOCAL = "/content/store" if IN_COLAB else os.path.join(PROJECT, "tmp", "store")
REV = os.path.join(OUT, "revision"); os.makedirs(REV, exist_ok=True)
sys.path.insert(0, PROJECT)
os.system("pip install -q timm opencv-python-headless 'transformers==4.51.3' sentencepiece IndicTransToolkit f1chexbert")
import numpy as np, pandas as pd, torch
torch.set_num_threads(os.cpu_count() or 2)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("device:", DEVICE)

# %% [markdown]
# ## A. Hindi and Telugu example translations (IndicTrans2, same decoding as notebook 04)

# %%
from huggingface_hub import login
try:
    from google.colab import userdata
    login(token=userdata.get("HF_TOKEN"))
except Exception as e:
    print("HF_TOKEN secret not found; IndicTrans2 (a gated model) will fail.", e)
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
try:
    from IndicTransToolkit.processor import IndicProcessor
except ImportError:
    from IndicTransToolkit import IndicProcessor
EXAMPLES = ["No pleural effusion or pneumothorax.", "No pneumothorax.", "There is no pleural effusion.",
            "The lungs are mildly hypoinflated without focal consolidation.", "There are no nodules or masses.",
            "Aorta is atherosclerotic.", "Bony structures unremarkable.",
            "The heart is normal in size.", "There is a small left pleural effusion.", "Mild atelectasis in the right lower lobe."]
ex_file = os.path.join(REV, "examples_hi_te.csv")
if not os.path.exists(ex_file):
    name = "ai4bharat/indictrans2-en-indic-1B"
    tk = AutoTokenizer.from_pretrained(name, trust_remote_code=True)
    md = AutoModelForSeq2SeqLM.from_pretrained(name, trust_remote_code=True).to(DEVICE).eval()
    ip = IndicProcessor(inference=True); ex = pd.DataFrame({"en": EXAMPLES})
    for code, tgt in [("hi", "hin_Deva"), ("te", "tel_Telu")]:
        b = ip.preprocess_batch(EXAMPLES, src_lang="eng_Latn", tgt_lang=tgt)
        enc = tk(b, truncation=True, padding="longest", return_tensors="pt", return_attention_mask=True).to(DEVICE)
        with torch.no_grad():
            g = md.generate(**enc, use_cache=True, min_length=0, max_length=256, num_beams=5, num_return_sequences=1)
        ex[code] = ip.postprocess_batch(tk.batch_decode(g, skip_special_tokens=True, clean_up_tokenization_spaces=True), lang=tgt)
        print("done", code)
    ex.to_csv(ex_file, index=False); del md
print(pd.read_csv(ex_file).to_string())

# %% [markdown]
# ## B. Classifier on IU X-Ray: per-finding precision, recall, F1, AUROC and calibration

# %%
from sklearn.metrics import f1_score, precision_score, recall_score, roc_auc_score, cohen_kappa_score
from merrg.labels import NIH_LABELS, READABLE
from merrg import text as T, stats
from merrg.vision import build_model, ArrayDataset, predict, load_store_local
NAME, SEED = "efficientnet_b3", 0
iu = pd.read_csv(os.path.join(OUT, "splits", "iu_split.csv")); iu["uid"] = iu.uid.astype(str)
Y = iu[NIH_LABELS].values.astype(int)
val, tst = (iu.split == "val").values, (iu.split == "test").values
prob_file = os.path.join(REV, "iu_probs.npy")
if os.path.exists(prob_file):
    probs = np.load(prob_file)
else:
    model = build_model(NAME, len(NIH_LABELS), pretrained=False)
    model.load_state_dict(torch.load(os.path.join(OUT, "models", f"{NAME}_seed{SEED}.pt"), map_location=DEVICE))
    IU_ARR = load_store_local(os.path.join(STORE, "iu_frontal"), LOCAL)
    probs = predict(model.to(DEVICE), ArrayDataset(IU_ARR, iu.row.values), batch_size=32, device=DEVICE)
    np.save(prob_file, probs); del model

nih_thr = json.load(open(os.path.join(OUT, "models", f"thresholds_{NAME}_seed{SEED}.json")))
t_nih = np.array([nih_thr[l] for l in NIH_LABELS])

def best_f1_threshold(p, y):
    grid = np.unique(np.quantile(p, np.linspace(0, 1, 201)))
    f1s = [f1_score(y, (p >= t).astype(int), zero_division=0) for t in grid]
    return float(grid[int(np.argmax(f1s))])

PREC_TARGET, MIN_PRED = 0.5, 3      # "confident" = at least half of the validation predictions above it are correct
def high_precision_threshold(p, y):
    """Smallest threshold whose validation precision >= PREC_TARGET with >= MIN_PRED predictions; inf if none."""
    for t in np.unique(np.quantile(p, np.linspace(0, 1, 401))):
        pr = (p >= t)
        if pr.sum() >= MIN_PRED and y[pr].mean() >= PREC_TARGET:
            return float(t)
    return float("inf")

t_iu, t_hi = np.zeros(len(NIH_LABELS)), np.zeros(len(NIH_LABELS))
for k, l in enumerate(NIH_LABELS):
    p, y = probs[val, k], Y[val, k]
    if y.sum() == 0:
        t_iu[k], t_hi[k] = t_nih[k], float("inf")
    else:
        t_iu[k] = best_f1_threshold(p, y)
        t_hi[k] = max(high_precision_threshold(p, y), t_iu[k])
json.dump({"nih": dict(zip(NIH_LABELS, t_nih.tolist())), "iu_val_f1": dict(zip(NIH_LABELS, t_iu.tolist())),
           "iu_val_high_precision": dict(zip(NIH_LABELS, [None if np.isinf(v) else v for v in t_hi]))},
          open(os.path.join(REV, "thresholds.json"), "w"), indent=1)
P_nih, P_iu, P_hi = [(probs >= t).astype(int) for t in (t_nih, t_iu, t_hi)]
P_unc = ((probs >= t_iu) & (probs < t_hi)).astype(int)          # uncertain band for the hedged variant

# %% [markdown]
# ## 2. Per-finding precision, recall, F1, AUROC and calibration on the IU X-Ray test split (reviewer Issue 2)

# %%
def ece(y, p, bins=10):
    e, edges = 0.0, np.linspace(0, 1, bins + 1)
    for a, b in zip(edges[:-1], edges[1:]):
        m = (p >= a) & ((p < b) if b < 1 else (p <= b))
        if m.any():
            e += m.mean() * abs(y[m].mean() - p[m].mean())
    return e

rows = []
Yt, Pt = Y[tst], probs[tst]
for k, l in enumerate(NIH_LABELS):
    r = {"Finding": l, "Test positives": int(Yt[:, k].sum()),
         "AUROC": round(roc_auc_score(Yt[:, k], Pt[:, k]), 3) if 0 < Yt[:, k].sum() < len(Yt) else np.nan,
         "Brier": round(float(np.mean((Pt[:, k] - Yt[:, k]) ** 2)), 4), "ECE": round(ece(Yt[:, k], Pt[:, k]), 4)}
    for tag, P in [("NIH thr", P_nih), ("IU-val thr", P_iu), ("high-precision thr", P_hi)]:
        pk = P[tst, k]
        r[f"Predicted ({tag})"] = int(pk.sum())
        r[f"Precision ({tag})"] = round(precision_score(Yt[:, k], pk, zero_division=0), 3)
        r[f"Recall ({tag})"] = round(recall_score(Yt[:, k], pk, zero_division=0), 3)
        r[f"F1 ({tag})"] = round(f1_score(Yt[:, k], pk, zero_division=0), 3)
    rows.append(r)
summ = {"Finding": "ALL (micro)", "Test positives": int(Yt.sum())}
for tag, P in [("NIH thr", P_nih), ("IU-val thr", P_iu), ("high-precision thr", P_hi)]:
    summ[f"Predicted ({tag})"] = int(P[tst].sum())
    summ[f"Precision ({tag})"] = round(precision_score(Yt, P[tst], average="micro", zero_division=0), 3)
    summ[f"Recall ({tag})"] = round(recall_score(Yt, P[tst], average="micro", zero_division=0), 3)
    summ[f"F1 ({tag})"] = round(f1_score(Yt, P[tst], average="micro", zero_division=0), 3)
rows.append(summ)
cls = pd.DataFrame(rows); cls.to_csv(os.path.join(REV, "R1_classifier_per_finding_iu_test.csv"), index=False)
print(cls.to_string())
print("findings per test study: reference", Yt.sum(1).mean().round(2), "| NIH thr", P_nih[tst].sum(1).mean().round(2),
      "| IU-val thr", P_iu[tst].sum(1).mean().round(2), "| high-precision thr", P_hi[tst].sum(1).mean().round(2),
      "| uncertain band", P_unc[tst].sum(1).mean().round(2))


# %% [markdown]
# ## C. Do the MeSH-derived IU labels agree with CheXbert labels read from the report text?

# %%
_cx = "/root/.cache/chexbert/chexbert.pth"
if not os.path.exists(_cx):
    _c = [p for p in glob.glob("/root/.cache/**/chexbert.pth", recursive=True) if os.path.isfile(p)]
    if _c:
        os.makedirs(os.path.dirname(_cx), exist_ok=True); shutil.copy(_c[0], _cx)
if not os.path.exists(_cx):
    from huggingface_hub import hf_hub_download
    os.makedirs(os.path.dirname(_cx), exist_ok=True); shutil.copy(hf_hub_download("StanfordAIMI/RRG_scorers", "chexbert.pth"), _cx)
from f1chexbert import F1CheXbert
CONDITIONS = ["Enlarged Cardiomediastinum", "Cardiomegaly", "Lung Opacity", "Lung Lesion", "Edema", "Consolidation", "Pneumonia",
              "Atelectasis", "Pneumothorax", "Pleural Effusion", "Pleural Other", "Fracture", "Support Devices", "No Finding"]
chexbert = F1CheXbert(device=DEVICE)
lbl = lambda texts: np.array([chexbert.get_label(t) for t in texts], dtype=int)
PAIRS = {"Atelectasis": "Atelectasis", "Cardiomegaly": "Cardiomegaly", "Effusion": "Pleural Effusion",
         "Pneumothorax": "Pneumothorax", "Consolidation": "Consolidation", "Edema": "Edema", "Pneumonia": "Pneumonia"}
Ytext = lbl(iu.findings.fillna("").tolist())
rows = []
for nih_l, cx in PAIRS.items():
    a, b = Y[:, NIH_LABELS.index(nih_l)], Ytext[:, CONDITIONS.index(cx)]
    rows.append({"NIH label (MeSH)": nih_l, "CheXbert label (text)": cx, "MeSH positives": int(a.sum()), "Text positives": int(b.sum()),
                 "Both positive": int((a & b).sum()), "Agreement (%)": round(100 * (a == b).mean(), 1),
                 "Cohen kappa": round(cohen_kappa_score(a, b), 3) if (a.any() or b.any()) else np.nan})
R3 = pd.DataFrame(rows); R3.to_csv(os.path.join(REV, "R3_label_mapping_agreement.csv"), index=False)
print(R3.to_string())
print("\nDone. Zip the folder outputs/revision and send it to Claude.")
