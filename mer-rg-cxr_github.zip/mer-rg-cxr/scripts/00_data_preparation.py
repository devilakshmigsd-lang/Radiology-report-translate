# %% [markdown]
# # 00 · Data preparation (Google Colab)
#
# Downloads each dataset, shrinks every image **once** to 224 × 224 (CLAHE + letterbox), stores the result
# as compact files in Google Drive (`MyDrive/mer-rg/store/`), deletes the raw download, and builds
# patient-level splits.
#
# * Runtime: GPU is **not** needed here, so a CPU runtime is fine. It takes about 3–6 hours, mostly downloading.
# * **Safe to re-run**: anything already finished is skipped, so after a disconnect just run all cells again.
# * Drive space needed: about 8 GB.
#
# Outputs used by later notebooks: `store/*.npy|csv`, `outputs/splits/*.csv`, and **Paper Table 2**
# (`outputs/tables/table2_dataset_counts.csv`).

# %%
import os, sys, glob, json, shutil, subprocess, tarfile
IN_COLAB = "google.colab" in sys.modules
if IN_COLAB:
    from google.colab import drive
    drive.mount("/content/drive")
PROJECT = "/content/drive/MyDrive/mer-rg" if IN_COLAB else os.path.abspath("..")
STORE, OUT = os.path.join(PROJECT, "store"), os.path.join(PROJECT, "outputs")
TMP = "/content/tmp" if IN_COLAB else os.path.join(PROJECT, "tmp")      # big, temporary, local disk
sys.path.insert(0, PROJECT)
for d in [STORE, TMP, os.path.join(OUT, "splits"), os.path.join(OUT, "tables")]:
    os.makedirs(d, exist_ok=True)
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "kaggle", "opencv-python-headless", "openpyxl"], check=True)
SIZE, SEED = 224, 2026

import numpy as np, pandas as pd
from merrg.store import build_store
from merrg.labels import NIH_LABELS, VINDR_TO_NIH, NIH_BBOX_RENAME, iu_problems_to_labels

def find_one(root, pattern):
    hits = sorted(glob.glob(os.path.join(root, "**", pattern), recursive=True))
    if not hits:
        raise FileNotFoundError(f"{pattern} not found under {root}. List the folder and fix the pattern.")
    return hits[0]

def done(prefix):
    return os.path.exists(prefix + ".npy") and os.path.exists(prefix + ".csv")

# %% [markdown]
# ## 1. Kaggle key
# Either put `kaggle.json` inside `MyDrive/mer-rg/`, or (new-style token starting with KGAT_) add it as a Colab secret:
# click the key icon in Colab's left bar → *Add new secret* → name `KAGGLE_API_TOKEN`, paste the token, switch on *Notebook access*.

# %%
subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", "kaggle"], check=True)
if os.path.exists(os.path.join(PROJECT, "kaggle.json")):            # classic key file
    os.makedirs(os.path.expanduser("~/.kaggle"), exist_ok=True)
    shutil.copy(os.path.join(PROJECT, "kaggle.json"), os.path.expanduser("~/.kaggle/kaggle.json"))
    os.chmod(os.path.expanduser("~/.kaggle/kaggle.json"), 0o600)
else:                                                                # new-style token (KGAT_...) stored as a Colab secret
    from google.colab import userdata
    os.environ["KAGGLE_API_TOKEN"] = userdata.get("KAGGLE_API_TOKEN")

def kaggle_dataset(slug, dest, files=None):
    """Download a whole Kaggle dataset (or only `files`) into dest and unzip."""
    os.makedirs(dest, exist_ok=True)
    if files:
        for f in files:
            subprocess.run(["kaggle", "datasets", "download", "-d", slug, "-f", f, "-p", dest, "-q"], check=True)
        for z in glob.glob(os.path.join(dest, "*.zip")):
            shutil.unpack_archive(z, dest); os.remove(z)
    else:
        subprocess.run(["kaggle", "datasets", "download", "-d", slug, "-p", dest, "--unzip", "-q"], check=True)

# Check each slug on kaggle.com if a download fails; any copy with the same files works.
KAGGLE = {
    "nih_meta": "nih-chest-xrays/data",                                   # only the CSV/TXT files are taken from here
    "vindr": "xhlulu/vinbigdata-chest-xray-resized-png-1024x1024",
    "tbx11k": "usmanshams/tbx-11",
    "shenzhen": "raddar/tuberculosis-chest-xrays-shenzhen",
    "montgomery": "raddar/tuberculosis-chest-xrays-montgomery",
    "iu": "raddar/chest-xrays-indiana-university",
}

# %% [markdown]
# ## 2. NIH ChestX-ray14
# Labels and splits come from Kaggle (small files). Images come from the 12 official NIH archives
# (about 4 GB each). Each archive is downloaded, shrunk into `store/nih_partNN`, and deleted before the next.

# %%
meta_dir = os.path.join(STORE, "nih_meta")
if not os.path.exists(os.path.join(meta_dir, "Data_Entry_2017.csv")):
    kaggle_dataset(KAGGLE["nih_meta"], meta_dir, files=["Data_Entry_2017.csv", "BBox_List_2017.csv", "test_list.txt", "train_val_list.txt"])
print(os.listdir(meta_dir))

NIH_URLS = [  # official NIH Clinical Center links (from the dataset's batch_download_zips.py)
    "https://nihcc.box.com/shared/static/vfk49d74nhbxq3nqjg0900w5nvkorp5c.gz",
    "https://nihcc.box.com/shared/static/i28rlmbvmfjbl8p2n3ril0pptcmcu9d1.gz",
    "https://nihcc.box.com/shared/static/f1t00wrtdk94satdfb9olcolqx20z2jp.gz",
    "https://nihcc.box.com/shared/static/0aowwzs5lhjrceb3qp67ahp0rd1l1etg.gz",
    "https://nihcc.box.com/shared/static/v5e3goj22zr6h8tzualxfsqlqaygfbsn.gz",
    "https://nihcc.box.com/shared/static/asi7ikud9jwnkrnkj99jnpfkjdes7l6l.gz",
    "https://nihcc.box.com/shared/static/jn1b4mw4n6lnh74ovmcjb8y48h8xj07n.gz",
    "https://nihcc.box.com/shared/static/tvpxmn7qyrgl0w8wfh9kqfjskv6nmm1j.gz",
    "https://nihcc.box.com/shared/static/upyy3ml7qdumlgk2rfcvlb9k6gvqq2pj.gz",
    "https://nihcc.box.com/shared/static/l6nilvfa9cg3s28tqv1qc1olm3gnz54p.gz",
    "https://nihcc.box.com/shared/static/hhq8fkdgvcari67vfhs7ppg2w6ni4jze.gz",
    "https://nihcc.box.com/shared/static/ioqwiy20ihqwyr8pf4c24eazhh281pbu.gz",
]
for k, url in enumerate(NIH_URLS, start=1):
    prefix = os.path.join(STORE, f"nih_part{k:02d}")
    if done(prefix):
        print("part", k, "already done"); continue
    tgz, xdir = os.path.join(TMP, f"nih_{k:02d}.tar.gz"), os.path.join(TMP, f"nih_{k:02d}")
    print("downloading part", k)
    subprocess.run(["wget", "-c", "-q", "-O", tgz, url], check=True)
    with tarfile.open(tgz) as t:
        t.extractall(xdir)
    os.remove(tgz)
    pngs = sorted(glob.glob(os.path.join(xdir, "**", "*.png"), recursive=True))
    print(f"  {len(pngs)} images -> {prefix}")
    build_store(pngs, prefix, size=SIZE, delete_source=True)
    shutil.rmtree(xdir, ignore_errors=True)

# %%
parts = [os.path.join(STORE, f"nih_part{k:02d}") for k in range(1, 13)]
idx = pd.concat([pd.read_csv(p + ".csv").assign(part=k) for k, p in enumerate(parts, start=1)], ignore_index=True)
idx["global_row"] = np.arange(len(idx))         # row in the assembled array (parts concatenated in order)
idx["Image Index"] = idx.path.apply(os.path.basename)
meta = pd.read_csv(os.path.join(meta_dir, "Data_Entry_2017.csv"))
nih = meta.merge(idx[["Image Index", "global_row", "scale", "pad_x", "pad_y"]], on="Image Index", how="inner")
print(len(meta), "listed,", len(nih), "stored")
for lab in NIH_LABELS:
    nih[lab] = nih["Finding Labels"].str.split("|").apply(lambda xs: int(lab in xs))
test_list = set(open(os.path.join(meta_dir, "test_list.txt")).read().split())
nih["split"] = np.where(nih["Image Index"].isin(test_list), "test", "train")
rng = np.random.default_rng(SEED)
tr_pat = nih.loc[nih.split == "train", "Patient ID"].unique()
val_pat = set(rng.choice(tr_pat, size=int(0.1 * len(tr_pat)), replace=False))
nih.loc[(nih.split == "train") & nih["Patient ID"].isin(val_pat), "split"] = "val"
S = {s: set(nih.loc[nih.split == s, "Patient ID"]) for s in ["train", "val", "test"]}
assert not (S["train"] & S["val"]) and not (S["train"] & S["test"]) and not (S["val"] & S["test"]), "patient leakage"
nih = nih[["Image Index", "Patient ID", "View Position", "global_row", "scale", "pad_x", "pad_y", "split"] + NIH_LABELS]
nih.to_csv(os.path.join(OUT, "splits", "nih_split.csv"), index=False)

bbox = pd.read_csv(os.path.join(meta_dir, "BBox_List_2017.csv")).iloc[:, :6]
bbox.columns = ["Image Index", "Finding Label", "x", "y", "w", "h"]
bbox["Finding Label"] = bbox["Finding Label"].replace(NIH_BBOX_RENAME)
bbox = bbox.merge(nih[["Image Index", "Patient ID", "global_row", "scale", "pad_x", "pad_y", "split"]], on="Image Index")
print("boxes:", len(bbox), "| on test patients:", int((bbox.split == "test").sum()))
bbox[bbox.split == "test"].to_csv(os.path.join(OUT, "splits", "nih_bbox_test.csv"), index=False)
nih.groupby("split")[NIH_LABELS].sum().T

# %% [markdown]
# ## 3. VinDr-CXR (external test). A finding counts when ≥ 2 of the 3 radiologists marked it.

# %%
USE_VINDR = True
vprefix = os.path.join(STORE, "vindr")
vdir = os.path.join(TMP, "vindr")
VCOMP = "vinbigdata-chest-xray-abnormalities-detection"   # labels (train.csv) come from the original competition
if USE_VINDR and not done(vprefix) and not glob.glob(os.path.join(vdir, "**", "*.png"), recursive=True):
    kaggle_dataset(KAGGLE["vindr"], vdir)
if USE_VINDR and not done(vprefix) and not glob.glob(os.path.join(vdir, "**", "train.csv"), recursive=True):
    subprocess.run(["kaggle", "competitions", "download", "-c", VCOMP, "-f", "train.csv", "-p", vdir])
    for z in glob.glob(os.path.join(vdir, "*.zip")):
        shutil.unpack_archive(z, vdir); os.remove(z)
if USE_VINDR and not done(vprefix) and not glob.glob(os.path.join(vdir, "**", "train.csv"), recursive=True):
    print("VinDr labels not available: open kaggle.com/competitions/" + VCOMP + "/rules, accept the rules, then re-run. Skipping VinDr for now.")
    USE_VINDR = False
if USE_VINDR and not done(vprefix):
    shutil.copy(find_one(vdir, "train.csv"), os.path.join(STORE, "vindr_train.csv"))
    pngs = sorted(p for p in glob.glob(os.path.join(vdir, "**", "*.png"), recursive=True) if "/test" not in p)
    build_store(pngs, vprefix, size=SIZE, delete_source=True); shutil.rmtree(vdir, ignore_errors=True)
if USE_VINDR:
    v = pd.read_csv(os.path.join(STORE, "vindr_train.csv"))
    vix = pd.read_csv(vprefix + ".csv"); vix["image_id"] = vix.path.apply(lambda p: os.path.splitext(os.path.basename(p))[0])
    votes = v[v.class_name.isin(VINDR_TO_NIH)].groupby(["image_id", "class_name"]).rad_id.nunique().unstack(fill_value=0)
    vl = vix[["image_id", "row"]].copy()
    for cname, lab in VINDR_TO_NIH.items():
        col = votes[cname] if cname in votes else pd.Series(dtype=int)
        vl[lab] = (vl.image_id.map(col).fillna(0) >= 2).astype(int)
    vl = vl[vl.image_id.isin(set(v.image_id))]
    vl.to_csv(os.path.join(OUT, "splits", "vindr_labels.csv"), index=False)
    print(vl.drop(columns=["image_id", "row"]).sum())

# %% [markdown]
# ## 4. Tuberculosis: TBX11K (train / internal test) + Shenzhen and Montgomery (external test)
# TBX11K's official test labels are not public, so its official *val* list is the internal test set.

# %%
tprefix = os.path.join(STORE, "tb")
if not done(tprefix):
    rows = []
    tdir = os.path.join(TMP, "tbx11k"); kaggle_dataset(KAGGLE["tbx11k"], tdir)
    lists = {n: set(l.strip() for l in open(find_one(tdir, f"TBX11K_{n}.txt"))) for n in ["train", "val"]}
    for p in glob.glob(os.path.join(tdir, "**", "imgs", "**", "*.png"), recursive=True):
        cat = os.path.basename(os.path.dirname(p))
        rel = f"{cat}/{os.path.basename(p)}"
        if cat in ("health", "sick", "tb") and (rel in lists["train"] or rel in lists["val"]):
            rows.append({"path": p, "tb": int(cat == "tb"), "split": "test" if rel in lists["val"] else "train", "source": "TBX11K"})
    assert rows, "TBX11K list entries did not match image paths: print a few list lines and adjust `rel`"
    for key in ["shenzhen", "montgomery"]:
        d = os.path.join(TMP, key); kaggle_dataset(KAGGLE[key], d)
        for p in glob.glob(os.path.join(d, "**", "*.png"), recursive=True):
            stem = os.path.splitext(os.path.basename(p))[0]
            if stem.upper().startswith(("CHNCXR", "MCUCXR")) and stem.split("_")[-1] in ("0", "1"):
                rows.append({"path": p, "tb": int(stem.split("_")[-1]), "split": "external", "source": key})
    tb = pd.DataFrame(rows)
    tr = tb.index[tb.split == "train"]
    tb.loc[rng.choice(tr, size=int(0.1 * len(tr)), replace=False), "split"] = "val"
    idx_tb = build_store(tb.path.tolist(), tprefix, size=SIZE, delete_source=True)
    tb["row"] = idx_tb.row.values
    tb.drop(columns="path").to_csv(os.path.join(OUT, "splits", "tb_split.csv"), index=False)
    for key in ["tbx11k", "shenzhen", "montgomery"]:
        shutil.rmtree(os.path.join(TMP, key), ignore_errors=True)
tb = pd.read_csv(os.path.join(OUT, "splits", "tb_split.csv"))
tb.groupby(["source", "split"]).tb.agg(["count", "sum"])

# %% [markdown]
# ## 5. IU X-Ray: studies with a findings section and both views; 7:1:2 split by study

# %%
iprefix_f, iprefix_l = os.path.join(STORE, "iu_frontal"), os.path.join(STORE, "iu_lateral")
iu_file = os.path.join(OUT, "splits", "iu_split.csv")
if not (done(iprefix_f) and done(iprefix_l) and os.path.exists(iu_file)):
    idir = os.path.join(TMP, "iu"); kaggle_dataset(KAGGLE["iu"], idir)
    rep = pd.read_csv(find_one(idir, "indiana_reports.csv"))
    proj = pd.read_csv(find_one(idir, "indiana_projections.csv"))
    ipaths = {os.path.basename(p): p for p in glob.glob(os.path.join(idir, "**", "*.png"), recursive=True)}
    proj["path"] = proj.filename.map(ipaths)
    front = proj[proj.projection == "Frontal"].dropna(subset=["path"]).groupby("uid").path.first()
    lat = proj[proj.projection == "Lateral"].dropna(subset=["path"]).groupby("uid").path.first()
    iu = rep.set_index("uid").join(front.rename("frontal")).join(lat.rename("lateral")).reset_index()
    iu = iu[iu.findings.notna() & (iu.findings.str.strip() != "") & iu.frontal.notna() & iu.lateral.notna()].reset_index(drop=True)
    labs = iu.Problems.fillna("").apply(iu_problems_to_labels).apply(pd.Series)
    iu = pd.concat([iu, labs], axis=1)
    order = rng.permutation(len(iu)); n_tr, n_va = int(0.7 * len(iu)), int(0.1 * len(iu))
    iu["split"] = "test"
    iu.loc[order[:n_tr], "split"] = "train"; iu.loc[order[n_tr:n_tr + n_va], "split"] = "val"
    build_store(iu.frontal.tolist(), iprefix_f, size=SIZE)
    build_store(iu.lateral.tolist(), iprefix_l, size=SIZE)
    iu["row"] = np.arange(len(iu))
    iu.drop(columns=["frontal", "lateral"]).to_csv(iu_file, index=False)
    shutil.rmtree(idir, ignore_errors=True)
iu = pd.read_csv(iu_file)
iu.split.value_counts()

# %% [markdown]
# ### Export the IU split for the R2Gen / CMN baselines (PNG files + annotation.json in their format)

# %%
r2 = os.path.join(PROJECT, "r2gen_iu")
if not os.path.exists(os.path.join(r2, "annotation.json")):
    import cv2
    F, L = np.load(iprefix_f + ".npy", mmap_mode="r"), np.load(iprefix_l + ".npy", mmap_mode="r")
    ann = {"train": [], "val": [], "test": []}
    for _, r in iu.iterrows():
        sid = str(r.uid); d = os.path.join(TMP, "r2gen_iu", "images", sid); os.makedirs(d, exist_ok=True)
        cv2.imwrite(os.path.join(d, "0.png"), np.asarray(F[r.row])); cv2.imwrite(os.path.join(d, "1.png"), np.asarray(L[r.row]))
        ann[r.split].append({"id": sid, "report": r.findings, "image_path": [f"{sid}/0.png", f"{sid}/1.png"], "split": r.split})
    json.dump(ann, open(os.path.join(TMP, "r2gen_iu", "annotation.json"), "w"))
    shutil.make_archive(os.path.join(TMP, "r2gen_iu"), "zip", os.path.join(TMP, "r2gen_iu"))
    os.makedirs(r2, exist_ok=True)
    shutil.copy(os.path.join(TMP, "r2gen_iu.zip"), os.path.join(r2, "r2gen_iu.zip"))
    shutil.copy(os.path.join(TMP, "r2gen_iu", "annotation.json"), os.path.join(r2, "annotation.json"))
print("R2Gen export:", os.listdir(r2))

# %% [markdown]
# ## 6. Paper Table 2 — dataset counts (+ Supplementary Table S2 prevalence)

# %%
rows = [{"Dataset": "NIH ChestX-ray14", "Split": s, "Images": int((nih.split == s).sum()), "Patients": nih.loc[nih.split == s, "Patient ID"].nunique()} for s in ["train", "val", "test"]]
if USE_VINDR:
    rows.append({"Dataset": "VinDr-CXR (external)", "Split": "test", "Images": len(vl), "Patients": None})
for (src, s), d in tb.groupby(["source", "split"]):
    rows.append({"Dataset": src, "Split": s, "Images": len(d), "Patients": None, "TB positive": int(d.tb.sum())})
rows += [{"Dataset": "IU X-Ray", "Split": s, "Images": 2 * int((iu.split == s).sum()), "Patients": int((iu.split == s).sum())} for s in ["train", "val", "test"]]
bt = pd.read_csv(os.path.join(OUT, "splits", "nih_bbox_test.csv"))
rows.append({"Dataset": "NIH expert boxes (test patients)", "Split": "test", "Images": bt["Image Index"].nunique(), "Patients": bt["Patient ID"].nunique(), "Boxes": len(bt)})
t2 = pd.DataFrame(rows); t2.to_csv(os.path.join(OUT, "tables", "table2_dataset_counts.csv"), index=False)
(nih.groupby("split")[NIH_LABELS].mean().T * 100).round(2).to_csv(os.path.join(OUT, "tables", "tableS2_label_prevalence_nih.csv"))
print("Drive usage of store/:", round(sum(os.path.getsize(p) for p in glob.glob(os.path.join(STORE, "*"))) / 1e9, 2), "GB")
t2
