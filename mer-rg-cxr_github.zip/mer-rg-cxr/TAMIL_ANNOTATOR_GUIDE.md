# Tamil translation check: instructions for annotators

Thank you for helping. You will check computer translations of short chest X-ray report sentences from English
into Tamil. **No medical training is needed.** You only judge whether the Tamil sentence keeps the meaning of
the English one.

**Time:** about 2–3 hours, and you can stop and continue later. Please work **alone** and don't discuss your
answers with the other annotator until both of you have finished.

## Your sheet

Each row has:
- `en`: the English sentence
- `system_code`: a code for the translation program (S1, S2, ...). Ignore it.
- `tamil_translation`: the computer's Tamil translation
- seven columns for you to fill in

The same English sentence appears more than once, translated by different programs. Judge each row on its own.

## What to mark

Read the English, then the Tamil. Put **1** in a column if that problem is present. Leave the cell **empty**
if it isn't. One row can have more than one 1.

| Column | Put 1 when... | Example |
|---|---|---|
| `negation_changed` | "no / not / without" is lost or added, so a finding becomes present or absent | "**No** pneumothorax" translated as "pneumothorax is present" |
| `left_right_changed` | left becomes right, right becomes left, or a side is lost or added | "Small **left** effusion" translated with **வலது** (right) |
| `size_or_severity_changed` | small, large, mild, moderate or severe is changed or lost | "**Mild** cardiomegaly" translated as "severe" |
| `finding_or_sentence_missing` | part of the English meaning is missing from the Tamil | "No effusion **or pneumothorax**" with the pneumothorax part missing |
| `meaning_changed_other` | the meaning is wrong in any other way | a different body part, or a different finding |
| `grammar_or_fluency` | the meaning is right but the Tamil is awkward or ungrammatical | |
| `comment` | anything you want to note (optional) | |

**Rules of thumb**
- Medical words may stay in English or be transliterated (e.g., "நியூமோதோராக்ஸ்"). That is **not** an error.
- "XXXX" in a sentence is a hidden word (privacy). Ignore it.
- If you're unsure, mark it and write a short comment.
- If the translation is correct, leave all the columns empty.

When you're finished, save the file (keep the same columns) and send it back.
