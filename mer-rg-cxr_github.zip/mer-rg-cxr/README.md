# Multilingual chest radiograph reporting with translation-safety triage: a stage-wise safety evaluation

Code for the paper *"Fluent but Wrong: A Stage-wise Safety Evaluation of a Finding-Grounded, Explainable and
Multilingual Chest Radiograph Reporting Framework with Translation-Safety Triage"* (G. S. Devi Lakshmi and R. Priyadharsini).

The pipeline classifies chest radiographs (EfficientNet-B3), generates finding-grounded English reports (BioGPT with a
label prompt and a consistency filter), explains predictions (Grad-CAM, LIME), translates reports into Hindi, Tamil and
Telugu (IndicTrans2, NLLB-200) and screens every translated sentence with reference-free safety checks. Each stage is
evaluated for the way it can fail. **This is research code, not a clinical tool: no output should reach a patient
without verification by a clinician.**

## Contents

| Folder | What it contains |
|---|---|
| `merrg/` | Python package: labels and MeSH mapping, image store, vision models, explanations, text matcher, consistency filter, translation checks, statistics |
| `notebooks/` | Colab notebooks 00-05 (data preparation, classifiers, explainability, report generation, translation, Tamil audit) |
| `scripts/` | The same notebooks as plain Python, plus the revision experiments (06a-06d: per-finding classifier analysis, label-mapping agreement, confidence-gated generation, end-to-end Tamil test, equal-budget ResNet-50) |
| `tests/` | Unit tests for the text matcher, filter and checks (`pytest tests`) |
| `TAMIL_ANNOTATOR_GUIDE.md` | Instructions and error taxonomy given to the Tamil annotator |

## Data

No data are included. All datasets are public and must be downloaded from their providers under their own licences:
NIH ChestX-ray14 (with the 984 expert bounding boxes), Indiana University (IU) X-Ray / Open-i, TBX11K, and the Shenzhen and Montgomery
tuberculosis sets (external test). Notebook 00 downloads and prepares them and writes the
patient-level splits used in the paper.

## Running

The experiments were run on Google Colab with a T4 GPU. Put this folder in Google Drive as `MyDrive/mer-rg/`, then run
the notebooks in order (00 -> 05), followed by `scripts/06a`, `06c` and `06b`. Translation needs a Hugging Face token
with access to `ai4bharat/indictrans2-en-indic-1B` and `ai4bharat/indictrans2-indic-en-1B`, stored as the Colab
secret `HF_TOKEN`. Install dependencies with `pip install -r requirements.txt`.

## Citation

If you use this code, please cite the paper (details to be added on publication).

## Licence

MIT (see `LICENSE`). The datasets and pretrained models keep their own licences.
